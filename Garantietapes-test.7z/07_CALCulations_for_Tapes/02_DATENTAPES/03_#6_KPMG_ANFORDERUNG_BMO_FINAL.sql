------------------------------------------------------------------------------------------------------------------------
-- FINISH VIEW ---------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_FINISH_DISTINCT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_FINISH_DISTINCT as
select
     K.CUT_OFF_DATE
     ,KONZERN_NR
     ,KONZERN_BEZ
     ,ACC.CLIENT_ID
     ,CLIENT_NAME
     ,INSTITUTE_CLIENT
     ,CUSTOMERSEGMENT
     ,LEGALFORM
     ,E_MAIL_ADRESS_MAIN
     ,COUNTRY_AS_LEGI_DOK
     ,ZIP_AS_LEGI_DOK
     ,CITY_AS_LEGI_DOK
     ,STREET_AS_LEGI_DOK
     ,NBR_AS_LEGI_DOK
     ,PERSONTYPE
     ,KUSYMA_20
     ,NACE
     ,OE_BEZEICHNUNG
     ,OE_NR_OSP
     ,CLIENT_INFORMATION_FROM
     ,K.BSA_RELEVANT
     ,ACC.KONSORTIALGESCHAEFT
     ,upper(ACC.SYNDICATION_ROLE) as SYNDICATION_ROLE
     ,K.ORIGINATION_2020 as CLIENT_ORIGINATION_IN_YEAR_OF_COD
     --------------------
     ,left(LPAD(ACC.PRODUCT_KEY,4,'0'),2) as PRODUCT_GROUP
     ,ACC.PRODUCT_KEY
     ,PRODUCT_DESCRIPTION
     ,FACILITY_ID
     ,MUREX_COMPONENT_REFERENCE
     ,MUREX_CONTRACT_REFERENCE
     ,ACC.BRANCH as INSTITUTE_ACCOUNT
     ,ACC.RATING_ID
     ,ACC.ORIGINATION_2020 as ACCOUNT_ORIGINATION_IN_YEAR_OF_COD
     ,CURRENTCONTRACTUALMATURITYDATE
     ,MATURITYDATE
     ,EAD_TOTAL_EUR
     ,FREIE_LINIE
     ,PRINCIPALOUTSTANDING_EUR
     ,BALANCE_SHEET_ITEM
     ,first_value(POS.BESCHREIBUNG) over (partition by FACILITY_ID order by POS.POSITION desc) as BALANCE_SHEET_ITEM_TXT
     ,LLP_EUR
     ,ACCOUNT_CURRENCY
     ,coalesce(C_N.RISIKO_FINAL,C_B.RISIKO_FINAL) as MONEY_LAUDRY_CLASS_ON_20200931
     ,CURRENT_BUSINESS_RELATION
     ,ACCOUNT_INFROMATION_FROM
from MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT_CURRENT as K
inner join MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT_CURRENT as ACC on ACC.CLIENT_ID = K.CLIENT_ID and ACC.CLIENT_ID=K.CLIENT_ID and ACC.BRANCH_CLIENT=K.INSTITUTE_CLIENT and K.CUT_OFF_DATE=ACC.CUT_OFF_DATE
left join STG.PRODUKTKATALOG as PRODK on PRODK.PRODUCT_KEY = LPAD(ACC.PRODUCT_KEY,4,'0')
left join NLB.COMPLIANCE_GELDWAESCHE as C_N on /*C_n.CUTOFFDATE=K.CUTOFFDATE and*/ C_N.CLIENT_ID=K.CLIENT_ID and C_N.BRANCH=K.INSTITUTE_CLIENT and C_N.RISIKO_FINAL is not null and C_N.CUTOFFDATE = '30.09.2020'
left join BLB.COMPLIANCE_GELDWAESCHE as C_B on /*C_B.CUTOFFDATE=K.CUTOFFDATE and*/ C_B.CLIENT_ID=K.CLIENT_ID and C_B.BRANCH=K.INSTITUTE_CLIENT and C_B.RISIKO_FINAL is not null and C_B.CUTOFFDATE = '30.09.2020'
left join IMAP.POSITIONEN as POS on left(POS.POSITION,7)=left(BALANCE_SHEET_ITEM,7)

--order by KONZERN_NR desc,CLIENT_ID DESC,PRODUCT_GROUP desc,PRODUCT_KEY desc, FACILITY_ID desc
;

-- Tabelle erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_FINISH_DISTINCT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_FINISH_DISTINCT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_FINISH_DISTINCT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_FINISH_DISTINCT_CURRENT select distinct * from MAP.VIEW_KPMG_ANFORDERUNG_FINISH_DISTINCT;

------------------------------------------------------------------------------------------------------------------------
-- Banken inkl. Schattenbanken -----------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT as
with KI as (
select distinct ZM_EXTNR,'NLB' as BR from NLB.BW_ZBC_IFRS_CURRENT where left(CS_ITEM,5) like ('11_41') or left(CS_ITEM,5) like ('21_51')
)
    select
        A.*
    --,case when left(Right(KUSYMA_20,7),3) in (
    --'641','642','643','644','649','651','652','653','661','662','663','665','666','667','670','671','672','673','676'
    --) then 'JA' else 'NEIN' end as SCHATTENBANK_VERDACHT_KUSYMA
        ,SA.WERT as SCHATTENBANK_ANALYSE_KR
        ,KS.WERT as TREUHANDVERHAELTNIS
    from MAP.TABLE_KPMG_ANFORDERUNG_FINISH_DISTINCT_CURRENT as A
    left join KI on KI.ZM_EXTNR =A.CLIENT_ID and A.INSTITUTE_CLIENT=KI.BR
    left join SMAP.KPMG_SCHATTENBANKEN as SA on A.CLIENT_ID=SA.KUNDENNUMMER and A.INSTITUTE_CLIENT=SA.INSTITUT
    left join NLB.KPMG_KONSOLIDIERUNG as KS on KS.KUNDENNUMMER = A.CLIENT_ID and A.INSTITUTE_CLIENT = KS.BRANCH
    where 1=1
        and ( KI.ZM_EXTNR is not null
        or left(nace,5) in ('K64','K64.1')
        or SA.KUNDENNUMMER is not null
        )
;

-- Tabelle erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT_CURRENT select distinct * from MAP.VIEW_KPMG_ANFORDERUNG_SCHATTENBANKEN_DISTINCT;


------------------------------------------------------------------------------------------------------------------------
-- alles andere --------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_REST_DISTINCT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_REST_DISTINCT as
    with KI as (
select distinct ZM_EXTNR,'NLB' as BR from NLB.BW_ZBC_IFRS_CURRENT where left(CS_ITEM,5) like ('11_41') or left(CS_ITEM,5) like ('21_51')
)
    select A.* from MAP.TABLE_KPMG_ANFORDERUNG_FINISH_DISTINCT_CURRENT as A
    left join KI on KI.ZM_EXTNR =A.CLIENT_ID and A.INSTITUTE_CLIENT=KI.BR
    left join SMAP.KPMG_SCHATTENBANKEN as SA on A.CLIENT_ID=SA.KUNDENNUMMER and A.INSTITUTE_CLIENT=SA.INSTITUT
    where 1=1
    and KI.ZM_EXTNR is null
    and coalesce(left(nace,5),'AAA') not in ('K64','K64.1')
    and SA.KUNDENNUMMER is null
;

-- Tabelle erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_REST_DISTINCT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_REST_DISTINCT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_REST_DISTINCT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_REST_DISTINCT_CURRENT select distinct * from MAP.VIEW_KPMG_ANFORDERUNG_REST_DISTINCT;

