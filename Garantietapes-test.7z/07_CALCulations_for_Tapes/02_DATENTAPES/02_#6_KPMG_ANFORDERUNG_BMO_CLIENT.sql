------------------------------------------------------------------------------------------------------------------------
-- FINISH VIEW ---------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT as
    with Client_Since as (
        select min(CUTOFFDATE) as CLIENT_SCINCE_AT_LEAST_DATE,branch, BORROWERID from NLB.IWHS_KUNDE group by BORROWERID,branch
            union all
        select min(CUTOFFDATE) as CLIENT_SCINCE_AT_LEAST_DATE,branch, BORROWERID from BLB.IWHS_KUNDE group by BORROWERID,branch
    ),BSA as (
        select distinct Client_ID,B.CUTOFFDATE,B.BRANCH from ANL.SPOT_STAMMDATEN_CURRENT as B
        where B.BRANCH = 'NL03'

    ),data as (

        select distinct
            A.BORROWERID as CLIENT_ID
            ,'NLB' as INSTITUTE_CLIENT
            ,'NLB' as INSTITUTE_ACCOUNT
            ,A.BORROWERNAME as CLIENT_NAME
            ,A.CUSTOMERSEGMENT
            ,A.LEGALFORM
            ,ZO.KONZERN_NR
            ,ZO.KONZERN_BEZ
            ,EK.ELEKTRON_ADR as E_MAIL_ADRESS_MAIN
            ,A.COUNTRY as COUNTRY_AS_LEGI_DOK
            ,A.PLZ as ZIP_AS_LEGI_DOK
            ,A.ORT as CITY_AS_LEGI_DOK
            ,A.STRASSE as STREET_AS_LEGI_DOK
            ,NULL as NBR_AS_LEGI_DOK
            ,A.PERSONTYPE
            ,A.KUSY_20 as KUSYMA_20
            ,A.NACE as NACE
            ,A.OE_BEZEICHNUNG
            ,A.OE_NR as OE_NR_OSP
            ,C.RATING_ID
            ,C.SUB_SEGMENT
            ,'MUREX' Produced_By
            ,case when Year(CLIENT_SCINCE_AT_LEAST_DATE) < year(A.CUTOFFDATE) then 'N' else 'Y' end as ORIGINATION_2020
            ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
            ,A.CUTOFFDATE as CUT_OFF_DATE
        from NLB.IWHS_KUNDE as A
        left join MAP.TABLE_BW_KENNZAHLEN_NLB_CURRENT as AA on AA.ZM_IDNUM=A.BORROWERID and A.CUTOFFDATE=AA.CUT_OFF_DATE
        left join NLB.DERIVATE_FACILITY_ID_MUREX_ID_MAPPING as M on M.FACILITY_ID=AA.FACILITY_ID
        left join (select CUTOFFDATE,COMPONENT_REFERENCE from NLB.MUREX_ZDBLCUR union all select CUTOFFDATE,COMPONENT_REFERENCE from NLB.MUREX_ZDIRDBL) as B on M.MUREX_ID=B.COMPONENT_REFERENCE and A.CUTOFFDATE=B.CUTOFFDATE
        left join NLB.KN_KNE as ZO on ZO.KND_NR = A.BORROWERID and A.CUTOFFDATE=ZO.CUTOFFDATE
        left join NLB.SPOT_RATING_GESCHAEFTSPARTNER as C on C.GP_NR = A.BORROWERID and C.CUT_OFF_DATE=A.CUTOFFDATE
        left join Client_Since as CS on CS.BORROWERID=A.BORROWERID and CS.BRANCH=A.BRANCH
        left join NLB.IWHS_EMAIL_KUNDE as EK on EK.PERSONEN_NR=A.BORROWERID and EK.CUTOFFDATE=A.CUTOFFDATE
        --left join DPK.TRAIN_BASIS as TB on TB.TS_STAND=A.CUTOFFDATE and TB.INSTITUT = '009' and TB.PERSONEN_NR=A.BORROWERID
        left join BSA as BSA on BSA.CLIENT_ID=A.BORROWERID and A.CUTOFFDATE=BSA.CUTOFFDATE
        where 1=1
            and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
            and B.CUTOFFDATE in ('31.12.2020','30.09.2020')
            and coalesce(A.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H')
        union

        select distinct
            A.BORROWERID as CLIENT_ID
            ,A.BRANCH as INSTITUTE_CLIENT
            ,B.BRANCH as INSTITUTE_ACCOUNT
            ,A.BORROWERNAME as CLIENT_NAME
            ,A.CUSTOMERSEGMENT
            ,A.LEGALFORM
            ,ZO.KONZERN_NR
            ,ZO.KONZERN_BEZ
            ,EK.ELEKTRON_ADR as E_MAIL_ADRESS_MAIN
            ,A.COUNTRY as COUNTRY_AS_LEGI_DOK
            ,A.PLZ as ZIP_AS_LEGI_DOK
            ,A.ORT as CITY_AS_LEGI_DOK
            ,A.STRASSE as STREET_AS_LEGI_DOK
            ,NULL as HAUS_NR
            ,A.PERSONTYPE
            ,A.KUSY_20 as KUSYMA_20
            ,A.NACE as NACE
            ,A.OE_BEZEICHNUNG
            ,A.OE_NR as OE_NR_OSP
            ,C.RATING_ID
            ,C.SUB_SEGMENT
            ,'SPOT' Produced_By
            ,case when Year(CLIENT_SCINCE_AT_LEAST_DATE) < year(A.CUTOFFDATE) then 'N' else 'Y' end as ORIGINATION_2020
            ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
            ,A.CUTOFFDATE as CUT_OFF_DATE
        from NLB.IWHS_KUNDE as A
        left join NLB.SPOT_STAMMDATEN as B on A.BORROWERID=B.CLIENT_ID and A.CUTOFFDATE=B.CUTOFFDATE
        left join NLB.KN_KNE as ZO on ZO.KND_NR = A.BORROWERID and A.CUTOFFDATE=ZO.CUTOFFDATE
        left join NLB.SPOT_RATING_GESCHAEFTSPARTNER as C on C.GP_NR = A.BORROWERID and C.CUT_OFF_DATE=A.CUTOFFDATE
        left join Client_Since as CS on CS.BORROWERID=A.BORROWERID and CS.BRANCH=A.BRANCH
        left join NLB.IWHS_EMAIL_KUNDE as EK on EK.PERSONEN_NR=A.BORROWERID and EK.CUTOFFDATE=A.CUTOFFDATE
        left join BSA as BSA on BSA.CLIENT_ID=A.BORROWERID and A.CUTOFFDATE=BSA.CUTOFFDATE
        --left join DPK.TRAIN_BASIS as TB on TB.TS_STAND=A.CUTOFFDATE and TB.INSTITUT = '009' and TB.PERSONEN_NR=A.BORROWERID
        where 1=1
            and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
            and coalesce(A.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H')
        union
        select distinct
            A.BORROWERID as CLIENT_ID
            ,A.BRANCH as INSTITUTE_CLIENT
            ,B.BRANCH as INSTITUTE_ACCOUNT
            ,A.BORROWERNAME as CLIENT_NAME
            ,A.CUSTOMERSEGMENT
            ,A.LEGALFORM
            ,ZO.KONZERN_NR
            ,ZO.KONZERN_BEZ
            ,EK.ELEKTRON_ADR as E_MAIL_ADRESS_MAIN
            ,A.COUNTRY as COUNTRY_AS_LEGI_DOK
            ,A.PLZ as ZIP_AS_LEGI_DOK
            ,A.ORT as CITY_AS_LEGI_DOK
            ,A.STRASSE as STREET_AS_LEGI_DOK
            ,NULL as HAUS_NR
            ,A.PERSONTYPE
            ,A.KUSY_20 as KUSYMA_20
            ,A.NACE as NACE
            ,A.OE_BEZEICHNUNG
            ,A.OE_NR as OE_NR_OSP
            ,C.RATING_ID
            ,C.SUB_SEGMENT
            ,'SPOT' Produced_By
            ,case when Year(CLIENT_SCINCE_AT_LEAST_DATE) < year(A.CUTOFFDATE) then 'N' else 'Y' end as ORIGINATION_2020
            ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
            ,A.CUTOFFDATE as CUT_OFF_DATE
        from NLB.IWHS_KUNDE as A
        left join ANL.SPOT_STAMMDATEN as B on A.BORROWERID=B.CLIENT_ID and A.CUTOFFDATE=B.CUTOFFDATE
        left join ANL.KN_KNE as ZO on ZO.KND_NR = A.BORROWERID and A.CUTOFFDATE=ZO.CUTOFFDATE
        left join NLB.SPOT_RATING_GESCHAEFTSPARTNER as C on C.GP_NR = A.BORROWERID and C.CUT_OFF_DATE=A.CUTOFFDATE
        left join Client_Since as CS on CS.BORROWERID=A.BORROWERID and CS.BRANCH=A.BRANCH
        left join NLB.IWHS_EMAIL_KUNDE as EK on EK.PERSONEN_NR=A.BORROWERID and EK.CUTOFFDATE=A.CUTOFFDATE
        --left join DPK.TRAIN_BASIS as TB on TB.TS_STAND=A.CUTOFFDATE and TB.INSTITUT = '009' and TB.PERSONEN_NR=A.BORROWERID
        left join BSA as BSA on BSA.CLIENT_ID=A.BORROWERID and A.CUTOFFDATE=BSA.CUTOFFDATE
        where 1=1
            and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
            and coalesce(A.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H')
        union
        select distinct
                A.BORROWERID as CLIENT_ID
                ,A.BRANCH as INSTITUTE_CLIENT
                ,B.BRANCH as INSTITUTE_ACCOUNT
                ,A.BORROWERNAME as CLIENT_NAME
                ,A.CUSTOMERSEGMENT
                ,A.LEGALFORM
                ,ZO.KONZERN_NR
                ,ZO.KONZERN_BEZ
                ,EK.ELEKTRON_ADR as E_MAIL_ADRESS_MAIN
                ,A.COUNTRY as COUNTRY_AS_LEGI_DOK
                ,A.PLZ as ZIP_AS_LEGI_DOK
                ,A.ORT as CITY_AS_LEGI_DOK
                ,A.STRASSE as STREET_AS_LEGI_DOK
                ,NULL AS HAUS_NR
                ,A.PERSONTYPE
                ,A.KUSY_20 as KUSYMA_20
                ,A.NACE as NACE
                ,A.OE_BEZEICHNUNG
                ,A.OE_NR as OE_NR_OSP
                ,C.RATING_ID
                ,C.SUB_SEGMENT
                ,'SPOT' Produced_By
                ,case when Year(CLIENT_SCINCE_AT_LEAST_DATE) < year(A.CUTOFFDATE) then 'N' else 'Y' end as ORIGINATION_2020
                ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
                ,A.CUTOFFDATE as CUT_OFF_DATE
        from BLB.IWHS_KUNDE as A
        left join BLB.SPOT_STAMMDATEN as B on A.BORROWERID=B.CLIENT_ID and A.CUTOFFDATE=B.CUTOFFDATE
        left join BLB.KN_KNE as ZO on ZO.KND_NR = A.BORROWERID and A.CUTOFFDATE=ZO.CUTOFFDATE
        left join BLB.SPOT_RATING_GESCHAEFTSPARTNER as C on C.GP_NR = A.BORROWERID and C.CUT_OFF_DATE=A.CUTOFFDATE
        left join Client_Since as CS on CS.BORROWERID=A.BORROWERID and CS.BRANCH=A.BRANCH
        left join BLB.IWHS_EMAIL_KUNDE as EK on EK.PERSONEN_NR=A.BORROWERID and EK.CUTOFFDATE=A.CUTOFFDATE
        --left join DPK.TRAIN_BASIS as TB on TB.TS_STAND=A.CUTOFFDATE and TB.INSTITUT = '004' and TB.PERSONEN_NR=A.BORROWERID
        left join BSA as BSA on BSA.CLIENT_ID=A.BORROWERID and A.CUTOFFDATE=BSA.CUTOFFDATE
        where 1=1
            and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
            and coalesce(A.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
            --and A.BORROWERID = '1686'
        )
    /*
        select distinct CLIENT_ID, INSTITUTE_CLIENT, listagg(INSTITUTE_ACCOUNT,',') over (partition by CLIENT_ID,INSTITUTE_CLIENT)as INSTITUTE_ACCOUNT, CLIENT_NAME,CUSTOMERSEGMENT
            ,LEGALFORM,KONZERN_NR,KONZERN_BEZ,E_MAIL_ADRESS_MAIN, COUNTRY_AS_LEGI_DOK, ZIP_AS_LEGI_DOK, CITY_AS_LEGI_DOK, STREET_AS_LEGI_DOK, NBR_AS_LEGI_DOK, PERSONTYPE, KUSYMA_20, OE_BEZEICHNUNG, OE_NR_OSP, RATING_ID, SUB_SEGMENT
                  , listagg(Produced_By,'|')  over (partition by CLIENT_ID,INSTITUTE_CLIENT)  as Produced_By
                  ,'IWHS' as CLIENT_INFORMATION_FROM
                  , ORIGINATION_2020, BSA_RELEVANT, CUTOFFDATE
    from
                */
        (

        select distinct * from DATA
    )
;

-- Tabelle erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_CURRENT select * from MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT;

------------------------------------------------------------------------------------------------------------------------
-- Distinct View -------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT as
    select distinct CLIENT_ID, INSTITUTE_CLIENT,INSTITUTE_ACCOUNT, CLIENT_NAME,CUSTOMERSEGMENT
            ,LEGALFORM,KONZERN_NR,KONZERN_BEZ,E_MAIL_ADRESS_MAIN, COUNTRY_AS_LEGI_DOK, ZIP_AS_LEGI_DOK, CITY_AS_LEGI_DOK, STREET_AS_LEGI_DOK, NBR_AS_LEGI_DOK, PERSONTYPE, KUSYMA_20,NACE, OE_BEZEICHNUNG, OE_NR_OSP, RATING_ID, SUB_SEGMENT
                  , listagg(Produced_By,'|')  over (partition by CLIENT_ID,INSTITUTE_CLIENT,CUT_OFF_DATE)  as Produced_By
                  ,'IWHS' as CLIENT_INFORMATION_FROM
                  , ORIGINATION_2020, BSA_RELEVANT, CUT_OFF_DATE
    from (
        select distinct CLIENT_ID, INSTITUTE_CLIENT, listagg(INSTITUTE_ACCOUNT,',') over (partition by CLIENT_ID,INSTITUTE_CLIENT,CUT_OFF_DATE)as INSTITUTE_ACCOUNT, CLIENT_NAME,CUSTOMERSEGMENT
                ,LEGALFORM,KONZERN_NR,KONZERN_BEZ,E_MAIL_ADRESS_MAIN, COUNTRY_AS_LEGI_DOK, ZIP_AS_LEGI_DOK, CITY_AS_LEGI_DOK, STREET_AS_LEGI_DOK, NBR_AS_LEGI_DOK, PERSONTYPE, KUSYMA_20,NACE, OE_BEZEICHNUNG, OE_NR_OSP, RATING_ID, SUB_SEGMENT
                      ,Produced_By
                      , ORIGINATION_2020, BSA_RELEVANT, CUT_OFF_DATE
        from (
            select distinct CLIENT_ID, INSTITUTE_CLIENT,INSTITUTE_ACCOUNT, CLIENT_NAME,CUSTOMERSEGMENT
                    ,LEGALFORM,KONZERN_NR,KONZERN_BEZ,E_MAIL_ADRESS_MAIN, COUNTRY_AS_LEGI_DOK, ZIP_AS_LEGI_DOK, CITY_AS_LEGI_DOK, STREET_AS_LEGI_DOK, NBR_AS_LEGI_DOK, PERSONTYPE, KUSYMA_20,NACE
                          , FIRST_VALUE(OE_BEZEICHNUNG) over (PARTITION by CLIENT_ID, INSTITUTE_CLIENT,CUT_OFF_DATE order by OE_NR_OSP desc) as OE_BEZEICHNUNG
                          , MAX(OE_NR_OSP) over (PARTITION by CLIENT_ID, INSTITUTE_CLIENT,CUT_OFF_DATE) as OE_NR_OSP
                          , RATING_ID, SUB_SEGMENT
                          , Produced_By
                          , ORIGINATION_2020, BSA_RELEVANT, CUT_OFF_DATE
            from MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_CURRENT
        )
         )
;

-- Tabelle erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT_CURRENT select * from MAP.VIEW_KPMG_ANFORDERUNG_BMO_CLIENT_DISTINCT;
