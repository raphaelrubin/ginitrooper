------------------------------------------------------------------------------------------------------------------------
-- FINISH VIEW ---------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT as
with BSA as (
    select distinct Client_ID,B.CUTOFFDATE,B.BRANCH from ANL.SPOT_STAMMDATEN as B
    where B.BRANCH = 'NL03' and B.CUTOFFDATE in ('31.12.2020','30.09.2020')

),BALANCE_SHEET_ITEM as (
  select distinct first_value(left(CS_ITEM,7) || 'XXX') over(partition by ZM_PRODID,CUTOFFDATE order by THE_ORDER ASC) as CS_ITEM,ZM_PRODID,CUTOFFDATE from (
    select distinct
                    CS_ITEM,ZM_PRODID,ZM_KFSEM,CUTOFFDATE
            ,case
                when ZM_KFSEM = '_KORELT' then 1
                when ZM_KFSEM = '_KOACIN' then 2
                when ZM_KFSEM = 'A_KAC262' then 3
                when ZM_KFSEM = 'A_KAC256' then 4
                when ZM_KFSEM = 'A_KAC671' then 5
                when ZM_KFSEM = 'A_RIVOO' then 6
                when ZM_KFSEM = 'A_RIVO' then 7
                when ZM_KFSEM = 'A_RIVOAO' then 8
                when ZM_KFSEM = 'A_RIVOZO' then 9
                when ZM_KFSEM = '_KOTFSR' then 10
                when ZM_KFSEM = '_KAVAFV' then 11
                when ZM_KFSEM = '_KOPICA' then 12
                when ZM_KFSEM = '_KOPICO' then 13

                --when ZM_KFSEM = '' then 1
                else 99
            end as the_order
    from ANL.BW_ZBC_IFRS as IFRS where 1=1
        and (left(CS_ITEM,1) in ('1','2','4') or substr(CS_ITEM, 1, 8) in ('96100005','96200005','96300005') or CS_ITEM in ('9011103004','9011104004','9011109004','9021003004','9021004004','9021009004') )
        and ZM_KFSEM not in ('&55QUANT','&55TEVR') and ZM_RLSTD = 'I'
        and YEAR(IFRS.CUTOFFDATE) >= 2019
        and IFRS.CUTOFFDATE in ('31.12.2020','30.09.2020')
        and coalesce(ZM_STAKOR,'ALPAKA') not in ('E','Z')
    ) where ZM_KFSEM in ('_KORELT','_KOACIN','_KOPICA','_KOPICO','A_KAC671','A_KAC262','A_KAC256','A_RIVOO','A_RIVOAO','A_RIVOZO','_KAVAFV','_KOTFSR','A_RIVO')
    union all
    select distinct first_value(left(CS_ITEM,7) || 'XXX') over(partition by ZM_PRODID,CUTOFFDATE order by the_order asc) as CS_ITEM,ZM_PRODID,CUTOFFDATE from (
    select distinct
                    CS_ITEM,ZM_PRODID,ZM_KFSEM,CUTOFFDATE
            ,case
                when ZM_KFSEM = '_KORELT' then 1
                when ZM_KFSEM = '_KOACIN' then 2
                when ZM_KFSEM = 'A_KAC262' then 3
                when ZM_KFSEM = 'A_KAC256' then 4
                when ZM_KFSEM = 'A_KAC671' then 5
                when ZM_KFSEM = 'A_RIVOO' then 6
                when ZM_KFSEM = 'A_RIVO' then 7
                when ZM_KFSEM = 'A_RIVOAO' then 8
                when ZM_KFSEM = 'A_RIVOZO' then 9
                when ZM_KFSEM = '_KOTFSR' then 10
                when ZM_KFSEM = '_KAVAFV' then 11
                when ZM_KFSEM = '_KOPICA' then 12
                when ZM_KFSEM = '_KOPICO' then 13
                --when ZM_KFSEM = '' then 1
                else 99
            end as the_order
    from NLB.BW_ZBC_IFRS as IFRS where 1=1
        and (left(CS_ITEM,1) in ('1','2','4') or substr(CS_ITEM, 1, 8) in ('96100005','96200005','96300005') or CS_ITEM in ('9011103004','9011104004','9011109004','9021003004','9021004004','9021009004') )
        and ZM_KFSEM not in ('&55QUANT','&55TEVR') and ZM_RLSTD = 'I'
        and YEAR(IFRS.CUTOFFDATE) >= 2019
        and coalesce(ZM_STAKOR,'ALPAKA') not in ('E','Z')
        and IFRS.CUTOFFDATE in ('31.12.2020','30.09.2020')
    ) where ZM_KFSEM in ('_KORELT','_KOACIN','_KOPICA','_KOPICO','A_KAC671','A_KAC262','A_KAC256','A_RIVOO','A_RIVOAO','A_RIVOZO','_KAVAFV','_KOTFSR','A_RIVO')
    union all
    select distinct first_value(left(CS_ITEM,7) || 'XXX') over(partition by ZM_PRODID,CUTOFFDATE order by the_order asc) as CS_ITEM,ZM_PRODID,CUTOFFDATE from (
    select distinct
                    CS_ITEM,ZM_PRODID,ZM_KFSEM,CUTOFFDATE
            ,case
                when ZM_KFSEM = '_KORELT' then 1
                when ZM_KFSEM = '_KOACIN' then 2
                when ZM_KFSEM = 'A_KAC262' then 3
                when ZM_KFSEM = 'A_KAC256' then 4
                when ZM_KFSEM = 'A_KAC671' then 5
                when ZM_KFSEM = 'A_RIVOO' then 6
                when ZM_KFSEM = 'A_RIVO' then 7
                when ZM_KFSEM = 'A_RIVOAO' then 8
                when ZM_KFSEM = 'A_RIVOZO' then 9
                when ZM_KFSEM = '_KOTFSR' then 10
                when ZM_KFSEM = '_KAVAFV' then 11
                when ZM_KFSEM = '_KOPICA' then 12
                when ZM_KFSEM = '_KOPICO' then 13
                --when ZM_KFSEM = '' then 1
                else 99
            end as the_order
    from BLB.BW_ZBC_IFRS as IFRS where 1=1
        and (left(CS_ITEM,1) in ('1','2','4') or substr(CS_ITEM, 1, 8) in ('96100005','96200005','96300005') or CS_ITEM in ('9011103004','9011104004','9011109004','9021003004','9021004004','9021009004') )
        and ZM_KFSEM not in ('&55QUANT','&55TEVR') and ZM_RLSTD = 'I'
        and YEAR(IFRS.CUTOFFDATE) >= 2019
        and coalesce(ZM_STAKOR,'ALPAKA') not in ('E','Z')
        and IFRS.CUTOFFDATE in ('31.12.2020','30.09.2020')
    ) where ZM_KFSEM in ('_KORELT','_KOACIN','_KOPICA','_KOPICO','A_KAC671','A_KAC262','A_KAC256','A_RIVOO','A_RIVOAO','A_RIVOZO','_KAVAFV','_KOTFSR','A_RIVO')
)
select
    A.CUTOFFDATE as CUT_OFF_DATE
     ,A.CLIENT_ID
     ,'NLB' as BRANCH_CLIENT
     ,A.FACILITY_ID
     ,NULL as MUREX_COMPONENT_REFERENCE
     ,NULL as MUREX_CONTRACT_REFERENCE
     ,A.BRANCH
     ,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'Y' else 'N' end as KONSORTIALGESCHAEFT
     ,coalesce(SYNDICATIONROLE,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'KONSORTIALFUEHER' else 'ALLEINGESCHAEFT' end) as SYNDICATION_ROLE
    ,A.CURRENTCONTRACTUALMATURITYDATE
    ,A.MATURITYDATE
    ,KR.EAD_TOTAL_EUR
    ,KR.FREIE_LINIE
    ,A.PRINCIPALOUTSTANDING_EUR
     ,A.PRINCIPALOUTSTANDING_EUR*CMAP.KURS as PRINCIPALOUTSTANDING_WAEHRUNG
    ,BSI.CS_ITEM as Balance_Sheet_ITEM
    --,'Nicht Freigegeben' as Balance_Sheet_ITEM_KORELT
    ,A.CO_PROD_SCHL as PRODUCT_KEY
    ,coalesce(B.DKTO_RATING_ID,B.DIGP_RATING_ID,B.RH_RATING_ID) as RATING_ID
    ,case when BWK.FACILITY_ID is null then NULL else  coalesce(RIVO_STAGE_1_EUR,0) + coalesce(RIVO_STAGE_2_EUR,0)+coalesce(RIVO_STAGE_3_EUR,0)+coalesce(RIVO_STAGE_POCI_EUR,0) end  as LLP_EUR
    --,'NICHT Freigegeben' as LLP_EUR
    ,A.ACCOUNT_CURRENCY
     ,CMAP.KURS as WECHSELKURS
    ,'NICHT VORHANDEN' as MONEY_LAUDRY_CLASS
    ,case when Year(A.ORIGINATIONDATE) = year(A.CUTOFFDATE) then 'Y' else 'N' end as ORIGINATION_2020
    ,coalesce(case when A.LOANSTATE in ('INAKTIV','I_VOR_GESC') then 'N' else 'Y' end,'Y') as CURRENT_BUSINESS_RELATION
    ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
    ,'SPOT' as ACCOUNT_INFROMATION_FROM
    ,case
        when COALESCE(KK.OE_BEZEICHNUNG,'AAA') in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
        then 'Y' else 'N'
    end as MA
from NLB.SPOT_STAMMDATEN as A
left join NLB.SPOT_RATING_KONTO as B on A.CUTOFFDATE=B.CUT_OFF_DATE and A.FACILITY_ID=B.BWLKEY
left join MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_NLB_CURRENT as KR on KR.FACILITY_ID = A.FACILITY_ID and A.CUTOFFDATE=KR.CUT_OFF_DATE
left join BALANCE_SHEET_ITEM as BSI on BSI.CUTOFFDATE=A.CUTOFFDATE and BSI.ZM_PRODID=A.FACILITY_ID
left join MAP.TABLE_BW_KENNZAHLEN_NLB_CURRENT as BWK on BWK.FACILITY_ID=A.FACILITY_ID and BWK.CUT_OFF_DATE=A.CUTOFFDATE
inner join NLB.IWHS_KUNDE as KK on KK.CUTOFFDATE=A.CUTOFFDATE and KK.BORROWERID=A.CLIENT_ID
left join BSA as BSA on BSA.CLIENT_ID=A.CLIENT_ID and A.CUTOFFDATE=BSA.CUTOFFDATE
left join IMAP.CURRENCY_MAP as CMAP on CMAP.CUT_OFF_DATE = A.CUTOFFDATE and CMAP.ZIEL_WHRG=A.ACCOUNT_CURRENCY
where 1=1
    --and coalesce(KK.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
    and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
union all
select
    A.CUTOFFDATE as CUT_OFF_DATE
     ,A.CLIENT_ID
     ,'BLB' as BRANCH_CLIENT
     ,A.FACILITY_ID
     ,NULL as MUREX_COMPONENT_REFERENCE
     ,NULL as MUREX_CONTRACT_REFERENCE
     ,A.BRANCH
     ,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'Y' else 'N' end as KONSORTIALGESCHAEFT
     ,coalesce(SYNDICATIONROLE,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'KONSORTIALFUEHER' else 'ALLEINGESCHAEFT' end) as SYNDICATION_ROLE
    ,A.CURRENTCONTRACTUALMATURITYDATE
    ,A.MATURITYDATE
    ,KR.EAD_TOTAL_EUR
    ,KR.FREIE_LINIE
    ,A.PRINCIPALOUTSTANDING_EUR
    ,A.PRINCIPALOUTSTANDING_EUR*CMAP.KURS as PRINCIPALOUTSTANDING_WAEHRUNG
    ,BSI.CS_ITEM as Balance_Sheet_ITEM_KORELT
    --,'Nicht Freigegeben' as Balance_Sheet_ITEM_KORELT
    ,A.CO_PROD_SCHL as PRODUCT_KEY
    ,coalesce(B.DKTO_RATING_ID,B.DIGP_RATING_ID,B.RH_RATING_ID) as RATING_ID
    ,case when BWK.FACILITY_ID is null then NULL else  coalesce(RIVO_STAGE_1_EUR,0) + coalesce(RIVO_STAGE_2_EUR,0)+coalesce(RIVO_STAGE_3_EUR,0)+coalesce(RIVO_STAGE_POCI_EUR,0) end  as LLP_EUR
    --,'NICHT Freigegeben' as LLP_EUR
    ,A.ACCOUNT_CURRENCY
     ,CMAP.KURS as WECHSELKURS
    ,'NICHT VORHANDEN' as MONEY_LAUDRY_CLASS
    ,case when Year(A.ORIGINATIONDATE) = year(A.CUTOFFDATE) then 'Y' else 'N' end as ORIGINATION_2020
    ,coalesce(case when A.LOANSTATE in ('INAKTIV','I_VOR_GESC') then 'N' else 'Y' end,'Y') as CURRENT_BUSINESS_RELATION
    ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
    ,'SPOT' as ACCOUNT_INFROMATION_FROM
    ,case
        when COALESCE(KK.OE_BEZEICHNUNG,'AAA') in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
        then 'Y' else 'N'
    end as MA
from BLB.SPOT_STAMMDATEN as A
left join BLB.SPOT_RATING_KONTO as B on A.CUTOFFDATE=B.CUT_OFF_DATE and A.FACILITY_ID=B.BWLKEY
left join MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_BLB_CURRENT as KR on KR.FACILITY_ID = A.FACILITY_ID and A.CUTOFFDATE=KR.CUT_OFF_DATE
left join BALANCE_SHEET_ITEM as BSI on BSI.CUTOFFDATE=A.CUTOFFDATE and BSI.ZM_PRODID=A.FACILITY_ID
left join MAP.TABLE_BW_KENNZAHLEN_BLB_CURRENT as BWK on BWK.FACILITY_ID=A.FACILITY_ID and BWK.CUT_OFF_DATE=A.CUTOFFDATE
inner join BLB.IWHS_KUNDE as KK on KK.CUTOFFDATE=A.CUTOFFDATE and KK.BORROWERID=A.CLIENT_ID
left join BSA as BSA on BSA.CLIENT_ID=A.CLIENT_ID and A.CUTOFFDATE=BSA.CUTOFFDATE
left join IMAP.CURRENCY_MAP as CMAP on CMAP.CUT_OFF_DATE = A.CUTOFFDATE and CMAP.ZIEL_WHRG=A.ACCOUNT_CURRENCY
where 1=1
    --and coalesce(KK.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
    and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
union all
select
    A.CUTOFFDATE as CUT_OFF_DATE
     ,A.CLIENT_ID
     ,'NLB' as BRANCH_CLIENT
     ,A.FACILITY_ID
     ,NULL as MUREX_COMPONENT_REFERENCE
     ,NULL as MUREX_CONTRACT_REFERENCE
     ,A.BRANCH
     ,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'Y' else 'N' end as KONSORTIALGESCHAEFT
     ,coalesce(SYNDICATIONROLE,case when coalesce(A.OWNSYNDICATEQUOTA,100) not in (0,100) then 'KONSORTIALFUEHER' else 'ALLEINGESCHAEFT' end) as SYNDICATION_ROLE
    ,A.CURRENTCONTRACTUALMATURITYDATE
    ,A.MATURITYDATE
    ,KR.EAD_TOTAL_EUR
    ,KR.FREIE_LINIE
    ,A.PRINCIPALOUTSTANDING_EUR
    ,A.PRINCIPALOUTSTANDING_EUR*CMAP.KURS as PRINCIPALOUTSTANDING_WAEHRUNG
    ,BSI.CS_ITEM as Balance_Sheet_ITEM_KORELT
    --,'Nicht Freigegeben' as Balance_Sheet_ITEM_KORELT
    ,A.CO_PROD_SCHL as PRODUCT_KEY
    ,coalesce(B.DKTO_RATING_ID,B.DIGP_RATING_ID,B.RH_RATING_ID) as RATING_ID
    ,case when BWK.FACILITY_ID is null then NULL else  coalesce(RIVO_STAGE_1_EUR,0) + coalesce(RIVO_STAGE_2_EUR,0)+coalesce(RIVO_STAGE_3_EUR,0)+coalesce(RIVO_STAGE_POCI_EUR,0) end  as LLP_EUR
    --,'NICHT Freigegeben' as LLP_EUR
    ,A.ACCOUNT_CURRENCY
    ,CMAP.KURS as WECHSELKURS
    ,'NICHT VORHANDEN' as MONEY_LAUDRY_CLASS
    ,case when Year(A.ORIGINATIONDATE) = year(A.CUTOFFDATE) then 'Y' else 'N' end as ORIGINATION_2020
    ,coalesce(case when A.LOANSTATE in ('INAKTIV','I_VOR_GESC') then 'N' else 'Y' end,'Y') as CURRENT_BUSINESS_RELATION
    ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
    ,'SPOT' as ACCOUNT_INFROMATION_FROM
    ,case
        when COALESCE(KK.OE_BEZEICHNUNG,'AAA') in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
        then 'Y' else 'N'
    end as MA
from ANL.SPOT_STAMMDATEN as A
left join ANL.SPOT_RATING_KONTO as B on A.CUTOFFDATE=B.CUT_OFF_DATE and A.FACILITY_ID=B.BWLKEY
left join MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_ANL_CURRENT as KR on KR.FACILITY_ID = A.FACILITY_ID and A.CUTOFFDATE=KR.CUT_OFF_DATE
left join BALANCE_SHEET_ITEM as BSI on BSI.CUTOFFDATE=A.CUTOFFDATE and BSI.ZM_PRODID=A.FACILITY_ID
left join MAP.TABLE_BW_KENNZAHLEN_ANL_CURRENT as BWK on BWK.FACILITY_ID=A.FACILITY_ID and BWK.CUT_OFF_DATE=A.CUTOFFDATE
inner join NLB.IWHS_KUNDE as KK on KK.CUTOFFDATE=A.CUTOFFDATE and KK.BORROWERID=A.CLIENT_ID
left join BSA as BSA on BSA.CLIENT_ID=A.CLIENT_ID and A.CUTOFFDATE=BSA.CUTOFFDATE
left join IMAP.CURRENCY_MAP as CMAP on CMAP.CUT_OFF_DATE = A.CUTOFFDATE and CMAP.ZIEL_WHRG=A.ACCOUNT_CURRENCY
where 1=1
    --and coalesce(KK.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H')
    and A.CUTOFFDATE in ('31.12.2020','30.09.2020')
    union all
select
    A.CUTOFFDATE as CUT_OFF_DATE
     ,BWK.ZM_IDNUM
     ,'NLB' as BRANCH_CLIENT
     ,AA.FACILITY_ID
     ,A.COMPONENT_REFERENCE
     ,A.CONTRACT_REFERENCE
     ,A.BRANCH
     ,'N' as KONSORTIALGESCHAEFT
     ,'ALLEINGESCHAEFT' as SYNDICATION_ROLE
    ,NULL as CURRENTCONTRACTUALMATURITYDATE
    ,MAX(A.MATURITY_DATE) over (Partition by A.CUTOFFDATE,AA.FACILITY_ID)
    ,KR.EAD_TOTAL_EUR
    ,KR.FREIE_LINIE
    ,SUM(A.MARKET_VALUE) over (Partition by A.CUTOFFDATE,AA.FACILITY_ID)
    ,NULL as PRINCIPALOUTSTANDING_WAEHRUNG
    ,BSI.CS_ITEM as Balance_Sheet_ITEM_KORELT
    --,'Nicht Freigegeben' as Balance_Sheet_ITEM_KORELT
    ,BWK.ZM_PRKEY as PRODUCT_KEY
    ,coalesce(B.DKTO_RATING_ID,B.DIGP_RATING_ID,B.RH_RATING_ID) as RATING_ID
    ,case when BWK.FACILITY_ID is null then NULL else  coalesce(RIVO_STAGE_1_EUR,0) + coalesce(RIVO_STAGE_2_EUR,0)+coalesce(RIVO_STAGE_3_EUR,0)+coalesce(RIVO_STAGE_POCI_EUR,0) end  as LLP_EUR
    --,'NICHT Freigegeben' as LLP_EUR
    ,A.P_L_CURRENCY
     ,CMAP.KURS as WECHSELKURS
    ,'NICHT VORHANDEN' as MONEY_LAUDRY_CLASS
    ,case when Year(A.TRADE_DATE) = year(A.CUTOFFDATE) then 'Y' else 'N' end as ORIGINATION_2020
    ,'Y' as CURRENT_BUSINESS_RELATION
    ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
    ,'MUREX_BLCUR' as ACCOUNT_INFROMATION_FROM
    ,case
        when COALESCE(KK.OE_BEZEICHNUNG,'AAA') in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
        then 'Y' else 'N'
    end as MA
from NLB.MUREX_ZDBLCUR as A
inner join NLB.DERIVATE_FACILITY_ID_MUREX_ID_MAPPING as AA on AA.CUT_OFF_DATE=A.CUTOFFDATE and AA.MUREX_ID=A.COMPONENT_REFERENCE
left join NLB.SPOT_RATING_KONTO as B on A.CUTOFFDATE=B.CUT_OFF_DATE and AA.FACILITY_ID=B.BWLKEY
left join MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_NLB_CURRENT as KR on KR.FACILITY_ID = AA.FACILITY_ID and AA.CUT_OFF_DATE=KR.CUT_OFF_DATE
left join BALANCE_SHEET_ITEM as BSI on BSI.CUTOFFDATE=A.CUTOFFDATE and BSI.ZM_PRODID=AA.FACILITY_ID
left join MAP.TABLE_BW_KENNZAHLEN_NLB_CURRENT as BWK on BWK.FACILITY_ID=AA.FACILITY_ID and BWK.CUT_OFF_DATE=A.CUTOFFDATE
left join NLB.IWHS_KUNDE as KK on KK.CUTOFFDATE=A.CUTOFFDATE and KK.BORROWERID=BWK.ZM_IDNUM
left join BSA as BSA on BSA.CLIENT_ID=BWK.ZM_IDNUM and A.CUTOFFDATE=BSA.CUTOFFDATE
left join IMAP.CURRENCY_MAP as CMAP on CMAP.CUT_OFF_DATE = A.CUTOFFDATE and CMAP.ZIEL_WHRG=A.P_L_CURRENCY
--where COALESCE(KK.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H')

union all
select
    A.CUTOFFDATE as CUT_OFF_DATE
     ,BWK.ZM_IDNUM
     ,'NLB' as BRANCH_CLIENT
     ,AA.FACILITY_ID
     ,A.COMPONENT_REFERENCE
     ,A.CONTRACT_REFERENCE
     ,A.BRANCH
     ,'N' as KONSORTIALGESCHAEFT
     ,'ALLEINGESCHAEFT' as SYNDICATION_ROLE
    ,NULL as CURRENTCONTRACTUALMATURITYDATE
    ,MAX(A.MATURITY_DATE) over (Partition by A.CUTOFFDATE,AA.FACILITY_ID)
    ,KR.EAD_TOTAL_EUR
    ,KR.FREIE_LINIE
    ,SUM(A.MARKET_VALUE) over (Partition by A.CUTOFFDATE,AA.FACILITY_ID)
    ,NULL as PRINCIPALOUTSTANDING_WAEHRUNG
    ,BSI.CS_ITEM as Balance_Sheet_ITEM_KORELT
    --,'Nicht Freigegeben' as Balance_Sheet_ITEM_KORELT
    ,BWK.ZM_PRKEY as PRODUCT_KEY
    ,coalesce(B.DKTO_RATING_ID,B.DIGP_RATING_ID,B.RH_RATING_ID) as RATING_ID
    ,case when BWK.FACILITY_ID is null then NULL else  coalesce(RIVO_STAGE_1_EUR,0) + coalesce(RIVO_STAGE_2_EUR,0)+coalesce(RIVO_STAGE_3_EUR,0)+coalesce(RIVO_STAGE_POCI_EUR,0) end  as LLP_EUR
    --,'NICHT Freigegeben' as LLP_EUR
    ,A.P_L_CURRENCY
     ,CMAP.KURS as WECHSELKURS
    ,'NICHT VORHANDEN' as MONEY_LAUDRY_CLASS
    ,case when Year(A.TRADE_DATE) = year(A.CUTOFFDATE) then 'Y' else 'N' end as ORIGINATION_2020
    ,'Y' as CURRENT_BUSINESS_RELATION
    ,case when BSA.CLIENT_ID is not null then 'Y' else 'N' end as BSA_RELEVANT
    ,'MUREX_IRDBL' as ACCOUNT_INFROMATION_FROM
    ,case
        when COALESCE(KK.OE_BEZEICHNUNG,'AAA') in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
        then 'Y' else 'N'
    end as MA
from NLB.MUREX_ZDIRDBL as A
inner join NLB.DERIVATE_FACILITY_ID_MUREX_ID_MAPPING as AA on AA.CUT_OFF_DATE=A.CUTOFFDATE and AA.MUREX_ID=A.COMPONENT_REFERENCE
left join NLB.SPOT_RATING_KONTO as B on A.CUTOFFDATE=B.CUT_OFF_DATE and AA.FACILITY_ID=B.BWLKEY
left join MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_NLB_CURRENT as KR on KR.FACILITY_ID = AA.FACILITY_ID and A.CUTOFFDATE=KR.CUT_OFF_DATE
left join BALANCE_SHEET_ITEM as BSI on BSI.CUTOFFDATE=A.CUTOFFDATE and BSI.ZM_PRODID=AA.FACILITY_ID
left join MAP.TABLE_BW_KENNZAHLEN_NLB_CURRENT as BWK on BWK.FACILITY_ID=AA.FACILITY_ID and BWK.CUT_OFF_DATE=A.CUTOFFDATE
left join NLB.IWHS_KUNDE as KK on KK.CUTOFFDATE=A.CUTOFFDATE and KK.BORROWERID=BWK.ZM_IDNUM
left join BSA as BSA on BSA.CLIENT_ID=BWK.ZM_IDNUM and A.CUTOFFDATE=BSA.CUTOFFDATE
left join IMAP.CURRENCY_MAP as CMAP on CMAP.CUT_OFF_DATE = A.CUTOFFDATE and CMAP.ZIEL_WHRG=A.P_L_CURRENCY
--where COALESCE(KK.OE_BEZEICHNUNG,'AAA') not in ('Immo Mitarbeiter BS','Immo Mitarbeiter H','KSC MA-Gesch. DBE 61','KSC MA-Gesch.BLSK','Mitarbeitergesch. H','Mitarbeitergeschäfte','PB Mitarbeiter BS','PB Mitarbeiterge. H','Mitarbeitergeschäfte HB/OL')
;

-- Tabellen erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_CURRENT select * from MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT;


------------------------------------------------------------------------------------------------------------------------
-- DISTINCT VIEW -------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------
drop view MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT;
create or replace view MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT as 
    select distinct * from MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_CURRENT where coalesce(BSA_RELEVANT,'N') = 'N' and coalesce(MA,'N') = 'N'
;

-- Tabellen erstellen
drop table MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT_CURRENT;
create table MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT_CURRENT like MAP.VIEW_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT_CURRENT select * from MAP.TABLE_KPMG_ANFORDERUNG_BMO_ACCOUNT_DISTINCT_CURRENT


