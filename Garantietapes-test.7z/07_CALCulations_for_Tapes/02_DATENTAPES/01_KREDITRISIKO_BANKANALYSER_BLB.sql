-----------------------
----------KR-----------
-----------------------
drop view MAP.VIEW_KREDITRISIKO_BANKANALYSER_FULL_BLB;
create or replace view MAP.VIEW_KREDITRISIKO_BANKANALYSER_FULL_BLB as
with BASE as (
    --select BA.* from NLB.DLD_DR_IFRS as BA
        --union all
    select BA.* from BLB.DLD_DR_IFRS as BA
        --union all
    --select BA.* from ANL.DLD_DR_IFRS as BA
),AGGREGATE as (
    SELECT
                    CUT_OFF_DATE,
                    DLD_DR.BIC_XS_IDNUM AS CLIENT_ID_KR,
                    --PORTFOLIO,CLIENT_NO,
                    DLD_DR.BA1_C11EXTCON AS FACILITY_ID,
                    DLD_DR.BIC_XB_VBNR AS DBE,
                    DLD_DR.BIC_XS_CONTCU AS ORIGINAL_CURRENCY,
                    Sum(DLD_DR.BIC_E_FRELIN) AS FREIE_LINIE,
                    Sum(DLD_DR.BIC_E_INSPNA) AS PRINCIPAL_OUTSTANDING,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Sum(DLD_DR.BIC_E_FRELIN)>0 then Min(DLD_DR.BIC_B_CCFWER)
                        else Null
                    end AS CREDIT_CONVERSION_FACTOR,
                    ----------------------------------------------------------------------------------------------------
                    Sum(DLD_DR.BIC_E_EADANT) AS EAD_NON_SECURITIZED_EUR,
                    Sum(DLD_DR.BIC_E_EADAUS) AS EAD_SECURITIZED,
                    Sum(DLD_DR.BIC_E_EADANT)+Sum(DLD_DR.BIC_E_EADAUS) AS EAD_TOTAL_EUR,
                    Sum(DLD_DR.KSA_EXPOSURE) AS KSA_EXPOSURE_EUR,
                    Sum(DLD_DR.IRBA_EXPOSURE) AS IRBA_EXPOSURE_EUR,
                    Sum(DLD_DR.BIC_E_RWAAUS) AS RWA_SECURITIZED_EUR,
                    Sum(DLD_DR.BIC_E_BERANB) AS RWA_NON_SECURITIZED_EUR,
                    Sum(DLD_DR.BIC_E_BERANB)+Sum(DLD_DR.BIC_E_RWAAUS) AS RWA_TOTAL_EUR,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Sum(DLD_DR.BIC_E_EADANT)=0 then Max(DLD_DR.BIC_B_RWARM)
                        else Sum(DLD_DR.BIC_E_BERANB)/Sum(DLD_DR.BIC_E_EADANT)
                    end  AS RW_Non_Securitized,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when (Min(DLD_DR.BA_LCEAPPRL2)<3 And Max(DLD_DR.BA_LCEAPPRL2)<3) OR ( Sum(DLD_DR.KSA_EXPOSURE) >0 AND Sum(DLD_DR.IRBA_EXPOSURE) =0) then 'KSA / leeres IRBA Exposure'
                        when Max(DLD_DR.BA_LCEAPPRL2)>=3 AND Sum(DLD_DR.KSA_EXPOSURE) =0 AND Sum(DLD_DR.IRBA_EXPOSURE) >0 then 'IRBA / leeres KSA Exposure'
                        else 'Mischfall'
                    end  AS ANSATZ,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Min(DLD_DR.BA_LCEAPPRL2)<3 And Max(DLD_DR.BA_LCEAPPRL2)<3 then Null
                        else Max(DLD_DR.BIC_B_PDWERT)
                    end AS PD_MAX,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Min(DLD_DR.BA_LCEAPPRL2)<3 And Max(DLD_DR.BA_LCEAPPRL2)<3 then Null
                        else Sum(DLD_DR.BIC_E_EADANT*DLD_DR.BIC_B_PDWERT)
                    end AS EAD_X_PD,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Min(DLD_DR.BA_LCEAPPRL2)<3 And Max(DLD_DR.BA_LCEAPPRL2)<3 then Null
                        when Sum(DLD_DR.BIC_E_EADANT)=0 then Max(DLD_DR.BIC_B_PDWERT)
                        else Sum(DLD_DR.BIC_E_EADANT*DLD_DR.BIC_B_PDWERT)/Sum(DLD_DR.BIC_E_EADANT)
                    end AS PD_WEIGHTED,
                    ----------------------------------------------------------------------------------------------------
                    case
                        when Max(DLD_DR.BA_LZBBEWARM)>=91 then Null
                        else Max(DLD_DR.BA_LZBBEWARM)
                    end AS MAX_RATING,
                    ----------------------------------------------------------------------------------------------------
                    DLD_DR.BIC_XB_DAUSKZ AS SECURITISATION_FLAG,
                    DLD_DR.BIC_XX_PRKEY AS PRODUCT_TYPE_DETAIL
                    --Kunden.TransferPortfolio,
                    --Kunden.BorrowerID
    FROM
         (
        SELECT A.*,
         case when A.BA_LCEAPPRL2<=2 then A.BIC_E_EADANT else  0 end as KSA_EXPOSURE,
         case when A.BA_LCEAPPRL2>2 then A.BIC_E_EADANT else  0 end as IRBA_EXPOSURE
         from BASE as A
         ) AS DLD_DR
    GROUP BY CUT_OFF_DATE,
    DLD_DR.BIC_XS_IDNUM,
            -- ,PORTFOLIO,CLIENT_NO,
    DLD_DR.BA1_C11EXTCON,
    DLD_DR.BIC_XB_VBNR, DLD_DR.BIC_XS_CONTCU,
    DLD_DR.BIC_XB_DAUSKZ, DLD_DR.BIC_XX_PRKEY
)
select
    B.*
    ,C.ZM_PRODNR_TXT AS PRODUCT_TYPE_DETAIL_TXT
    ,C.ZM_PRODNR_CATEGORY AS PRODUCT_TYPE
    ,C.ZM_PRODNR_CATEGORY_TXT AS PRODUCT_TYPE_TXT
    ,D.Ausplatzierung
     ----------------------------------------------------------------------------------------------------
    ,case
        when ANSATZ='KSA / leeres IRBA Exposure' then Null
        else E.ALP_RATING
    end  AS RATINGKLASSE_IRBA
     ----------------------------------------------------------------------------------------------------
    ,case
        when ANSATZ='KSA / leeres IRBA Exposure' then Null
        else E.NUM_RATING
    end  AS RATINGSTUFE_IRBA
     ----------------------------------------------------------------------------------------------------
    ,case
        when ANSATZ='KSA / leeres IRBA Exposure' then RW.RATINGSTUFE
        else null
    end  AS RATINGSTUFE_KSA
     ----------------------------------------------------------------------------------------------------
    ,case
        when ANSATZ='KSA / leeres IRBA Exposure' then RW.RATINGKLASSE
        else null
    end  AS RATINGKLASSE_KSA
     ----------------------------------------------------------------------------------------------------
    ,case
        when PD_WEIGHTED >0.95 and MAX_RATING = 25 then '16'
        when PD_WEIGHTED >0.95 and MAX_RATING = 26 then '17'
        when PD_WEIGHTED >0.95 and MAX_RATING = 27 then '18'
        when ANSATZ='KSA / leeres IRBA Exposure' then RW.RATINGKLASSE
        else E.ALP_RATING
    end  AS INTERNAL_RATINGKLASSE
     ----------------------------------------------------------------------------------------------------
    ,case
            when PD_WEIGHTED>0.95 then  MAX_RATING
            when /*PD_WEIGHTED<=0.95 and*/ ANSATZ='KSA / leeres IRBA Exposure' then RW.RATINGSTUFE
            else E.NUM_RATING
     end AS INTERNAL_RATINGSTUFE
    ----------------------------------------------------------------------------------------------------
FROM AGGREGATE as B
LEFT JOIN  SMAP.KR_PRODUKTE_MAP as C ON B.PRODUCT_TYPE_DETAIL = C.ZM_PRODNR
LEFT JOIN SMAP.AUSPLATZIERUNG_MAP as D  ON B.SECURITISATION_FLAG =D.BIC_XB_DAUSKZ
LEFT JOIN SMAP.RATING_MAP as E ON (B.PD_WEIGHTED < E.PD_UBOUND) AND (B.PD_WEIGHTED >= E.PD_LBOUND)
LEFT JOIN SMAP.KR_RW_MAP as RW ON (B.RW_Non_Securitized >= RW.RW_LBOUND) AND (B.RW_Non_Securitized < RW.RW_UBOUND)
;

-- Tabelle erstellen
drop table MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_BLB_CURRENT;
create table MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_BLB_CURRENT like MAP.VIEW_KREDITRISIKO_BANKANALYSER_FULL_BLB;
-- ToDo: über LOAD-Befehl auszuführen
-- insert into MAP.TABLE_KREDITRISIKO_BANKANALYSER_FULL_BLB_CURRENT select * from MAP.VIEW_KREDITRISIKO_BANKANALYSER_FULL_BLB;