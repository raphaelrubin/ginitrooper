drop view CALC.AUTO_VIEW_CLIENTS_FOR_BW;
create or replace view CALC.AUTO_VIEW_CLIENTS_FOR_BW as
    with
    the_COD(THE_DATE) as (select MAX(COD) from CALC.AUTO_TABLE_CLIENTS_FOR_BW_DESIRED_COD ),
    /*
    the_COD(N,THE_DATE) as (
        select 1 , Date('2018-10-31') from SYSIBM.SYSDUMMY1
        union all
        select N+1 , Date('2018-10-31')+ n MONTH from the_COD
        where Date('2018-10-31') + N MONTH < Date(current_date )
    )
     */
    BGA_CLIENTS as (
        select distinct
            CLIENT_NO    as ZM_EXTNR,
            BRANCH_CLIENT as ZM_IDTYPE
        from BGA.TABLE_PORTFOLIO_DESIRED_CLIENTS_CURRENT
        where BRANCH_CLIENT <> 'CBB'
        union all
        select distinct
            CLIENT_NO as ZM_EXTNR,
            BRANCH_CLIENT as ZM_IDTYPE
        from IMAP.MANUAL_LISTS_CURRENT
        where BRANCH_CLIENT <> 'CBB'
    ), AMC_CLIENTS as (
        select distinct
            CLIENT_NO    as ZM_EXTNR,
            BRANCH_CLIENT as ZM_IDTYPE
        from AMC.TABLE_PORTFOLIO_DESIRED_CLIENTS_CURRENT
        where BRANCH_CLIENT <> 'CBB'
        union all
        select distinct
            CL.CLIENT_NO    as ZM_EXTNR,
            BRANCH_CLIENT   as ZM_IDTYPE
        from AMC.TABLE_PORTFOLIO_DESIRED_CLIENTS_ARCHIVE as CL
        where BRANCH_CLIENT <> 'CBB'
    )
    , MANUELLE_KUNDEN_AUS_05(ZM_EXTNR, ZM_IDTYPE) as (select * from SMAP.ZUSAETZLICHE_KUNDEN_BW_BESTELLUNG)
    , RESULT as (
        select AMC.ZM_EXTNR, AMC.ZM_IDTYPE
        from AMC_CLIENTS as AMC
        union
        select BGA.ZM_EXTNR, BGA.ZM_IDTYPE
        from BGA_CLIENTS as BGA
        union
        select MAN.ZM_EXTNR, MAN.ZM_IDTYPE
        from MANUELLE_KUNDEN_AUS_05 as MAN
    )
    select distinct
        BIGINT(ZM_EXTNR) as ZM_EXTNR,
        case when ZM_IDTYPE='NLB' then 'N001'
             when ZM_IDTYPE='BLB' then 'K001'
             else ZM_IDTYPE
        end as ZM_IDTYPE,
        COD.THE_DATE,
        YEAR(COD.THE_DATE) ||'0' || VARCHAR_FORMAT(COD.THE_DATE,'MM') as FISCPER
    from RESULT
    cross join the_COD as COD
    where ZM_EXTNR is not null
;

--select * from CALC.AUTO_VIEW_CLIENTS_FOR_BW where ZM_IDTYPE not in ('N001','K001');
