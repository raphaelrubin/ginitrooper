## MAPPING

In diesem Ordner befinden sich alle CALC.VIEW_ Definitionen. Diese Definitionen sind zuständig um Daten zwischen zwei
Tabellen zu mappen.

Das File 08_CLIENTS_FOR_BW.sql greift auf die Tabelle AMC.TABLE_PORTFOLIO_DESIRED_CLIENTS_CURRENT, somit kann die View
erst nachdem das Portfolio gebaut wurde erstellt werden.