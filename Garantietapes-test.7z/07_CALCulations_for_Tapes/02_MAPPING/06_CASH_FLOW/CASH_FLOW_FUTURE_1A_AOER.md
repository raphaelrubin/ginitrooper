Die Datei CASH_FLOW_FUTURE_1A_AOER ist für die korrekte Ausführungsreihenfolge durch die CI unter
02_Mapping -> 02_Facility -> 07_FACILTIY_CASH_FLOW_FUTURE_1A_AOER
zu finden.