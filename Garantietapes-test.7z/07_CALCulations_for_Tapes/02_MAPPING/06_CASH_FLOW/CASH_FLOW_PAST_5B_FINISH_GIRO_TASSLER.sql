---------------------------------
-- CASH_FLOW_PAST_GIRO_TASSLER --
---------------------------------
-- CI START FOR ALL TAPES
-- Drop View
drop view AMC.TAPE_CASH_FLOW_PAST_GIRO_TASSLER_FINISH;
-- View erstellen
create or replace view AMC.TAPE_CASH_FLOW_PAST_GIRO_TASSLER_FINISH as select * from AMC.TABLE_CASH_FLOW_PAST_GIRO_TASSLER_CURRENT;
-- CI END FOR ALL TAPES