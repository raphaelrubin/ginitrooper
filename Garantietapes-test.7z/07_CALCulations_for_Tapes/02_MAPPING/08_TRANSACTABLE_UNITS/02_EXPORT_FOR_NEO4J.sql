--Collateral to Facility zum aktuellen Stichtag
drop view AMC.TU_IMPORT_C2F;
create or replace view AMC.TU_IMPORT_C2F as select distinct COLLATERAL_ID, FACILITY_ID from AMC.TABLE_COLLATERAL_TO_FACILITY_CURRENT;
--Asset to Collateral
drop view AMC.TU_IMPORT_A2C;
create or replace view AMC.TU_IMPORT_A2C as select distinct asset_ID, COLLATERAL_ID from AMC.TABLE_ASSET_TO_COLLATERAL_CURRENT;
--Borrower to Konzern-ID
drop view AMC.TU_IMPORT_B2K;
create or replace view AMC.TU_IMPORT_B2K as select distinct CLIENT_ID_TXT, KONZERN_ID from AMC.TABLE_CLIENT_ACCOUNTHOLDER_CURRENT;

--TUs aus dem letzten Monat
drop view AMC.TU_IMPORT_PREVIOUS_TU;
create view AMC.TU_IMPORT_PREVIOUS_TU as
    with CURRENT_CUT_OFF_DATE as (
        select CUT_OFF_DATE from CALC.AUTO_TABLE_CUTOFFDATES where IS_ACTIVE
    ),
    LAST_CUT_OFF_DATE as (
        select MAX(PAST.CUT_OFF_DATE) as CUT_OFF_DATE
        from CALC.AUTO_TABLE_CUTOFFDATES as CURRENT
        left join CALC.AUTO_TABLE_CUTOFFDATES as PAST on CURRENT.CUT_OFF_DATE > PAST.CUT_OFF_DATE
        where CURRENT.IS_ACTIVE
    )
       select distinct TU_ID, TYP, ID from AMC.TABLE_TRANSACTABLE_UNITS_ARCHIVE TU
        --CUT_OFF_DATE from the month before
        inner join LAST_CUT_OFF_DATE as LAST on LAST.CUT_OFF_DATE = TU.CUT_OFF_DATE;