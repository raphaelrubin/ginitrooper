-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','TABLE_TRANSACTABLE_UNITS_CURRENT');

create table AMC.TABLE_TRANSACTABLE_UNITS_CURRENT (
    --ID aus dem TU Algorithmus
    TU_ID BIGINT,
    --Art des Gegenstands gefüllt mit (ASSET, COLLATERAL, FACILITY, KUNDE)
    TYP VARCHAR(20),
    --ID des Gegenstands (Facility-ID, Asset-ID, Collateral ID, Borrower ID)
    ID VARCHAR(40),
    --CUT_OFF_DATE
    CUT_OFF_DATE DATE
)
distribute by hash(TU_ID) in SPACE_AMC_A,SPACE_AMC_B,SPACE_AMC_C,SPACE_AMC_D,SPACE_AMC_E,SPACE_AMC_F;

create index AMC.TABLE_TRANSACTABLE_UNITS_CURRENT_TU_ID on AMC.TABLE_TRANSACTABLE_UNITS_CURRENT(TU_ID);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','TABLE_TRANSACTABLE_UNITS_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- ARCHIVE TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','TABLE_TRANSACTABLE_UNITS_ARCHIVE');
create table AMC.TABLE_TRANSACTABLE_UNITS_ARCHIVE like AMC.TABLE_TRANSACTABLE_UNITS_CURRENT distribute by hash(TU_ID) partition by RANGE (CUT_OFF_DATE) (starting '1.1.2015' ending '31.12.2030' EVERY 1 Month) in SPACE_AMC_A,SPACE_AMC_B,SPACE_AMC_C,SPACE_AMC_D,SPACE_AMC_E,SPACE_AMC_F;
create index AMC.TABLE_TRANSACTABLE_UNITS_ARCHIVE_TU_ID on AMC.TABLE_TRANSACTABLE_UNITS_ARCHIVE (TU_ID);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','TABLE_TRANSACTABLE_UNITS_ARCHIVE');
------------------------------------------------------------------------------------------------------------------------