/* PORTFOLIO_MANUAL_CLIENTS
 * Liste an Kunden, die für das AMC Tape angefragt wurden.
 * Neue Kunden können hier manuell ergänzt werden.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view AMC.VIEW_PORTFOLIO_MANUAL_CLIENTS;
create or replace view AMC.VIEW_PORTFOLIO_MANUAL_CLIENTS(BRANCH_CLIENT,CLIENT_NO,PORTFOLIO,VALID_FROM_DATE,VALID_TO_DATE,SOURCE,CREATED_USER,CREATED_TIMESTAMP) as
with
    -- IMAP mit Manuellen Kunden für alle Tapes
    LISTE as (
        select
            BRANCH_CLIENT,
            CLIENT_NO,
            PORTFOLIO,
            valid_from_date,
            VALID_TO_DATE
        from IMAP.MANUAL_LISTS
        where PORTFOLIO_CODE = 'AMC'
    ),
    ADDITIONAL_CLIENTS_BY_QUICKFIX_2021 as (
        select
            BRANCH_CLIENT,
            CLIENT_NO,
            NULL as PORTFOLIO,
            valid_from_date,
            VALID_TO_DATE,
            QUELLE as SOURCE
        from STG.T_VIEW_MANUAL_LISTS
        where PORTFOLIO_CODE = 'AMC'
    ),
    -- Ursprüngliche Grundgesamtheit aus dem KR
    CLIENT_COLLECTION_BASICS as (
        select BRANCH_CLIENT, CLIENT_NO, PORTFOLIO as PORTFOLIO, VALID_FROM_DATE, VALID_TO_DATE
        from AMC.VIEW_PORTFOLIO_BASIC_SELECTION as CLIENTS
    ),
    COMBINATION as (
        Select CHAR(BRANCH_CLIENT, 3) as BRANCH_CLIENT,
               BIGINT(CLIENT_NO) as CLIENT_NO,
               PORTFOLIO,
               VALID_FROM_DATE,
               VALID_TO_DATE,
               'Manuelle Kundenliste' as SOURCE
        from LISTE
        union all
        Select CHAR(BRANCH_CLIENT, 3)        as BRANCH_CLIENT,
               BIGINT(CLIENT_NO) as CLIENT_NO,
               PORTFOLIO,
               VALID_FROM_DATE,
               VALID_TO_DATE,
               'Manuelle Kundenliste' as SOURCE
        from ADDITIONAL_CLIENTS_BY_QUICKFIX_2021
        union all
        Select CHAR(BRANCH_CLIENT, 3) as BRANCH_CLIENT,
               BIGINT(CLIENT_NO) as CLIENT_NO,
               PORTFOLIO,
               VALID_FROM_DATE,
               VALID_TO_DATE,
               'Grundgesammtheit'     as SOURCE
        from CLIENT_COLLECTION_BASICS
    )
select
    CHAR(BRANCH_CLIENT, 3)              as BRANCH_CLIENT,
    BIGINT(CLIENT_NO)                   as CLIENT_NO,
    cast(PORTFOLIO as VARCHAR(64))      as PORTFOLIO,
    DATE(coalesce(VALID_FROM_DATE, '01.01.2015')) as VALID_FROM_DATE,
    DATE(coalesce(VALID_TO_DATE, '31.12.9999')) as VALID_TO_DATE,
    cast(SOURCE as VARCHAR(64)) as SOURCE,
    Current USER                            as CREATED_USER,     -- Letzter Nutzer, der diese Tabelle gebaut hat.
    Current TIMESTAMP                       as CREATED_TIMESTAMP -- Neuester Zeitstempel, wann diese Tabelle zuletzt gebaut wurde.
from COMBINATION
;
------------------------------------------------------------------------------------------------------------------------

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
create table AMC.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT like AMC.VIEW_PORTFOLIO_MANUAL_CLIENTS;
create index AMC.INDEX_TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT_CLIENT_NO  on AMC.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT (CLIENT_NO);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
grant select on AMC.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT to group NLB_MW_ADAP_S_GNI_TROOPER;
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('AMC','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------
