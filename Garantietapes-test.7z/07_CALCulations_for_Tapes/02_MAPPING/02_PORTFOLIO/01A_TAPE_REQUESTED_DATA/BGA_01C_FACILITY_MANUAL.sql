/* TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT
 * Liste an Konten, die für das BGA Tape angefragt werden.
 * Neue Konten können hier manuell ergänzt werden.
 */

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('BGA','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
create table BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT (
    LIST_ID BIGINT NOT NULL,    -- Eindeutige ID der Kontenliste (zu jedem Zeitpunkt immer die gleiche Zahl für alle Einträge in dieser Tabelle, nur im Archiv unterschiedlich)
    BRANCH_FACILITY CHAR(3) NOT NULL,    -- Institut (NLB/BLB/ANL/CBB)
    FACILITY_ID VARCHAR(64) NOT NULL,  -- Kontennummer
    PORTFOLIO VARCHAR(128),     -- Portfolioname
    SOURCE VARCHAR(256) DEFAULT 'Fachbereich',
    REQUESTED_BY VARCHAR(256) DEFAULT 'Unbekannt',
    VALID_FROM_DATE DATE DEFAULT '2023-01-01',
    VALID_TO_DATE DATE DEFAULT '2099-12-31',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(LIST_ID,BRANCH_FACILITY,FACILITY_ID)
);
create index BGA.INDEX_TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT_FACILITY_ID  on BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT (FACILITY_ID);
comment on table BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT is 'Kontenliste für Sonderanfragen - daher mit Listen ID';
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('BGA','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
grant select on BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT to group NLB_MW_ADAP_S_GNI_TROOPER;
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('BGA','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
------------------------------------------------------------------------------------------------------------------------
