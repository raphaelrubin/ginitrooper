/* PORTFOLIO_MANUAL_CLIENTS
 * Liste an Kunden, die für das BGA Tape angefragt wurden.
 * Neue Kunden können hier manuell ergänzt werden.
 */

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('BGA','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
-- create table BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT like BGA.VIEW_PORTFOLIO_MANUAL_CLIENTS;
create table BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT(
    LIST_ID BIGINT NOT NULL,    -- Eindeutige ID der Kundenliste (zu jedem Zeitpunkt immer die gleiche Zahl für alle Einträge in dieser Tabelle, nur im Archiv unterschiedlich)
    BRANCH_CLIENT CHAR(3) NOT NULL,    -- Institut (NLB/BLB/ANL/CBB)
    CLIENT_NO BIGINT NOT NULL,  -- Kundennummer
    PORTFOLIO VARCHAR(128),     -- Portfolioname
    SOURCE VARCHAR(256) DEFAULT 'Fachbereich',
    REQUESTED_BY VARCHAR(256) DEFAULT 'Unbekannt',
    VALID_FROM_DATE DATE DEFAULT '2015-01-01',
    VALID_TO_DATE DATE DEFAULT '2099-12-31',
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(LIST_ID,BRANCH_CLIENT,CLIENT_NO)
);
create index BGA.INDEX_TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT_CLIENT_NO  on BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT (CLIENT_NO);
comment on table BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT is 'Kundenliste für Sonderanfragen - daher mit Listen ID';
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('BGA','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
grant select on BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT to group NLB_MW_ADAP_S_GNI_TROOPER;
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('BGA','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------
