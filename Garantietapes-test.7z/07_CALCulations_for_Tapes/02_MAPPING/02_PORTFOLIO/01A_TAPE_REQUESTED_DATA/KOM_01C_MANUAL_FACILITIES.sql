/* PORTFOLIO_FACILITY_MANUAL
 * Liste an Konten, die für das KOM Tape angefragt wurden.
 * Neue Konten können hier manuell ergänzt werden.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view KOM.VIEW_PORTFOLIO_FACILITY_MANUAL;
create or replace view KOM.VIEW_PORTFOLIO_FACILITY_MANUAL as
    select distinct
            CHAR(BRANCH_FACILITY,3) as BRANCH_FACILITY,
            FACILITY_ID,
            PORTFOLIO,
            DATE(coalesce(VALID_FROM_DATE,'01.01.2015')) as VALID_FROM_DATE,
            DATE(coalesce(VALID_TO_DATE,'31.12.9999')) as VALID_TO_DATE,
            'Manuelle Konten' as SOURCE
        from AMC.VIEW_PORTFOLIO_FACILITY_MANUAL
        where 1 <> 1
;
------------------------------------------------------------------------------------------------------------------------

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('KOM','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
create table KOM.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT like KOM.VIEW_PORTFOLIO_FACILITY_MANUAL;
create index KOM.INDEX_TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT_FACILITY_ID  on KOM.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT (FACILITY_ID);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('KOM','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('KOM','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
------------------------------------------------------------------------------------------------------------------------
