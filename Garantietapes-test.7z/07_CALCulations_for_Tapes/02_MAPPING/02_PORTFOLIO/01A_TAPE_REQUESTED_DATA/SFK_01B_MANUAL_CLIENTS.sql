/* PORTFOLIO_MANUAL_CLIENTS
 * Liste an Kunden, die für das SFK Tape angefragt wurden.
 * Neue Kunden können hier manuell ergänzt werden.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view SFK.VIEW_PORTFOLIO_MANUAL_CLIENTS;
create or replace view SFK.VIEW_PORTFOLIO_MANUAL_CLIENTS(BRANCH_CLIENT,CLIENT_NO,PORTFOLIO,VALID_FROM_DATE,VALID_TO_DATE,SOURCE,CREATED_USER,CREATED_TIMESTAMP) as
with
        LISTE as (
        select
        BRANCH_CLIENT,
        CLIENT_NO,
        PORTFOLIO,
        valid_from_date,
        VALID_TO_DATE
        from
        IMAP.MANUAL_LISTS where PORTFOLIO_CODE = 'SFK'
    )
Select
    CHAR(BRANCH_CLIENT,3),
    BIGINT(CLIENT_NO),
    VARCHAR(PORTFOLIO,128),
    DATE(VALID_FROM_DATE),
    DATE(VALID_TO_DATE),
    'Manuelle Kundenliste' as SOURCE,
    Current USER                            as CREATED_USER,     -- Letzter Nutzer, der diese Tabelle gebaut hat.
    Current TIMESTAMP                       as CREATED_TIMESTAMP -- Neuester Zeitstempel, wann diese Tabelle zuletzt gebaut wurde.
from LISTE
;
------------------------------------------------------------------------------------------------------------------------

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('SFK','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
create table SFK.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT like SFK.VIEW_PORTFOLIO_MANUAL_CLIENTS;
create index SFK.INDEX_TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT_CLIENT_NO  on SFK.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT (CLIENT_NO);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('SFK','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('SFK','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------
