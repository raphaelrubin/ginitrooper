/* PORTFOLIO_MANUAL_CLIENTS
 * Liste an Kundenbetreuer OEs, die für das AMC Tape angefragt wurden.
 * Neue Kundenbetreuer OEs können hier manuell ergänzt werden.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view AMC.VIEW_PORTFOLIO_MANUAL_OE;
create or replace view AMC.VIEW_PORTFOLIO_MANUAL_OE(BRANCH_OE, OE_BEZEICHNUNG, PORTFOLIO, VALID_FROM_DATE,VALID_TO_DATE,CREATED_USER,CREATED_TIMESTAMP) as
with
    LISTE(BRANCH_OE, OE_BEZEICHNUNG,PORTFOLIO, VALID_FROM_DATE,VALID_TO_DATE) as (
        select *
        from TABLE (VALUES
                        ('NLB', 'MI Portfoliomgmt III','Maritime Industries OE Auffüllung', '30.06.2020', null),
                        ('NLB', 'SPO Schiffe H 1','Maritime Industries OE Auffüllung','30.06.2020', null),
                        ('NLB', 'SPO Abwicklung','Maritime Industries OE Auffüllung','30.06.2020', null),
                        ('BLB', 'MI Portfoliomanagement I','Maritime Industries OE Auffüllung','30.06.2020', null),
                        ('BLB', 'MI Portfoliomanagement II','Maritime Industries OE Auffüllung', '30.06.2020', null)
                   )
    )
Select
    cast(BRANCH_OE as VARCHAR(3))           as BRANCH_OE,
    cast(OE_BEZEICHNUNG as VARCHAR(64))     as OE_BEZEICHNUNG,
    cast(PORTFOLIO as VARCHAR(64))          as PORTFOLIO,
    DATE(coalesce(VALID_FROM_DATE,'01.01.2015')) as VALID_FROM_DATE,
    DATE(coalesce(VALID_TO_DATE,'31.12.9999')) as VALID_TO_DATE,
    Current USER                            as CREATED_USER,     -- Letzter Nutzer, der diese Tabelle gebaut hat.
    Current TIMESTAMP                       as CREATED_TIMESTAMP -- Neuester Zeitstempel, wann diese Tabelle zuletzt gebaut wurde.
from LISTE
;
------------------------------------------------------------------------------------------------------------------------

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
create table AMC.TABLE_PORTFOLIO_MANUAL_OE_CURRENT like AMC.VIEW_PORTFOLIO_MANUAL_OE;
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('AMC','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
------------------------------------------------------------------------------------------------------------------------
