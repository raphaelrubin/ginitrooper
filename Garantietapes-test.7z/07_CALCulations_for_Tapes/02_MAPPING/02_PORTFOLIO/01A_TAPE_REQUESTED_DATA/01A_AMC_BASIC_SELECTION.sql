/* VIEW_PORTFOLIO_BASIC_SELECTION
 * Grundgesamtheit aus dem KR, welche Kunden - Konto Kombinationen für das Tape relevant sind.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view AMC.VIEW_PORTFOLIO_BASIC_SELECTION;
create or replace view AMC.VIEW_PORTFOLIO_BASIC_SELECTION as
    select
           replace(INSTITUTE,'LUX','CBB') as BRANCH_CLIENT,
           CLIENT_ID as CLIENT_NO,
           replace(BRANCH,'LUX','CBB') as BRANCH_FACILITY,
           FACILITY_ID as FACILITY_ID,
           PORTFOLIO as PORTFOLIO,
           CUT_OFF_DATE as VALID_FROM_DATE,
           NULL as VALID_TO_DATE
    from AMC.AMC_GG
;
------------------------------------------------------------------------------------------------------------------------
grant select on AMC.VIEW_PORTFOLIO_BASIC_SELECTION to group NLB_MW_ADAP_S_GNI_TROOPER;
-- Kommentar für CI-Test