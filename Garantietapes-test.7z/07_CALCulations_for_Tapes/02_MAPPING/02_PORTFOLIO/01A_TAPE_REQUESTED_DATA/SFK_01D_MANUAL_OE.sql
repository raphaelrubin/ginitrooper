/* PORTFOLIO_MANUAL_CLIENTS
 * Liste an Kundenbetreuer OEs, die für das SFK Tape angefragt wurden.
 * Neue Kundenbetreuer OEs können hier manuell ergänzt werden.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view SFK.VIEW_PORTFOLIO_MANUAL_OE;
create or replace view SFK.VIEW_PORTFOLIO_MANUAL_OE(BRANCH_OE, OE_BEZEICHNUNG, PORTFOLIO, VALID_FROM_DATE,VALID_TO_DATE,CREATED_USER,CREATED_TIMESTAMP) as
with
    LISTE(BRANCH_OE, OE_BEZEICHNUNG,PORTFOLIO, VALID_FROM_DATE,VALID_TO_DATE) as (
        select NULL, NULL,NULL, NULL,NULL
        from SYSIBM.SYSDUMMY1 where 1 <> 1
    )
Select
    cast(BRANCH_OE as VARCHAR(3))           as BRANCH_OE,
    cast(OE_BEZEICHNUNG as VARCHAR(64))     as OE_BEZEICHNUNG,
    cast(PORTFOLIO as VARCHAR(64))          as PORTFOLIO,
    DATE(coalesce(VALID_FROM_DATE,'01.01.2015')) as VALID_FROM_DATE,
    DATE(coalesce(VALID_TO_DATE,'31.12.9999')) as VALID_TO_DATE,
    Current USER                            as CREATED_USER,     -- Letzter Nutzer, der diese Tabelle gebaut hat.
    Current TIMESTAMP                       as CREATED_TIMESTAMP -- Neuester Zeitstempel, wann diese Tabelle zuletzt gebaut wurde.
from LISTE
;
------------------------------------------------------------------------------------------------------------------------

-- CURRENT TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('SFK','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
create table SFK.TABLE_PORTFOLIO_MANUAL_OE_CURRENT like SFK.VIEW_PORTFOLIO_MANUAL_OE;
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('SFK','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- SWITCH erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('SFK','TABLE_PORTFOLIO_MANUAL_OE_CURRENT');
------------------------------------------------------------------------------------------------------------------------
