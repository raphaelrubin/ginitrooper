-- View erstellen
--This is a merge between the Facility_Core Table and the Bankanalyser Table
drop view AMC.VIEW_FACILITY_KREDITRISIKO_MERGE_VOR_KERMIT;
create or replace view AMC.VIEW_FACILITY_KREDITRISIKO_MERGE_VOR_KERMIT as
    with FACILITIES as (
        select
            CUT_OFF_DATE
            ,FACILITY_ID
            ,CLIENT_ID
             ,PORTFOLIO
            ,BRANCH
           ,case when substring(BRANCH,1,1) = 'N' then 'NLB'
               when BRANCH = 'CBB' then 'LUX'
            else BRANCH end as INSTITUTE
             ,GUARANTEE_FLAG
           ,PRODUCTTYPE
           ,PRODUCTGROUP_AVIATION
           ,ORIGINAL_CURRENCY
           ,OWN_SYNDICATE_QUOTA/100 as OWN_SYNDICATE_QUOTA --wird in Export als Prozentwert benötigt
           ,ORIGINATION_DATE
           ,CURRENT_CONTRACTUAL_MATURITY_DATE
             ,BILANZWERT_BRUTTO_EUR
             ,BILANZWERT_BRUTTO_TC
            ,BILANZWERT_IFRS9_EUR
            ,BILANZWERT_IFRS9_TC
             ,FVA_EUR
             ,FVA_TC
            ,ACCRUED_INTEREST_EUR
            ,ACCRUED_INTEREST_TC
            ,-PRICIPAL_OST_EUR_SPOT as PRICIPAL_OST_EUR_SPOT --Unterschied zwischen negativem und positivem Wert ist Betrachtungsweise in Bilanz
            ,-PRICIPAL_OST_TC_SPOT as PRICIPAL_OST_TC_SPOT --Unterschied zwischen negativem und positivem Wert ist Betrachtungsweise in Bilanz
            ,PRICIPAL_OST_EUR_BW
            ,PRICIPAL_OST_TC_BW
            ,AMORTIZATION_IN_ARREARS_EUR_SPOT
            ,AMORTIZATION_IN_ARREARS_TC_SPOT
            ,INTEREST_IN_ARREARS_EUR_SPOT
            ,INTEREST_IN_ARREARS_TC_SPOT
            ,FEES_IN_ARREARS_TC_SPOT
            ,FEES_IN_ARREARS_EUR_SPOT
            ,DERIVATIVES_FAIR_VALUE_DIRTY_EUR
            ,NEXT_AMORTIZATION_TO_BE_PAID
            ,AMOUNT_DUE_AT_MATURITY_EUR
            ,AMORTIZATION_TYPE
            ,AMORTIZATION_FREQUENCY_DAYS
            ,INTEREST_RATE_TYPE
            ,NEXT_INTEREST_PAYMENT_DATE
            ,INTEREST_RATE
            ,FIXED_INTEREST_RATE
            ,INTEREST_RATE_FREQUENCY
            ,FIXED_INTEREST_RATE_END_DATE
            ,INTEREST_RATE_INDEX
            ,INTEREST_RATE_MARGIN
            ,case when ELIGIBILITY_FOR_COVERSTOCK is null then 0
                when ELIGIBILITY_FOR_COVERSTOCK = 'in Deckung' then 1
                    else 0 end as ELIGIBILITY_FOR_COVERSTOCK --Annahme, dass vorgesehen = 0 überprüfen!
            ,COVERSTOCK_NAME
            ,EFFECTIVE_COVER_AMOUNT_EUR
            ,DAYS_PAST_DUE
               from CALC.VIEW_FACILITY_CORE
    ),
         KR_DATA as (
             select
            CUT_OFF_DATE
            ,FACILITY_ID
            ,EAD_TOTAL_EUR               -- ExposureAtDefault_EUR
            ,EAD_SECURITIZED --ExposureAtDefault_Securitized_EUR
            ,EAD_NON_SECURITIZED_EUR--ExposureAtDefault_NonSecuritized_EUR
            ,RWA_TOTAL_EUR--RiskWeightedAssets_EUR
            ,RWA_NON_SECURITIZED_EUR--RiskWeightedAssets_NonSecuritized_EUR
            ,RWA_SECURITIZED_EUR
            ,FREIE_LINIE as Undrawn_Amount_EUR
            ,CREDIT_CONVERSION_FACTOR
            ,INTERNAL_RATINGKLASSE --InternalRating_NLB
            ,INTERNAL_RATINGSTUFE --InternalRating
            ,PD_WEIGHTED --ProbabilityOfDefault_reg
            ,SECURITISATION_FLAG --IsSecuritized
             from CALC.VIEW_KREDITRISIKO_BANKANALYSER_VOR_KERMIT
         ), BASIS as (
    select FAC.*, P2F_MAP.FACILITY_TYPE, TU.TU_GUARANTEE_FLAG,
           ead_total_eur, ead_securitized, ead_non_securitized_eur, rwa_total_eur, rwa_non_securitized_eur, rwa_securitized_eur, undrawn_amount_eur, credit_conversion_factor, internal_ratingklasse, internal_ratingstufe, pd_weighted, securitisation_flag
    from FACILITIES FAC
        left join KR_DATA KR on (FAC.FACILITY_ID, FAC.CUT_OFF_DATE) = (KR.FACILITY_ID, KR.CUT_OFF_DATE)
        left join SMAP.PRODUCT_TO_FACILITY_ID P2F_MAP on FAC.PRODUCTTYPE = P2F_MAP.PRODUCT_TYPE
        left join AMC.VIEW_TU_FACILITY TU on (TU.CUT_OFF_DATE, TU.TU_ID) = (FAC.CUT_OFF_DATE,FAC.FACILITY_ID))
         select
                current_timestamp as TAPE_CREATED_TIMESTAMP
                ,BASIS.CUT_OFF_DATE --CutOffDate
                ,BASIS.FACILITY_ID --FacilityID
                ,CLIENT_ID --BorrowerID
                ,NULL as RISK_COLLECTIVE_ID --RiskCollectiveID
                ,NULL as TRANSACTABLE_UNIT_ID --TransactableUnitID
                ,PORTFOLIO as TRANSFER_PORTFOLIO--TransferPortfolio
                ,case
                    when GUARANTEE_FLAG is TRUE then 'Garantie'
                    when SECURITISATION_FLAG is not null then 'NV2'
                        end as AVIATION_PORTFOLIO
                ,BRANCH--Branch
                ,BASIS.INSTITUTE --Institute
                ,GUARANTEE_FLAG
                ,TU_GUARANTEE_FLAG
                ,FACILITY_TYPE--FacilityType
                ,PRODUCTTYPE--ProductType
                ,PRODUCTTYPE as Product_Type_Detailed
                ,PRODUCTGROUP_AVIATION--AircraftFinanceType
                ,ORIGINAL_CURRENCY--OriginalCurrency
                ,BASIS.OWN_SYNDICATE_QUOTA--OwnSyndicateQuota
                ,ORIGINATION_DATE--OriginationDate
                ,CURRENT_CONTRACTUAL_MATURITY_DATE--CurrentContractualMaturityDate
                ,EAD_TOTAL_EUR--ExposureAtDefault_EUR
                ,EAD_SECURITIZED--ExposureAtDefault_Securitized_EUR
                ,EAD_NON_SECURITIZED_EUR--ExposureAtDefault_NonSecuritized_EUR
                ,RWA_TOTAL_EUR--RiskWeightedAssets_EUR
                ,RWA_SECURITIZED_EUR--RiskWeightedAssets_Securitized_EUR
                ,RWA_NON_SECURITIZED_EUR--RiskWeightedAssets_NonSecuritized_EUR
                ,BILANZWERT_BRUTTO_EUR--IFRS_GrossBookValue_EUR
                ,BILANZWERT_BRUTTO_TC--IFRS_GrossBookValue_OriginalCurrency
                ,BILANZWERT_IFRS9_EUR as IFRS_NetBookValue_EUR
                ,BILANZWERT_IFRS9_TC as IFRS_NetBookValue_OriginalCurrency
                ,FVA_EUR as FairValueAdjustment_EUR
                ,FVA_TC as FairValueAdjustment_OriginalCurrency
                ,ACCRUED_INTEREST_EUR--AccruedInterest_EUR
                ,ACCRUED_INTEREST_TC--AccruedInterest_OriginalCurrency
                ,BASIS.PRICIPAL_OST_EUR_SPOT as PrincipalOutstanding_Total_EUR
                ,BASIS.PRICIPAL_OST_TC_SPOT as PrincipalOutstanding_Total_OriginalCurrency
                ,PRICIPAL_OST_EUR_BW as PrincipalOutstanding_NLB_EUR
                ,PRICIPAL_OST_TC_BW as PrincipalOutstanding_NLB_OriginalCurrency
                ,AMORTIZATION_IN_ARREARS_EUR_SPOT--AmortizationInArrears_EUR --TODO: Nach Tests verändert, schauen, was EY nach dem 31.12 hiermit macht!
                ,AMORTIZATION_IN_ARREARS_TC_SPOT--AmortizationInArrears_OriginalCurrency--TODO: Nach Tests verändert, schauen, was EY nach dem 31.12 hiermit macht!
                ,INTEREST_IN_ARREARS_EUR_SPOT--InterestInArrears_EUR--TODO: Nach Tests verändert, schauen, was EY nach dem 31.12 hiermit macht!
                ,INTEREST_IN_ARREARS_TC_SPOT--InterestInArrears_OriginalCurrency--TODO: Nach Tests verändert, schauen, was EY nach dem 31.12 hiermit macht!
                ,FEES_IN_ARREARS_EUR_SPOT--FeesInArrears_EUR
                ,FEES_IN_ARREARS_TC_SPOT--FeesInArrears_OriginalCurrency
                ,Undrawn_Amount_EUR--UndrawnAmount_EUR
                ,CREDIT_CONVERSION_FACTOR--CreditConversionFactor
                ,DERIVATIVES_FAIR_VALUE_DIRTY_EUR--DerivativesFairValue_dirty_EUR
                ,AMORTIZATION_TYPE--AmortizationType
                ,AMORTIZATION_FREQUENCY_DAYS--AmortizationFrequency
                ,NEXT_AMORTIZATION_TO_BE_PAID as AmortizationAmount_EUR
                ,AMOUNT_DUE_AT_MATURITY_EUR--AmortizationDueAtMaturity_EUR
                ,INTEREST_RATE_TYPE--InterestRateType
                ,INTEREST_RATE_FREQUENCY--InterestFrequency
                ,NEXT_INTEREST_PAYMENT_DATE--NextInterestPaymentDate
                ,INTEREST_RATE--InterestRate
                ,FIXED_INTEREST_RATE--FixedInterestRate
                ,FIXED_INTEREST_RATE_END_DATE--FixedInterestRateEndDate
                ,INTEREST_RATE_INDEX--InterestRateIndex
                ,INTEREST_RATE_MARGIN--InterestRateMargin
                ,INTERNAL_RATINGSTUFE--InternalRating_NLB
                ,INTERNAL_RATINGKLASSE--InternalRating
                ,PD_WEIGHTED--ProbabilityOfDefault_reg
                ,SECURITISATION_FLAG--IsSecuritized
                ,ELIGIBILITY_FOR_COVERSTOCK--IsEligibleForCoverStock
                ,COVERSTOCK_NAME--CoverStockName
                ,EFFECTIVE_COVER_AMOUNT_EUR--EffectiveCoverAmount_EUR
                ,NULL as Surrogate_PreviousID
                ,NULL as Surrogate_CreditLineID
                ,NULL as Surrogate_DeferralAccountID
                ,DAYS_PAST_DUE--DaysOverdue
                ,NULL as GuaranteeAmount_preliminary_EUR
                ,NULL as GuaranteeAmount_preliminary_OriginalCurrency
                ,NULL as GuaranteeAmount_OriginalCurrency_Stichtag
                ,NULL as FX_gem_Garantievertrag
                ,NULL as GuaranteeAmount_EUR_Stichtag
                ,NULL as InternalRating_letztesQuartal--Wert muss aus dem Archiv selektiert werden. In manchen Fällen funktioniert MAX_RATING aus KR_DATA
                ,Current_USER    as TAPE_CREATED_USER
    from BASIS
;
