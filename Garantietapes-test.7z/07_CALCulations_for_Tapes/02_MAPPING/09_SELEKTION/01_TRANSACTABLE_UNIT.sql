--An dieser Stelle müssen folgende Tabellen entstehen:
--FACILITY_TUs:
    --Spalten: Facility_ID, GUARANTEE_FLAG, TU_ID, TU_GUARANTEE_FLAG,CoD, TransferPortfolio, AviationPortfolio

drop view AMC.VIEW_TU_FACILITY;
create or replace view AMC.VIEW_TU_FACILITY as
    select
           FACILITY_ID,
           GUARANTEE_FLAG,
           TU_ID,
           NULL as RISKCOLLECTIVEID,
           --TU.RISKCOLLECTIVEID,
           GUARANTEE_FLAG as TU_GUARANTEE_FLAG,
           fac_core.CUT_OFF_DATE,
           fac_core.TRANSFER_PORTFOLIO,
           NULL as AVIATION_PORTFOLIO
           from AMC.TABLE_FACILITY_CORE_CURRENT FAC_CORE
             left join AMC.TABLE_TRANSACTABLE_UNITS_CURRENT TU on (TU.CUT_OFF_DATE, TU.ID) = (FAC_CORE.CUT_OFF_DATE,FAC_CORE.FACILITY_ID) and TU.TYP = 'FACILITY';


--ASSET_TUS: Asset_ID, TU_ID, TU_GUARANTEE_FLAG,CoD, TransferPortfolio, AviationPortfolio
drop view AMC.VIEW_TU_ASSET;
create or replace view AMC.VIEW_TU_ASSET as
    select
           ASSET_ID,
           TU.TU_ID,
           --TU.TRANSACTABLEUNITID as TU_ID,
           NULL as RISKCOLLECTIVEID,
           --TU.RISKCOLLECTIVEID,
           TU_FAC.TU_GUARANTEE_FLAG as TU_GUARANTEE_FLAG,
           ASSET.CUT_OFF_DATE,
           TU_FAC.TRANSFER_PORTFOLIO as TRANSFER_PORTFOLIO,
           NULL as AVIATION_PORTFOLIO
           from AMC.TABLE_GENERAL_ASSET_ARCHIVE ASSET
            left join AMC.TABLE_TRANSACTABLE_UNITS_CURRENT TU on (TU.CUT_OFF_DATE, TU.ID) = (ASSET.CUT_OFF_DATE,ASSET.ASSET_ID) and TU.TYP = 'ASSET'
               left join (select distinct
                                  TU_ID,
                                  TU_GUARANTEE_FLAG,
                                  TRANSFER_PORTFOLIO
                                  from AMC.VIEW_TU_FACILITY) TU_FAC on TU_FAC.TU_ID = TU.TU_ID;
                                                                            --TU.TRANSACTABLEUNITID

--select * from CALC.VIEW_TU_ASSET
--COLLATERAL_TUS: Collateral_ID, TU_ID, TU_GUARANTEE_FLAG,CoD, TransferPortfolio, AviationPortfolio
drop view AMC.VIEW_TU_COLLATERAL;
create or replace view AMC.VIEW_TU_COLLATERAL as
    select
           COLLATERAL_ID,
           TU.TU_ID,
           --TU.TRANSACTABLEUNITID as TU_ID,
           NULL as RISKCOLLECTIVEID,
           --TU.RISKCOLLECTIVEID,
           TU_FAC.TU_GUARANTEE_FLAG as TU_GUARANTEE_FLAG,
           COL.CUT_OFF_DATE,
           TU_FAC.TRANSFER_PORTFOLIO,
           NULL as AVIATION_PORTFOLIO
           from AMC.TABLE_COLLATERAL_AV_MA_ARCHIVE COL
               left join AMC.TABLE_TRANSACTABLE_UNITS_CURRENT TU on (TU.CUT_OFF_DATE, TU.ID) = (COL.CUT_OFF_DATE,COL.COLLATERAL_ID) and TU.TYP = 'COLLATERAL'
              left join (select distinct
                                  TU_ID,
                                  TU_GUARANTEE_FLAG,
                                  TRANSFER_PORTFOLIO
                                  from AMC.VIEW_TU_FACILITY) TU_FAC on TU_FAC.TU_ID = TU.TU_ID ;
                                                        --TU.TRANSACTABLEUNITID


--BORROWER_TUS: Borrower_ID, TU_ID, TU_GUARANTEE_FLAG,CoD
drop view AMC.VIEW_TU_BORROWER;
create or replace view AMC.VIEW_TU_BORROWER as
    select
           CLIENT_ID_TXT,
            TU.TU_ID,
           --TU.TRANSACTABLEUNITID as TU_ID,
           NULL as RISKCOLLECTIVEID,
           --TU.RISKCOLLECTIVEID,
           TU_FAC.TU_GUARANTEE_FLAG as TU_GUARANTEE_FLAG,
           BOR.CUT_OFF_DATE,
           TU_FAC.TRANSFER_PORTFOLIO,
           NULL as AVIATION_PORTFOLIO
           from AMC.TABLE_CLIENT_ACCOUNTHOLDER_ARCHIVE BOR
                 left join AMC.TABLE_TRANSACTABLE_UNITS_CURRENT TU on (TU.CUT_OFF_DATE, TU.ID) = (BOR.CUT_OFF_DATE,BOR.CLIENT_ID_TXT) and TU.TYP = 'KUNDE'
               left join (select distinct
                                  TU_ID,
                                  TU_GUARANTEE_FLAG,
                                  TRANSFER_PORTFOLIO
                                  from AMC.VIEW_TU_FACILITY) TU_FAC on TU_FAC.TU_ID = TU.TU_ID ;

