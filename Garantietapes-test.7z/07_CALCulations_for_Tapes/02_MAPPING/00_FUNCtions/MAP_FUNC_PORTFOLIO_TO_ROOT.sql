/* MAP_FUNC_PORTFOLIO_TO_ROOT
 * Nimmt ein Portfolio string als Input und
 * wandelt es in ein reinen Portfolionamen um. Dabei werden Zusätze aus Blossom entfernt
 */

-- FUNCTION erstellen
------------------------------------------------------------------------------------------------------------------------
drop function CALC.MAP_FUNC_PORTFOLIO_TO_ROOT(varchar(1024));
--#SET TERMINATOR &&
create or replace function CALC.MAP_FUNC_PORTFOLIO_TO_ROOT(PORTFOLIO varchar(1024))
  returns varchar(1024)
  begin
    declare PORTFOLIO_ROOT VARCHAR(128);

    set PORTFOLIO_ROOT = replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(
                         replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(PORTFOLIO,
        ' SPOT nicht KR Cut Off Dates Konto Auffüllung',''), -- alte Portfolio Ergänzung
        'SPOT',''),
        'LUX',''),
        'ALIS',''),
        'DERIVATE',''),
        'AVALOQ',''),
        'REACTIVATION',''),
        'DLD',''),
        'BW',''),
        'KONTOAUFFÜLLUNG',''),
        'ZUSATZKONTO',''),
        'Murex Flag',''), -- frühere Derivate Kennzeichnung - wird nicht mehr gebraucht
        ' DES KUNDEN NICHT AUS GG KR',''),  -- alte Portfolio Ergänzung
        ' (Rausgefallener Kunde)',''), -- alte Portfolio Ergänzung
        ' (Neu)',''), -- alte Portfolio Ergänzung
        ' (KUNDE HAT NUR ZUSATZKONTEN)',''),
        ' Konto Auffüllung aus Vergangenheit',''),
        ' Konto Auffüllung aus Zukunft',''),
        'FlagAF','Flag AF'),'FlagMI','Flag MI'); -- Portfolio Korrektur für merkwürdige Murex Portfolio
    set PORTFOLIO_ROOT = trim(BOTH ' ' FROM PORTFOLIO_ROOT);
    return PORTFOLIO_ROOT;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.MAP_FUNC_PORTFOLIO_TO_ROOT is 'Funktion zur Entfernung aller Ergänzungen aus dem Portfolionamen.';
------------------------------------------------------------------------------------------------------------------------
