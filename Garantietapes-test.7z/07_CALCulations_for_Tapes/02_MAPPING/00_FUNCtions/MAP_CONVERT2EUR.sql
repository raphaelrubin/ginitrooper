/* MAP_convert2eur
 * Rechnet einen Wert in EUR um.
 */

-- FUNCTION erstellen
------------------------------------------------------------------------------------------------------------------------
drop function CALC.convert2eur(double, double, double);
--#SET TERMINATOR &&
create function CALC.convert2eur(val double,rate double,currency double)
  returns double
  begin
    declare eurval double;
    if currency is null or currency = 'EUR' then return val;
    else set eurval = val / rate;
    end if;
    return eurval;
  end
&&

--#SET TERMINATOR ;
drop function CALC.convert2eur(double, double, varchar(3));
--#SET TERMINATOR &&
create function CALC.convert2eur(val double,rate double,currency varchar(3))
  returns double
  begin
    declare eurval double;
    if currency is null or currency = 'EUR' then return val;
    else set eurval = val / rate;
    end if;
    return eurval;
  end
&&

--#SET TERMINATOR ;
drop function CALC.convert2eur(bigint, double, varchar(3));
--#SET TERMINATOR &&
create function CALC.convert2eur(val bigint,rate double,currency varchar(3))
  returns double
  begin
    declare eurval double;
    if currency is null or currency = 'EUR' then return double(val);
    else set eurval = double(val) / rate;
    end if;
    return eurval;
  end
&&

