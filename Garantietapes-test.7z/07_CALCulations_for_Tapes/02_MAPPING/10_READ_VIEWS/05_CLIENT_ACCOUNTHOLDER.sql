-- CI START FOR ALL TAPES
drop view AMC.READ_CLIENT_ACCOUNTHOLDER;
create or replace view AMC.READ_CLIENT_ACCOUNTHOLDER as
with
-- Current
CURR as (
    select *, 'CURRENT' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_CLIENT_ACCOUNTHOLDER_CURRENT
),
-- Archiv
ARCH as (
    select *, 'ARCHIVE' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_CLIENT_ACCOUNTHOLDER_ARCHIVE
),
-- Union
ALL as (
    select *
    from CURR
    union all
    select *
    from ARCH
)
select *
from ALL;
grant select on AMC.READ_CLIENT_ACCOUNTHOLDER to group NLB_MW_ADAP_S_GNI_TROOPER_EBA_R;
-- CI END FOR ALL TAPES

