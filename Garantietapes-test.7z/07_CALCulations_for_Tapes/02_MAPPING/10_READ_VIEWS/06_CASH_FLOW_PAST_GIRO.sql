-- CI START FOR ALL TAPES
drop view AMC.READ_CASH_FLOW_PAST_GIRO;
create or replace view AMC.READ_CASH_FLOW_PAST_GIRO as
with
-- Current
CURR as (
    select *, 'CURRENT' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_CASH_FLOW_PAST_GIRO_CURRENT
),
-- Archiv
ARCH as (
    select *, 'ARCHIVE' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_CASH_FLOW_PAST_GIRO_ARCHIVE
),
-- Union
ALL as (
    select *
    from CURR
    union all
    select *
    from ARCH
)
select *
from ALL;
grant select on AMC.READ_CASH_FLOW_PAST_GIRO to group NLB_MW_ADAP_S_GNI_TROOPER_EBA_R;
-- CI END FOR ALL TAPES

