-- CI START FOR ALL TAPES
drop view AMC.READ_PROTECTION;
create or replace view AMC.READ_PROTECTION as
with
-- Current
CURR as (
    select *, 'CURRENT' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_COLLATERALIZATION_PROTECTION_CURRENT
),
-- Archiv
ARCH as (
    select *, 'ARCHIVE' as FLAG_CURRENT_ARCHIVE
    from AMC.TABLE_COLLATERALIZATION_PROTECTION_CURRENT
),
-- Union
ALL as (
    select *
    from CURR
    union all
    select *
    from ARCH
)
select *
from ALL;
grant select on AMC.READ_PROTECTION to group NLB_MW_ADAP_S_GNI_TROOPER_EBA_R;
-- CI END FOR ALL TAPES

