-- Test for Source Tables with a Cut-Off-date but without non Stage 9 entries.
-- TODO: Archive ignorieren?
drop view CALC.AUTO_VIEW_TEST_T2S_UNUSED_CUTOFFDATE;
create or replace view CALC.AUTO_VIEW_TEST_T2S_UNUSED_CUTOFFDATE as
select TABSCHEMA_SOURCE as TABSCHEMA, TABNAME_SOURCE as TABNAME, 'Source table has a cut off date but never requires to be updated.' AS MESSAGE from
  (
      select TABSCHEMA_SOURCE, TABNAME_SOURCE, SUM(Is_not_stage_9) AS HAS_NON_9
      from (
               select T2S.TABSCHEMA AS TABSCHEMA_SOURCE,
                      T2S.TABNAME AS TABNAME_SOURCE,
                      case when STAGE_REQUIRED_AT = 9 then 0 else 1 end as Is_not_stage_9
               from CALC.AUTO_VIEW_TARGET_TO_SOURCES AS T2S
                        left join CALC.AUTO_VIEW_TARGETS AS T
                                  on T.TABSCHEMA = T2S.TABSCHEMA and T.TABNAME = T2S.TABNAME
               where T.COLNAME_CUT_OFF_DATE is not NULL
           )
      group by TABSCHEMA_SOURCE, TABNAME_SOURCE
  )
where HAS_NON_9 = 0
;
