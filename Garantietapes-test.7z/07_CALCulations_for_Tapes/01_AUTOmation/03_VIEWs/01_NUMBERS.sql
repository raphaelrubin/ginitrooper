drop view CALC.AUTO_VIEW_NUMBERS;
create view CALC.AUTO_VIEW_NUMBERS as
with NUMBERS(NUMBER) as (
    select 1 as NUMBER from SYSIBM.SYSDUMMY1
    union all
    select NUMBER+1 from NUMBERS
    where NUMBER < 512
)
select * from NUMBERS
;

