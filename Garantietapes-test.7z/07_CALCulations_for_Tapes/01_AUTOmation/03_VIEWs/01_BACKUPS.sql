drop view CALC.AUTO_VIEW_BACKUPS;
create or replace view CALC.AUTO_VIEW_BACKUPS as
    with BACKUPS_PRE as (
        select BACKUPS.TABSCHEMA,
               trim(BOTH '_' FROM trim(replace(replace(BACKUPS.TABNAME, 'BACKUP', ''), VARCHAR_FORMAT(BACKUPS.CREATE_TIME,'YYYYMMDDHH24MISS'), ''))) as TABNAME,
               BACKUPS.TABNAME                                                                 as TABNAME_BACKUP,
               DATE(BACKUPS.CREATE_TIME)                                                       as CREATED_AT,
               case when AVGROWSIZE > 0 then TRUE else FALSE end                               as CONTAINS_DATA
        from SYSCAT.TABLES as BACKUPS
        where BACKUPS.TABNAME like '%BACKUP%'
    ),
    BACKUPS as (
        select BACKUPS_PRE.* from BACKUPS_PRE
        inner join SYSCAT.TABLES as TABLES on BACKUPS_PRE.TABSCHEMA = TABLES.TABSCHEMA and BACKUPS_PRE.TABNAME = TABLES.TABNAME
    )
select * from BACKUPS
;


