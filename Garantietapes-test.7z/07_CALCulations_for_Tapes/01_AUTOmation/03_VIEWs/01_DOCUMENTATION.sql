/* CALC.AUTO_VIEW_DOCUMENTATION
 *
 * Diese View zeigt eine Übersicht über alle Tabellen, Views, Prozeduren und Funktionen und deren Bedeutung/Verwendungszweck.
 */

drop view CALC.AUTO_VIEW_DOCUMENTATION;
create or replace view CALC.AUTO_VIEW_DOCUMENTATION as
with GROUPS as (
    -- Tables & Views
    select TABSCHEMA AS SCHEMA, TABNAME AS NAME, NULL as SIGNATURE, REMARKS
    from SYSCAT.TABLES where TABSCHEMA = 'CALC' and TABNAME like 'AUTO_%'
    union all
    -- Functions
    select FUNCSCHEMA AS SCHEMA, FUNCNAME AS NAME, PARM_SIGNATURE as SIGNATURE, REMARKS
    from SYSCAT.FUNCTIONS where FUNCSCHEMA = 'CALC' and FUNCNAME like 'AUTO_%'
    union all
    -- Procedures
    select PROCSCHEMA AS SCHEMA, PROCNAME AS NAME, PARM_SIGNATURE AS SIGNATURE, REMARKS
    from SYSCAT.PROCEDURES where PROCSCHEMA = 'CALC' and (PROCNAME like 'AUTO_%' or PROCNAME like 'DO_%' or PROCNAME like 'HELP_%' or PROCNAME = 'HELP')
)
select
       SCHEMA,
       NAME,
       -- Convert Signature hex code
       '('||cast(TRIM(B ',' FROM TRIM(B ' ' FROM REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(SIGNATURE,x'00',''),x'2C','CLOB, '),x'3C','CHAR, '),x'38','VARCHAR, '),x'70','BOOLEAN, '),x'64','DATE, '),x'14','BIGINT, '),x'18','INT, '))) AS VARCHAR(512)) ||')' as SIGNATURE,
       REMARKS
from GROUPS
;
comment on table CALC.AUTO_VIEW_DOCUMENTATION is 'Übersicht über alle Tabellen, Views, Prozeduren und Funktionen und deren Bedeutung/Verwendungszweck';


