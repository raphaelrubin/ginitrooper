/* CALC.AUTO_VIEW_TARGETS
 *
 * Diese View zeigt die TARGETS für das aktuell aktive Tape.
 */

drop view CALC.AUTO_VIEW_TARGETS;
create or replace view CALC.AUTO_VIEW_TARGETS as
with ACTIVE_TAPE as (
    select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1
)
select
    case
        when BUILD_VIEW_SCHEMA = 'CALC' and TABSCHEMA <> 'CALC' then
            ACTIVE_TAPE.NAME
        else
            TABSCHEMA
    end as TABSCHEMA,
    TABNAME, COLNAME_CUT_OFF_DATE, TYPE, IS_AUTOMATEABLE,
    DO_TRUNCATE_BEFORE_BUILD, BUILDCODE, BUILD_VIEW_SCHEMA, RECREATECODE,
    CREATED_AT, CREATED_BY, LAST_CHANGED_AT, LAST_CHANGED_BY
from CALC.AUTO_TABLE_TARGETS AS T
full outer join ACTIVE_TAPE on 1=1
;
comment on table CALC.AUTO_VIEW_TARGETS is 'Liste aller Tabellen aus dem aktiven Tape';
