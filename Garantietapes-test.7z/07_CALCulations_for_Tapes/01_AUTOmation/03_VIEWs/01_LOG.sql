/* CALC.AUTO_VIEW_LOG
 *
 * Diese View zeigt den aktuellen Log auf Info Level mit uncommitted read - kann also immer ausgeführt werden.
 */

drop view CALC.AUTO_VIEW_LOG;
create or replace view CALC.AUTO_VIEW_LOG as
with ordered_data as (
    select CREATED_AT, LEVEL, MESSAGE, CREATED_BY, row_number() over (order by CREATED_AT DESC) AS ORDER_NUMBER
    from CALC.AUTO_TABLE_LOG
    where LEVEL <> 'DEBUG'
      and CREATED_AT > CURRENT_TIMESTAMP - 3 DAYS
    with UR
)
select CREATED_AT, LEVEL, MESSAGE from ordered_data where ORDER_NUMBER <= 500
;
comment on table CALC.AUTO_VIEW_LOG is 'Darstellung des Log.';
