/* CALC.AUTO_VIEW_TARGET_TO_SOURCES
 *
 * Diese View zeigt die TARGETS_TO_SOURCES für das aktuell aktive Tape.
 */

-- create or replace view CALC.AUTO_VIEW_TARGET_TO_SOURCES_OLD as
--     select
--         T2S.TABSCHEMA_SOURCE || '.' || T2S.TABNAME_SOURCE   as TABLENAME,
--         T2S.TABSCHEMA_SOURCE                                as TABSCHEMA,
--         T2S.TABNAME_SOURCE                                  as TABNAME,
--         S.COLNAME_CUT_OFF_DATE                              as CUT_OFF_DATE_COLNAME,
--         T2S.REQUIRED                                        as IS_REQUIRED_AT_ALL,
--         T2S.STAGE_REQUIRED_AT                               as STAGE_REQUIRED_AT,
--         T2S.TABSCHEMA_TARGET,
--         T2S.TABNAME_TARGET,
--         T2S.VALID_FROM,
--         T2S.VALID_UNTIL
--     from CALC.SWITCH_AUTO_TARGET_TO_SOURCES as T2S
--     left join CALC.SWITCH_AUTO_TARGETS as S on T2S.TABSCHEMA_SOURCE = S.TABSCHEMA and T2S.TABNAME_SOURCE = S.TABNAME
--     with UR
-- ;
-- comment on table CALC.AUTO_VIEW_TARGET_TO_SOURCES_OLD is 'Übersicht über Tabellenverbindungen - wird in dieser Form in der CHECK_REQUIREMENTS Prozedur gebraucht';

drop view CALC.AUTO_VIEW_TARGET_TO_SOURCES;
create or replace view CALC.AUTO_VIEW_TARGET_TO_SOURCES as
with
    -- Das momentan aktive Tape
    ACTIVE_TAPE as (
        select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1
    ),
    -- eine Liste aller anderen Tapes
    INACTIVE_TAPES as (
        select NAME from CALC.AUTO_TABLE_TAPES where not IS_ACTIVE
    ),
    DATA as (
        select distinct
            -- TABSCHEMA wird auf das aktive Tape gesetzt, wenn es sich um eine auf CALC basierte Tabelle handelt.
            -- Es sei denn, die tabelle ist auch in CALC. so werden alle (meist als AMC) eingetragenen Beziehungen
            -- in das aktuelle Tape umgewandelt.
            case
               when COALESCE(S.BUILD_VIEW_SCHEMA,SV.BUILD_VIEW_SCHEMA) = 'CALC' and T2S.TABSCHEMA_SOURCE <> 'CALC' then
                   ACTIVE_TAPE.NAME
               else
                   T2S.TABSCHEMA_SOURCE
            end                                               as TABSCHEMA,
            T2S.TABNAME_SOURCE                                as TABNAME,
            COALESCE(S.COLNAME_CUT_OFF_DATE,SV.COLNAME_CUT_OFF_DATE) as CUT_OFF_DATE_COLNAME,
            T2S.REQUIRED                                      as IS_REQUIRED_AT_ALL,
            T2S.STAGE_REQUIRED_AT                             as STAGE_REQUIRED_AT,
            -- für das Target schema erfolgt die gleiche Umwandlung wie für Source.
            case
               when COALESCE(T.BUILD_VIEW_SCHEMA,TV.BUILD_VIEW_SCHEMA) = 'CALC' and T2S.TABSCHEMA_TARGET <> 'CALC' then
                   ACTIVE_TAPE.NAME
               else
                   T2S.TABSCHEMA_TARGET
            end                                               as TABSCHEMA_TARGET,
            T2S.TABNAME_TARGET,
            COALESCE(S.BUILD_VIEW_SCHEMA,SV.BUILD_VIEW_SCHEMA) AS BUILD_VIEW_SCHEMA_SOURCE,
            COALESCE(T.BUILD_VIEW_SCHEMA,TV.BUILD_VIEW_SCHEMA) AS BUILD_VIEW_SCHEMA_TARGET,
            T2S.VALID_FROM,
            T2S.VALID_UNTIL
        from CALC.AUTO_TABLE_TARGET_TO_SOURCES as T2S
        left join CALC.AUTO_TABLE_TARGETS      as S
               on T2S.TABSCHEMA_SOURCE = S.TABSCHEMA and T2S.TABNAME_SOURCE = S.TABNAME
        left join CALC.AUTO_VIEW_TARGETS      as SV
               on T2S.TABSCHEMA_SOURCE = SV.TABSCHEMA and T2S.TABNAME_SOURCE = SV.TABNAME
        left join CALC.AUTO_TABLE_TARGETS      as T
               on T2S.TABSCHEMA_TARGET = T.TABSCHEMA and T2S.TABNAME_TARGET = T.TABNAME
        left join CALC.AUTO_VIEW_TARGETS      as TV
               on T2S.TABSCHEMA_TARGET = TV.TABSCHEMA and T2S.TABNAME_TARGET = TV.TABNAME
        full outer join ACTIVE_TAPE on 1 = 1
        where (COALESCE(T.BUILD_VIEW_SCHEMA,TV.BUILD_VIEW_SCHEMA) not in (select * from INACTIVE_TAPES) )
          and (COALESCE(S.BUILD_VIEW_SCHEMA,SV.BUILD_VIEW_SCHEMA) not in (select * from INACTIVE_TAPES) )
        --with UR
    )
select TABSCHEMA || '.' || TABNAME as TABLENAME,* from DATA
;
comment on table CALC.AUTO_VIEW_TARGET_TO_SOURCES is 'Übersicht über Tabellenverbindungen - wird in dieser Form in der CHECK_REQUIREMENTS Prozedur gebraucht';
