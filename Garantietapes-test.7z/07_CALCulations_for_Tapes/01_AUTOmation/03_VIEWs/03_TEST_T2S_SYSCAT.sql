/* CALC.AUTO_VIEW_TEST_T2S_SYSCAT
 *
 * Test, welche Beziehungen aus der T2S nicht mit den Beziehungen in der Syscat übereinstimmen.
 */
drop view CALC.AUTO_VIEW_TEST_T2S_SYSCAT;
create or replace view CALC.AUTO_VIEW_TEST_T2S_SYSCAT as
with
    active_tape as (
        select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE
    ),
    base_links_all as (
        select active_tape.NAME                                   AS SYS_TABSCHEMA_TARGET,
               REPLACE(VIEWNAME, 'VIEW_', 'TABLE_') || '_CURRENT' AS SYS_TABNAME_TARGET,
               case when LEFT(BNAME, 6) = 'SWITCH' then
                   active_tape.NAME
               else
                   TRIM(BSCHEMA)
               end                                                AS SYS_TABSCHEMA_SOURCE,
               case when LEFT(BNAME, 6) = 'SWITCH' then
                    REPLACE(BNAME,'SWITCH_','TABLE_')
               else
                   BNAME
               end                                                AS SYS_TABNAME_SOURCE,
               BTYPE                                              AS SYS_TYPE_SOURCE
        from SYSCAT.VIEWDEP
        full outer join active_tape on 1=1
        where (VIEWSCHEMA = 'CALC' or VIEWSCHEMA = active_tape.NAME)
          and LEFT(VIEWNAME, 4) = 'VIEW'
          and TRIM(BSCHEMA) not in ('SYSIBMADM','SYSFUN','SYSIBM')
    ),
     base_links as ( -- sicherstellen, dass dies wirklich eine Tabelle ist
       select ALLT.*
       from base_links_all as ALLT
       left join SYSCAT.TABLES as REALT on (ALLT.SYS_TABSCHEMA_TARGET, ALLT.SYS_TABNAME_TARGET) = (REALT.TABSCHEMA,REALT.TABNAME)
       where REALT.TABNAME is not NULL
     ),
     View_links as (
        select TRIM(VIEWSCHEMA)                                   AS SYS_TABSCHEMA_TARGET,
               VIEWNAME                                           AS SYS_TABNAME_TARGET,
               case when LEFT(BNAME, 6) = 'SWITCH' then
                   active_tape.NAME
               else
                   TRIM(BSCHEMA)
               end                                                AS SYS_TABSCHEMA_SOURCE,
               case when LEFT(BNAME, 6) = 'SWITCH' then
                    REPLACE(BNAME,'SWITCH_','TABLE_')
               else
                   BNAME
               end                                                AS SYS_TABNAME_SOURCE,
               BTYPE                                              AS SYS_TYPE_SOURCE
        from SYSCAT.VIEWDEP
        full outer join active_tape on 1=1
        where (VIEWSCHEMA = 'CALC' or VIEWSCHEMA = active_tape.NAME)
          and LEFT(VIEWNAME, 4) = 'VIEW'
          and TRIM(BSCHEMA) not in ('SYSIBMADM','SYSFUN','SYSIBM')
    ),
    syscat_links_2 as (
        select distinct
               B.SYS_TABSCHEMA_TARGET as SYS_TABSCHEMA_TARGET,
               B.SYS_TABNAME_TARGET,
               coalesce(V.SYS_TABSCHEMA_SOURCE,B.SYS_TABSCHEMA_SOURCE) AS SYS_TABSCHEMA_SOURCE,
               coalesce(V.SYS_TABNAME_SOURCE,B.SYS_TABNAME_SOURCE) AS SYS_TABNAME_SOURCE,
               coalesce(V.SYS_TYPE_SOURCE,B.SYS_TYPE_SOURCE) AS SYS_TYPE_SOURCE
        from base_links as B
        left join view_links as V on (B.SYS_TABSCHEMA_SOURCE,B.SYS_TABNAME_SOURCE) = (V.SYS_TABSCHEMA_TARGET, V.SYS_TABNAME_TARGET)
    ),
    syscat_links_1 as (
        select distinct
               B.SYS_TABSCHEMA_TARGET as SYS_TABSCHEMA_TARGET,
               B.SYS_TABNAME_TARGET,
               coalesce(V.SYS_TABSCHEMA_SOURCE,B.SYS_TABSCHEMA_SOURCE) AS SYS_TABSCHEMA_SOURCE,
               coalesce(V.SYS_TABNAME_SOURCE,B.SYS_TABNAME_SOURCE) AS SYS_TABNAME_SOURCE,
               coalesce(V.SYS_TYPE_SOURCE,B.SYS_TYPE_SOURCE) AS SYS_TYPE_SOURCE
        from syscat_links_2 as B
        left join view_links as V on (B.SYS_TABSCHEMA_SOURCE,B.SYS_TABNAME_SOURCE) = (V.SYS_TABSCHEMA_TARGET, V.SYS_TABNAME_TARGET)
    ),
    syscat_links as (
        select distinct
               B.SYS_TABSCHEMA_TARGET as SYS_TABSCHEMA_TARGET,
               B.SYS_TABNAME_TARGET,
               coalesce(V.SYS_TABSCHEMA_SOURCE,B.SYS_TABSCHEMA_SOURCE) AS SYS_TABSCHEMA_SOURCE,
               coalesce(V.SYS_TABNAME_SOURCE,B.SYS_TABNAME_SOURCE) AS SYS_TABNAME_SOURCE,
               coalesce(V.SYS_TYPE_SOURCE,B.SYS_TYPE_SOURCE) AS SYS_TYPE_SOURCE
        from syscat_links_1 as B
        left join view_links as V on (B.SYS_TABSCHEMA_SOURCE,B.SYS_TABNAME_SOURCE) = (V.SYS_TABSCHEMA_TARGET, V.SYS_TABNAME_TARGET)
    )
--select * from syscat_links;
select
    case when T2S.TABSCHEMA is NULL and SYS_TABNAME_TARGET <> SYS_TABNAME_SOURCE then
        SYS_TABSCHEMA_TARGET
    when SYS_TABSCHEMA_SOURCE is NULL then
        TABSCHEMA_TARGET
    else
        ''
    end as TABSCHEMA,
    case when T2S.TABSCHEMA is NULL and SYS_TABNAME_TARGET <> SYS_TABNAME_SOURCE then
        SYS_TABNAME_TARGET
    when SYS_TABSCHEMA_SOURCE is NULL then
        TABNAME_TARGET
    else
        ''
    end as TABNAME,
    case when T2S.TABSCHEMA is NULL and SYS_TABNAME_TARGET <> SYS_TABNAME_SOURCE then
        SYS_TABSCHEMA_TARGET||'.'||SYS_TABNAME_TARGET||' <- '||SYS_TABSCHEMA_SOURCE||'.'||SYS_TABNAME_SOURCE||' missing according to SYSCAT'
    when SYS_TABSCHEMA_SOURCE is NULL then
        TABSCHEMA_TARGET||'.'||TABNAME_TARGET||' <- '||T2S.TABSCHEMA||'.'||T2S.TABNAME||' not valid according to SYSCAT'
    else
        ''
    end as MESSAGE
from syscat_links AS SYS
full outer join CALC.AUTO_VIEW_TARGET_TO_SOURCES AS T2S on (SYS_TABSCHEMA_TARGET,SYS_TABNAME_TARGET,SYS_TABSCHEMA_SOURCE,SYS_TABNAME_SOURCE) = (TABSCHEMA_TARGET,TABNAME_TARGET,T2S.TABSCHEMA,T2S.TABNAME)
WHERE (SYS_TABSCHEMA_SOURCE is NULL or T2S.TABSCHEMA is NULL)
  and (TABNAME_TARGET is NULL or TABNAME_TARGET <> CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(T2S.TABSCHEMA,T2S.TABNAME))
;


-- Kommentar für CI-Test