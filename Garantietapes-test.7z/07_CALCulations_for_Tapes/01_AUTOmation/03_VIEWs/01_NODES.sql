/* CALC.AUTO_VIEW_NODES
 *
 * Diese View zeigt die einzelnen Tabellen. Dies kann als Knotenpunkte für Graphen-visualisierungen verwendet werden.
 */
drop view CALC.AUTO_VIEW_NODES;
create or replace view CALC.AUTO_VIEW_NODES as
    select distinct TABSCHEMA||'.'||TABNAME as NODE from CALC.AUTO_TABLE_TARGETS
union all
    select distinct
       'AMC' || '.' || TABNAME as NODE from CALC.SWITCH_AUTO_GROUPS where TABNAME like 'TAPE_%_FINISH'
;
comment on table CALC.AUTO_VIEW_NODES is 'Liste aller Knotenpunkte - nützlich für externe Graphendarstellung';
