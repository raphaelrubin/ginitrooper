drop view CALC.AUTO_VIEW_BACKUPS_TO_DROP;
create or replace view CALC.AUTO_VIEW_BACKUPS_TO_DROP as
    with BACKUPS_ALL as (
        select * from CALC.AUTO_VIEW_BACKUPS
    ),
    BACKUPS as (
        select TABSCHEMA, TABNAME, TABNAME_BACKUP, CREATED_AT from BACKUPS_ALL
        where CONTAINS_DATA or CREATED_AT >= CURRENT_DATE - 4 DAYS -- neue Backups wurden noch nicht analysiert und sehen daher leer aus auch wenn sie Daten enthalten.
    ),
    KEEP_THIS_WEEK as (
        select distinct first_value(TABSCHEMA)
                                    over (partition by TABSCHEMA, TABNAME, DATE(CREATED_AT) order by CREATED_AT DESC) as TABSCHEMA,
                        first_value(TABNAME)
                                    over (partition by TABSCHEMA, TABNAME, DATE(CREATED_AT) order by CREATED_AT DESC) as TABNAME,
                        first_value(TABNAME_BACKUP)
                                    over (partition by TABSCHEMA, TABNAME, DATE(CREATED_AT) order by CREATED_AT DESC) as TABNAME_BACKUP,
                        first_value(CREATED_AT)
                                    over (partition by TABSCHEMA, TABNAME, DATE(CREATED_AT) order by CREATED_AT DESC) as CREATED_AT
        from BACKUPS
        where CREATED_AT >= CURRENT_DATE - 7 DAYS
    ),
    KEEP_THIS_MONTH as (
        select distinct first_value(TABSCHEMA)
                                    over (partition by TABSCHEMA, TABNAME, WEEK_ISO(CREATED_AT) order by CREATED_AT DESC) as TABSCHEMA,
                        first_value(TABNAME)
                                    over (partition by TABSCHEMA, TABNAME, WEEK_ISO(CREATED_AT) order by CREATED_AT DESC) as TABNAME,
                        first_value(TABNAME_BACKUP)
                                    over (partition by TABSCHEMA, TABNAME, WEEK_ISO(CREATED_AT) order by CREATED_AT DESC) as TABNAME_BACKUP,
                        first_value(CREATED_AT)
                                    over (partition by TABSCHEMA, TABNAME, WEEK_ISO(CREATED_AT) order by CREATED_AT DESC) as CREATED_AT
        from BACKUPS
        where CREATED_AT < CURRENT_DATE - 7 DAYS
          and CREATED_AT >= CURRENT_DATE - 2 MONTHS
    ),
    KEEP_THIS_YEAR as (
        select distinct first_value(TABSCHEMA)
                                    over (partition by TABSCHEMA, TABNAME, MONTH(CREATED_AT) order by CREATED_AT DESC) as TABSCHEMA,
                        first_value(TABNAME)
                                    over (partition by TABSCHEMA, TABNAME, MONTH(CREATED_AT) order by CREATED_AT DESC) as TABNAME,
                        first_value(TABNAME_BACKUP)
                                    over (partition by TABSCHEMA, TABNAME, MONTH(CREATED_AT) order by CREATED_AT DESC) as TABNAME_BACKUP,
                        first_value(CREATED_AT)
                                    over (partition by TABSCHEMA, TABNAME, MONTH(CREATED_AT) order by CREATED_AT DESC) as CREATED_AT
        from BACKUPS
        where CREATED_AT < CURRENT_DATE - 2 MONTHS
          and CREATED_AT >= CURRENT_DATE - 1 YEAR
    ),
    KEEP_PAST_YEARS as (
        select distinct first_value(TABSCHEMA)
                                    over (partition by TABSCHEMA, TABNAME, YEAR(CREATED_AT) order by CREATED_AT DESC) as TABSCHEMA,
                        first_value(TABNAME)
                                    over (partition by TABSCHEMA, TABNAME, YEAR(CREATED_AT) order by CREATED_AT DESC) as TABNAME,
                        first_value(TABNAME_BACKUP)
                                    over (partition by TABSCHEMA, TABNAME, YEAR(CREATED_AT) order by CREATED_AT DESC) as TABNAME_BACKUP,
                        first_value(CREATED_AT)
                                    over (partition by TABSCHEMA, TABNAME, YEAR(CREATED_AT) order by CREATED_AT DESC) as CREATED_AT
        from BACKUPS
        where CREATED_AT < CURRENT_DATE - 1 YEAR
    ), KEEP as (
        select * from KEEP_THIS_WEEK
        union all
        select * from KEEP_THIS_MONTH
        union all
        select * from KEEP_THIS_YEAR
        union all
        select * from KEEP_PAST_YEARS
    ), DELETE as (
        select TABSCHEMA, TABNAME, TABNAME_BACKUP, CREATED_AT from BACKUPS_ALL except
        select * from KEEP
    )
    select TABSCHEMA, TABNAME, TABNAME_BACKUP, 'drop table '||trim(TABSCHEMA)||'.'||TABNAME_BACKUP as DROP_STATEMENT from DELETE
;
