/* View um die Gruppen des aktiven tapes um die Sondergruppe "SOURCES" die für die Validierung wichtig ist zu erweitern.
 */

-- VIEW erstellen
------------------------------------------------------------------------------------------------------------------------
drop view CALC.AUTO_VIEW_GROUPS_EXPANDED;
create or replace view CALC.AUTO_VIEW_GROUPS_EXPANDED as
    select TABNAME, GROUPNAME, EXPORTNAME, CREATED_AT, CREATED_BY, LAST_CHANGED_AT, LAST_CHANGED_BY from CALC.SWITCH_AUTO_GROUPS
union
    select TABNAME, 'SOURCES', TABNAME, CURRENT_TIMESTAMP, CURRENT_USER, CURRENT_TIMESTAMP, CURRENT_USER
    from CALC.AUTO_TABLE_TARGETS
    where TABSCHEMA in ('NLB','BLB','ANL','CBB','DH','SMAP','IMAP')
;

------------------------------------------------------------------------------------------------------------------------
