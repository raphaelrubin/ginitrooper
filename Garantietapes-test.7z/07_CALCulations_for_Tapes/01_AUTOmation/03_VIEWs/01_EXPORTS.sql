/* CALC.AUTO_VIEW_EXPORTS
 *
 * Diese View zeigt eine Übersicht für die Tape Exporte.
 */

drop view CALC.AUTO_VIEW_EXPORTS;
create or replace view CALC.AUTO_VIEW_EXPORTS as
    select
           CUT_OFF_DATE,
           GROUPNAME,
           MAX(VERSION) as VERSION,
           MAX(LAST_CHANGED_AT) as LAST_EXPORTET_AT,
           SUM(GETOETETE_ALPAKA) as GETOETETE_ALPAKA,
           SUM(STERNE) as STERNE
    from CALC.AUTO_TABLE_EXPORT_VERSIONS
    group by CUT_OFF_DATE, GROUPNAME
;
comment on table CALC.AUTO_VIEW_EXPORTS is 'Übersicht über die neuesten Exporte für einzelne Stichtage.';
