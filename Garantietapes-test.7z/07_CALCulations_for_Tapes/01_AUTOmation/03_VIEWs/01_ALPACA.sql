/* CALC.AUTO_VIEW_ALPACA
 *
 * Diese View zeigt die Anzahl an Alpaka und Magischen Sternen.
 */
drop view CALC.AUTO_VIEW_ALPACA;
create or replace view CALC.AUTO_VIEW_ALPACA as
    select
           SUM(CHANGE) AS ALPACA,
           SUM(STARS_CHANGE) as STARS
    from CALC.AUTO_TABLE_ALPACA
;
comment on table CALC.AUTO_VIEW_ALPACA is 'Übersicht über die Anzahl an Alpaka und Magischen Sternen.';

