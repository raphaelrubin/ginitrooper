/* CALC.AUTO_VIEW_TABLE_BUILD_STATE
 *
 * Diese View zeigt eine Übersicht über alle gebauten Tabellen, deren Stichtag und letzten Export
 */

drop view CALC.AUTO_VIEW_TABLE_BUILD_STATE;
create or replace view CALC.AUTO_VIEW_TABLE_BUILD_STATE as
    with
    builds as (
        select TABSCHEMA,
               TABNAME,
               CUT_OFF_DATE,
               VERSION,
               CREATED_AT,
               CREATED_BY,
               row_number() over (partition by TABSCHEMA, TABNAME order by CREATED_AT DESC) as ORDER_NUMBER
        from CALC.AUTO_TABLE_CHECK_BUILD
        with UR
    ),
    exports as (
        select
            TAPENAME as TABSCHEMA,
            CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME,
            CUT_OFF_DATE,
            VERSION,
            CREATED_AT,
            CREATED_BY
        from CALC.AUTO_TABLE_EXPORT_VERSIONS
    ),
    joined_data as (
        select builds.TABSCHEMA,
               builds.TABNAME,
               builds.CUT_OFF_DATE,
               builds.VERSION                                                                   as BUILD_VERSION,
               builds.CREATED_AT                                                                as BUILD_AT,
               builds.CREATED_BY                                                                as BUILD_BY,
               exports.VERSION                                                                  as EXPORT_VERSION,
               exports.CREATED_AT                                                               as EXPORTED_AT,
               exports.CREATED_BY                                                               as EXPORTED_BY,
               row_number() over (partition by builds.TABNAME order by exports.CREATED_AT DESC) as ORDER_NUMBER
        from builds
                 left join exports on (builds.TABSCHEMA, builds.TABNAME, builds.CUT_OFF_DATE) =
                                      (exports.TABSCHEMA, exports.TABNAME, exports.CUT_OFF_DATE) --and builds.CREATED_AT < exports.CREATED_AT
        where builds.ORDER_NUMBER = 1
    )
select TABSCHEMA, TABNAME, CUT_OFF_DATE, BUILD_VERSION, BUILD_AT, BUILD_BY, EXPORT_VERSION, EXPORTED_AT, EXPORTED_BY
from joined_data
where ORDER_NUMBER = 1;
;
comment on table CALC.AUTO_VIEW_TABLE_BUILD_STATE is 'Übersicht über alle gebauten Tabellen, deren Stichtag und letzten Export';
