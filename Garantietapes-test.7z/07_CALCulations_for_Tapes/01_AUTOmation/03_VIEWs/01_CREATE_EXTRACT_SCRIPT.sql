-- Teil der Export routine, die den Exportbefehl erstellt


drop view CALC.AUTO_VIEW_CREATE_EXTRACT_SCRIPT;
create or replace view CALC.AUTO_VIEW_CREATE_EXTRACT_SCRIPT as
select
  'call sysproc.admin_cmd('''
    -- start of export statement
    || 'export to '
    -- Export Path (already included?)
    --|| '/data/work/dbblossom/export/'
    --|| VARCHAR_FORMAT(CURRENT timestamp, 'YYYYMMDDHH24MI')
    --|| '_'
    || B.TABNAME
    || '.csv of del modified by coldel; codepage=1208 '
    -- start of select statement
    || 'select '
    -- list of all columns
    ||
      (
        select COLS from (
		    select left(COLs, LENGTH(cols)- 1) as COLS, TABNAME
             from (select xmlserialize(
                            xmlagg(
                              xmlconcat(
                                xmltext(COLNAME),
                                xmltext(',')
                                  )

                                order by COLNO) as varchar(32000)
                              ) as COLS, TABNAME
                   from SYSCAT.COLUMNS
                   where 1 = 1
                     and (TABSCHEMA in ('TMP','MAP','AMC','ZDF') and translate(right(TABNAME,2),'          ','1234567890') = ''
                      or TABSCHEMA in ('TMP','MAP','AMC','ZDF') and LEFT(TABNAME,15)='PSEUDONYM_TABLE'
                     )
                   group by tabname)
                         ) as A
                    where A.TABNAME=B.TABNAME
        )

        || ' from  ( select ' ||
        (
        select COLS from (
		    select COLS || '1 as RNK' as COLS, TABNAME
             from (select xmlserialize(
                            xmlagg(
                              xmlconcat(
                                xmltext(''''''),
                                xmltext(COLNAME),
                                 xmltext(''''''),
                                xmltext(' as '),
                                xmltext(COLNAME),
                                xmltext(',')
                                  )

                                order by COLNO) as varchar(32000)
                              ) as COLS, TABNAME
                   from SYSCAT.COLUMNS
                   where 1 = 1
                     and (TABSCHEMA in ('TMP','MAP','AMC','ZDF') and translate(right(TABNAME,2),'          ','1234567890') = ''
                      or TABSCHEMA in ('TMP','MAP','AMC','ZDF') and LEFT(TABNAME,15)='PSEUDONYM_TABLE'
                     )
                   group by tabname)
                         )as A
                    where A.TABNAME=B.TABNAME
        )
        || ' from sysibm.sysdummy1'
        || ' union all '
        || ' select distinct '
        ||
        (
        select COLS from (
         select COLS || '2 as RNK' as COLS, TABNAME from (
        select xmlserialize(
                            xmlagg(
                              xmlconcat(
                                xmltext( ' trim(' ||
                                case
                                  when typename in ('DECIMAL','DOUBLE','DECFLOAT','FLOAT') then ' CALC.DOUBLE_TO_STRING(' || COLNAME || ') ) as '
                                  when typename  = 'DATE' then 'varchar_format(' || COLNAME || ',''''YYYY-MM-DD'''') ) as '
                                  when typename  = 'TIMESTAMP' then 'varchar_format(' || COLNAME || ',''''YYYY-MM-DD'''') ) as '
                                  else 'cast(' || COLNAME || ' as VARCHAR (32000) ) ) as '
                                  end
                                  ),
                                xmltext(COLNAME),
                                xmltext(',')
                                  )

                                order by COLNO) as varchar(32000)
                              ) as COLS, TABNAME
                   from SYSCAT.COLUMNS
                   where 1 = 1
                     and (TABSCHEMA in ('TMP','MAP','AMC','ZDF') and translate(right(TABNAME,2),'          ','1234567890') = ''
                      or TABSCHEMA in ('TMP','MAP','AMC','ZDF') and LEFT(TABNAME,15)='PSEUDONYM_TABLE'
                     )
                   group by tabname

          )
        )as A
           where A.TABNAME=B.TABNAME
        )
        || ' from ' || B.TABSCHEMA || '.' || B.TABNAME || ') order by rnk'')'


        as CODE
        ,B.TABNAME
    from syscat.tables as B
    where 1=1
    and (B.TABSCHEMA in ('TMP','MAP','AMC','ZDF') and translate(right(B.TABNAME,2),'          ','1234567890') = ''
     or B.TABSCHEMA in ('TMP','MAP','AMC','ZDF') and LEFT(B.TABNAME,15)='PSEUDONYM_TABLE'
    )
    ;
