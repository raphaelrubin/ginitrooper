/* CALC.AUTO_VIEW_GROUPS
 *
 * Diese View zeigt eine Übersicht für die Gruppen für BUILD_GROUP und EXPORT_GROUP.
 */

drop view CALC.AUTO_VIEW_GROUPS;
create or replace view CALC.AUTO_VIEW_GROUPS as
    with
    ACTIVE_TAPE as (
        select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE
    ),
    CLEANED_DATA as (
        select distinct
            TAPE.NAME as TAPENAME,
            GROUPS.GROUPNAME,
            GROUPS.DESCRIPTION,
            CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABLES.TABNAME) as TABNAME
        from CALC.AUTO_TABLE_GROUPS AS GROUPS
        left join CALC.SWITCH_AUTO_GROUPS AS TABLES on GROUPS.GROUPNAME = TABLES.GROUPNAME
        full outer join ACTIVE_TAPE AS TAPE on 1=1
    ), AGGREGATED_DATA as (
        select distinct
            TAPENAME,
            GROUPNAME,
            first_value(DESCRIPTION) over (partition by TAPENAME,GROUPNAME order by DESCRIPTION DESC nulls last) as DESCRIPTION,
            LISTAGG(TABNAME || ',') over (partition by TAPENAME,GROUPNAME order by TABNAME) as TABLES,
            ROW_NUMBER() over (partition by TAPENAME,GROUPNAME order by TABNAME DESC) as ORDER_NUMBER
        from CLEANED_DATA
    )
    select distinct
        TAPENAME,
        GROUPNAME,
        DESCRIPTION,
        TRIM(B ',' FROM TABLES) as TABLES
    from AGGREGATED_DATA
    where ORDER_NUMBER = 1
;
comment on table CALC.AUTO_VIEW_GROUPS is 'Übersicht aller Gruppen. GROUPNAME kann als Argument für BUILD_GROUP und EXPORT_GROUP verwendet werden.';
