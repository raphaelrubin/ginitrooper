/* CALC.AUTO_VIEW_LOG_DEBUG
 *
 * Diese View zeigt den aktuellen Log im Detail mit uncommitted read - kann also immer ausgeführt werden.
 */
drop view CALC.AUTO_VIEW_LOG_DEBUG;
create or replace view CALC.AUTO_VIEW_LOG_DEBUG as
with ordered_data as (
    select CREATED_AT, LEVEL, MESSAGE, CREATED_BY, row_number() over (order by CREATED_AT DESC) AS ORDER_NUMBER
    from CALC.AUTO_TABLE_LOG
    where CREATED_AT > CURRENT_TIMESTAMP - 7 DAYS
    with UR
)
select CREATED_AT, LEVEL, MESSAGE, CREATED_BY from ordered_data where ORDER_NUMBER <= 1000
;
comment on table CALC.AUTO_VIEW_LOG_DEBUG is 'Darstellung des Log mit DEBUG Level.';