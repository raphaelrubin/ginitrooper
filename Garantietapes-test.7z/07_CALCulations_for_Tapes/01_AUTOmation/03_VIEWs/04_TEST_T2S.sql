/* CALC.AUTO_VIEW_TEST_T2S
 *
 * Diese View zeigt alle Unstimmigkeiten der T2S Tabelle
 */

drop view CALC.AUTO_VIEW_TEST_T2S;
create or replace view CALC.AUTO_VIEW_TEST_T2S as
    select * from CALC.AUTO_VIEW_TEST_T2S_MULTIPLE_STAGES
union all
select * from CALC.AUTO_VIEW_TEST_T2S_UNUSED_CUTOFFDATE
union all
select * from CALC.AUTO_VIEW_TEST_T2S_SYSCAT
;