/* CALC.AUTO_VIEW_TARGETS
 *
 * Diese View zeigt die TARGETS für das aktuell aktive Tape.
 */

drop view CALC.AUTO_VIEW_TARGETS_ALL;
create or replace view CALC.AUTO_VIEW_TARGETS_ALL as
with ALL_TAPES as (
    select distinct NAME from CALC.AUTO_TABLE_TAPES
)
select distinct
    case
        when BUILD_VIEW_SCHEMA = 'CALC' and TABSCHEMA <> 'CALC' then
            ALL_TAPES.NAME
        else
            TABSCHEMA
    end as TABSCHEMA,
    T.TABNAME, T.COLNAME_CUT_OFF_DATE, T.TYPE, T.IS_AUTOMATEABLE,
    T.DO_TRUNCATE_BEFORE_BUILD, T.BUILD_VIEW_SCHEMA
    --CREATED_AT, CREATED_BY, LAST_CHANGED_AT, LAST_CHANGED_BY
from CALC.AUTO_TABLE_TARGETS AS T
full outer join ALL_TAPES on 1=1
;
comment on table CALC.AUTO_VIEW_TARGETS_ALL is 'Liste aller Tabellen für aktuell aktives Tape.';
