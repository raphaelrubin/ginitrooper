/* CALC.AUTO_VIEW_EDGES
 *
 * Diese View zeigt die Verbindungen zwischen Tabellen. Dies kann als Kanten für Graphen-visualisierungen verwendet werden.
 */

drop view CALC.AUTO_VIEW_EDGES;
create or replace view CALC.AUTO_VIEW_EDGES as
    select distinct
        TABSCHEMA||'.'||TABNAME as SOURCE,
        STAGE_REQUIRED_AT as LINK_TYPE,
        TABSCHEMA_TARGET||'.'||TABNAME_TARGET as TARGET
    from CALC.AUTO_VIEW_TARGET_TO_SOURCES
union all
    select distinct
       'AMC' || '.' || CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as SOURCE,
       10 as LINK_TYPE,
       'AMC' || '.' || TABNAME as TARGET
from CALC.SWITCH_AUTO_GROUPS where TABNAME like 'TAPE_%_FINISH';
;
comment on table CALC.AUTO_VIEW_EDGES is 'Liste aller Kanten (Tabellenverbindungen) - nützlich für externe Graphendarstellung';
