/* CALC.AUTO_VIEW_MODES
 *
 * Diese View zeigt alle möglichen Modi
 */
drop view CALC.AUTO_VIEW_MODES;
create or replace view CALC.AUTO_VIEW_MODES as
    select NAME AS MODENAME, DESCRIPTION from CALC.AUTO_TABLE_MODES
;
comment on table CALC.AUTO_VIEW_MODES is 'Übersicht aller Modi. MODENAME kann als Argument für BUILD_GROUP verwendet werden.';
