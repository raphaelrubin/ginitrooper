/* CALC.AUTO_VIEW_TEST_T2S_MULTIPLE_STAGES
 *
 * Test for Source Tables that have different stages (excluding Stage 9)
 */
drop view CALC.AUTO_VIEW_TEST_T2S_MULTIPLE_STAGES;
create or replace view CALC.AUTO_VIEW_TEST_T2S_MULTIPLE_STAGES as
select TABSCHEMA_SOURCE as TABSCHEMA, TABNAME_SOURCE as TABNAME, 'Source table has '||DIFFERENT_STAGES||' different stages.' AS MESSAGE from (
                  select TABSCHEMA as TABSCHEMA_SOURCE, TABNAME as TABNAME_SOURCE, count(distinct STAGE_REQUIRED_AT) as DIFFERENT_STAGES
                  from CALC.AUTO_VIEW_TARGET_TO_SOURCES
                  where STAGE_REQUIRED_AT <> 9
                  group by TABSCHEMA, TABNAME
)
where DIFFERENT_STAGES > 1
  and TABNAME_SOURCE not like '%_ARCHIVE';
