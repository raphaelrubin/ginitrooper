/* CALC.AUTO_VIEW_VERSIONS
 * View to show the different Build and Export Versions that have been executed
 */

drop view CALC.AUTO_VIEW_VERSIONS;
create or replace view CALC.AUTO_VIEW_VERSIONS as
    select
        CREATED_AT,
        'BUILD' as TYPE,
        TAPENAME as TAPE,
        GROUPNAME as GROUP,
        CUT_OFF_DATE,
        ARG_VERSION as VERSION,
        COMPLETED,
        SUCCESS,
        WARNINGS as WARNINGS,
        case
            when not COMPLETED then
                TIME('00:00:00') + TIMESTAMPDIFF(2,CURRENT_TIMESTAMP-CREATED_AT) SECONDS
            else
                TIME('00:00:00') + TIMESTAMPDIFF(2,LAST_CHANGED_AT-CREATED_AT) SECONDS
        end AS DURATION,
--            TIMESTAMPDIFF(2,LAST_CHANGED_AT-CREATED_AT) as DURATION_SEC,
--            LAST_CHANGED_AT as TIME_MAX,
--            CREATED_AT as TIME_MIN,
           CREATED_BY
    from CALC.AUTO_TABLE_BUILD_VERSIONS
    union all
    select
           MIN(CREATED_AT) AS CREATED_AT,
           'EXPORT' AS TYPE,
           TAPENAME as TAPE,
           GROUPNAME as GROUP,
           CUT_OFF_DATE,
           VERSION,
           MIN(COMPLETED) as COMPLETED,
           MIN(SUCCESS) as SUCCESS,
           0 as WARNINGS,
           TIME('00:00:00') + MAX(0,TIMESTAMPDIFF(2,MAX(LAST_CHANGED_AT)-MIN(CREATED_AT))) SECONDS AS DURATION,
--            MAX(0,TIMESTAMPDIFF(2,MAX(LAST_CHANGED_AT)-MIN(CREATED_AT))) as DURATION_SEC,
--            MAX(LAST_CHANGED_AT) as TIME_MAX,
--            MIN(CREATED_AT) as TIME_MIN,
           CREATED_BY
    from CALC.AUTO_TABLE_EXPORT_VERSIONS
    group by GROUPNAME, TAPENAME, CUT_OFF_DATE, VERSION, CREATED_BY
;
comment on table CALC.AUTO_VIEW_VERSIONS is 'Übersicht über alle Bau- und Exportversionen';
