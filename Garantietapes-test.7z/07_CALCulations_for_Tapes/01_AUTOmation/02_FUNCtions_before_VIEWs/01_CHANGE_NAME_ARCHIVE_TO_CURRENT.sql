

drop function CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT(varchar(8),varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT(TABSCHEMA varchar(8), TABNAME_ARCHIVE varchar(128))
  returns varchar(128)
  begin
    declare TABNAME_CURRENT VARCHAR(128);

    if EXISTS(select * from CALC.AUTO_TABLE_TAPES where upper(TABSCHEMA) = NAME) then
        set TABNAME_CURRENT = replace(TABNAME_ARCHIVE,'_ARCHIVE','_CURRENT');
    else
        set TABNAME_CURRENT = TABNAME_ARCHIVE || '_CURRENT';
    end if;
    return TABNAME_CURRENT;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT is 'Funktion zum Konvertieren von ARCHIVE Tabellennamen zu CURRENT Tabellennamen.';
