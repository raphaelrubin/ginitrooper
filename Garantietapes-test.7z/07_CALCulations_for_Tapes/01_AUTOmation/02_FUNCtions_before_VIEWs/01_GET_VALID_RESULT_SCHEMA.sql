drop function CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema VARCHAR(8), TABLEGROUP VARCHAR(128))
  returns CLOB(200k)
  begin

    if upper(TABLEGROUP) = 'SOURCES' then
        return 'CALC';
    end if;

    return active_Schema;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA is 'Funktion, welche das Schema für die Validierungsergebnisse wiedergibt.';
