/* CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE
 *
 * Diese Funktion nimmt mehrere Parameter aus CALC.AUTO_PROC_GET_CLIENTS_FROM_IWHS und erstellt den insert code
 * Wirft einen Fehler falls NACE_OR_OE nicht (korrekt) angegeben wurde.
 *
 * @input: in_TABSCHEMA varchar(8)          NLB/BLB
 * @input: NACE_OR_OE varchar(16)           NACE/OE-Service/OE-Berater/ALL
 * @input: CODE_LIST varchar(512)           Liste an OE Nummern bzw. NACE Codes
 * @input: INCLUDE_PRIVATE BOOLEAN          Privatkunden mit einbeziehen?
 * @input: INCLUDE_KFW BOOLEAN              Privatkunden mit einbeziehen?
 * @input: msgOffset VARCHAR(128)           Leerzeichen, um Log-nachrichten einzurücken
 *
 * @output CLOB(200K)                       Insert Statement als SQL Code String
 */

drop function CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE(varchar(8), VARCHAR(16), VARCHAR(512), BOOLEAN, BOOLEAN, varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE(in_TABSCHEMA varchar(8), NACE_OR_OE VARCHAR(16), CODE_LIST VARCHAR(512),INCLUDE_PRIVATE BOOLEAN, INCLUDE_KFW BOOLEAN, msgOffset VARCHAR(128))
  returns CLOB(200K)
  MODIFIES SQL DATA
  begin
    declare curQuery CLOB(200K);
    declare tmpQuery CLOB(200K);

    set curQuery = 'insert into STG.BGA_MANUAL_LISTS (BRANCH_CLIENT, CLIENT_NO, CUT_OFF_DATE, QUELLE) select BRANCH, BORROWERID as CLIENT_NO, CUTOFFDATE, ''IWHS'' from '||in_TABSCHEMA||'.IWHS_KUNDE_CURRENT';

    case when upper(NACE_OR_OE) = 'NACE' then
        set tmpQuery = 'where NACE in ('||CODE_LIST||')';
    when upper(NACE_OR_OE) = 'OE-SERVICE' then
        set tmpQuery = 'where SERVICE_OE_NR in ('||CODE_LIST||')';
    when upper(NACE_OR_OE) = 'OE-BERATER' then
        set tmpQuery = 'where OE_NR in ('||CODE_LIST||')';
    when upper(NACE_OR_OE) = 'ALL' then
        set tmpQuery = 'where 1=1';
    when upper(NACE_OR_OE) = 'PRIVATE' then
        set tmpQuery = 'where PERSONTYPE in (''N'',''P'')';
    when upper(NACE_OR_OE) = 'COMPANIES' then
        set tmpQuery = 'where PERSONTYPE not in (''N'',''P'')';
    else
        call CALC.AUTO_PROC_LOG_ERROR(msgOffset||'Input parameter NACE_OR_OE must be ALL/NACE/OE-SERVICE/OE-BERATER','7I006');
    end case;
    set curQuery = curQuery||' '||tmpQuery;

    set tmpQuery = '';
    if not INCLUDE_PRIVATE then
        set tmpQuery = 'and PERSONTYPE not in (''N'',''P'')';
    end if;
    set curQuery = curQuery||' '||tmpQuery;

    set tmpQuery = '';
    case when not INCLUDE_KFW and in_TABSCHEMA = 'NLB' then
            set tmpQuery = 'and BORROWERID not in (1022,1041,10373749,1200,1513,1517)';
        when not INCLUDE_KFW and in_TABSCHEMA = 'BLB' then
            set tmpQuery = 'and BORROWERID not in (1022,1041)';
        else
            set tmpQuery = '';
    end case;
    set curQuery = curQuery||' '||tmpQuery;
    return curQuery;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE(varchar(8), VARCHAR(16), VARCHAR(512), BOOLEAN, BOOLEAN, varchar(128)) is 'Funktion zum Erstellen eines Codes um eine bestimmte Kundenliste aus dem IWHS zu erhalten.';


-- TEST

-- select CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('NLB', 'NACE', '''T98'',''O84''',FALSE, FALSE, '') AS CODE from SYSIBM.SYSDUMMY1
-- union all
-- select CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('BLB', 'NACE', '''T98'',''O84''',FALSE, FALSE, '') AS CODE from SYSIBM.SYSDUMMY1
-- union all
-- select CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('NLB', 'OE-SERVICE', '2090000,3142600',TRUE, TRUE, '') AS CODE from SYSIBM.SYSDUMMY1
-- union all
-- select CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('NLB', 'ALL', NULL,FALSE, TRUE, '') AS CODE from SYSIBM.SYSDUMMY1
-- ;
