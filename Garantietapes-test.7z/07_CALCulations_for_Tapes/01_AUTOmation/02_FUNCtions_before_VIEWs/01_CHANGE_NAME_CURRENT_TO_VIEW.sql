/* CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW
 *
 * Diese Funktion nimmt den Namen einer Tabelle und gibt den Namen der dazugehörigen View zurück.
 * Wirft keinen Fehler falls der Ursprungsname kein Tape ist! Nur für AMC und Basis NLB/BLB/ANL/DH/CBB verwendbar.
 * Bei Archiven mit Current wird die Current Tabelle wiedergegeben.
 *
 * @input: TABSCHEMA varchar(8)             Name des Schema der Current Tabelle
 * @input: TABNAME_CURRENT varchar(128)     Name der Current Tabelle
 *
 * @output varchar(128)                     Name der View auf welcher die Current Tabelle basiert
 */

drop function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(varchar(8),varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(in_TABSCHEMA varchar(8), TABNAME_CURRENT varchar(128))
  returns varchar(128)
  begin
    declare VIEWNAME VARCHAR(128);
    if EXISTS(select * from CALC.AUTO_TABLE_TAPES where NAME = upper(in_TABSCHEMA)) then
        set VIEWNAME = replace(replace(replace(TABNAME_CURRENT,'TAPE_','VIEW_'),'TABLE_','VIEW_'),'_CURRENT','');
    else
        -- Achtung! für Archive sollte hier die Current Tabelle falls vorhanden ausgewählt werden. sonst T_VIEW
        case
            when TABNAME_CURRENT like '%_CURRENT' then
                set VIEWNAME = 'T_VIEW_'||replace(TABNAME_CURRENT,'_CURRENT','');
            when EXISTS(select * from SYSCAT.TABLES where TABSCHEMA = in_TABSCHEMA and TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT( in_TABSCHEMA, TABNAME_CURRENT)) then
                set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT( in_TABSCHEMA, TABNAME_CURRENT);
            else
                set VIEWNAME = 'T_VIEW_'||replace(TABNAME_CURRENT,'_CURRENT','');
        end case;
    end if;
    return VIEWNAME;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW is 'Funktion zum Konvertieren von CURRENT Tabellennamen zum Viewnamen auf welchem die Tabelle basiert.';


-- TEST

-- select
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW('AMC','TABLE_PORTFOLIO_CURRENT') AS TABLE_PORTFOLIO_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW('BGA','TAPE_CASH_FLOW_FUTURE_CURRENT') AS TAPE_CASH_FLOW_FUTURE_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW('NLB','SPOT_UMSATZ_CURRENT') AS SPOT_UMSATZ_CURRENT
-- from SYSIBM.SYSDUMMY1;
