drop function CALC.AUTO_FUNC_GET_ACTIVE_TAPE();
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_ACTIVE_TAPE()
  returns varchar(128)
  begin
    declare out_Schema VARCHAR(8);
    set out_Schema = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    return out_Schema;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_ACTIVE_TAPE is 'Gibt das input Schema zurück oder wenn NULL dann das aktive Tape';
