/* CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT
 *
 * Diese Funktion nimmt den Namen einer Tabelle und gibt den dazugehörigen Stamm-Namen zurück.
 *
 * @input: TABSCHEMA varchar(8)             Name des Schema der Tabelle
 * @input: TABNAME varchar(128)             Name der Tabelle
 *
 * @output varchar(128)                     Name der View auf welcher die Current Tabelle basiert
 */

drop function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME varchar(128))
  returns varchar(128)
  begin
    declare ROOTNAME VARCHAR(128);
    set ROOTNAME = CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME);
    set ROOTNAME = replace(replace(ROOTNAME, 'TABLE_', ''), '_CURRENT', '');
    return ROOTNAME;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT is 'Funktion zum Konvertieren von Tabellennamen zum zugehörigen Basisnamen.';


-- TEST

-- select
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('TABLE_PORTFOLIO_CURRENT') AS TABLE_PORTFOLIO_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('TABLE_PORTFOLIO_ARCHIVE') AS TABLE_PORTFOLIO_ARCHIVE,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('TAPE_CASH_FLOW_FUTURE_FINISH') AS TAPE_CASH_FLOW_FUTURE_FINISH,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('TAPE_CASH_FLOW_FUTURE_PURE_KR') AS TAPE_CASH_FLOW_FUTURE_PURE_KR,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('SPOT_UMSATZ_CURRENT') AS SPOT_UMSATZ_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT('SPOT_UMSATZ') AS SPOT_UMSATZ
-- from SYSIBM.SYSDUMMY1;