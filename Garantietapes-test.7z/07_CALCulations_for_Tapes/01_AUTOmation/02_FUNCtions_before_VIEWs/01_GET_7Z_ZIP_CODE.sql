/* CALC.AUTO_FUNC_GET_7Z_ZIP_CODE
 *
 * Diese Funktion erstellt den bash Code, um mehrere Dateien in 7z zu verpacken
 *
 * @input: output_filename varchar(128))                    Name der 7z Datei
 * @input: input_filenames_spaceseparated varchar(128))     Name der csv Dateien mit Leerzeichen getrennt
 *
 * @output VARCHAR(10000) bash Code zum Verpacken mit 7z
 */

drop function CALC.AUTO_FUNC_GET_7Z_ZIP_CODE(varchar(128), varchar(9000));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_7Z_ZIP_CODE(output_filename varchar(128), input_filenames_spaceseparated varchar(9000))
  returns VARCHAR(10000)
  begin
    declare glob_zip_command VARCHAR(10000);
    declare input_filename VARCHAR(128);
    declare input_filenames VARCHAR(9000);

    SET glob_zip_command = '';
    set input_filenames = trim(input_filenames_spaceseparated);
    set output_filename = replace(output_filename,'.7z','');

    while(LENGTH(input_filenames) > 2) do
        set input_filename = SUBSTR(input_filenames, 1, LOCATE(' ',input_filenames||' ')-1);
        set input_filenames = SUBSTR(input_filenames, LOCATE(' ',input_filenames||' ')+1);
        set input_filename = replace(input_filename,'.csv','');
        SET glob_zip_command = glob_zip_command || ' /data/work/dbblossom/export/' || input_filename || '.csv';

    end while;



    SET glob_zip_command = '7z a -p /data/work/n2'||SUBSTRING(SESSION_USER ,3,6)||'/'||output_filename||'.7z'|| glob_zip_command;

    return glob_zip_command;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_7Z_ZIP_CODE is 'Funktion, welche den Bash Code zum Verpacken mehrerer Dateien wiedergibt. Bauen einer Tabelle wiedergibt.';


-- TESTS

-- select
--     CALC.AUTO_FUNC_GET_7Z_ZIP_CODE('outfile','infile') as TEST1,
--     CALC.AUTO_FUNC_GET_7Z_ZIP_CODE('outfile.7z','infile1.csv infile2 infile3') as TEST2,
--     CALC.AUTO_FUNC_GET_7Z_ZIP_CODE('out',' infile   ') as TEST3,
--     CALC.AUTO_FUNC_GET_7Z_ZIP_CODE('out','in') as TEST4,
--     CALC.AUTO_FUNC_GET_7Z_ZIP_CODE('out','infile in inf') as TEST5
-- from SYSIBM.SYSDUMMY1;