/* CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH
 *
 * Diese Funktion nimmt den Namen einer Tabelle und gibt den Namen der dazugehörigen SWITCH View zurück.
 *
 * @input: TABSCHEMA varchar(8)             Name des Schema der Tabelle
 * @input: TABNAME varchar(128)             Name der Tabelle
 *
 * @output varchar(128)                     Name der View auf welcher die Current Tabelle basiert
 */

drop function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH(varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH(TABNAME varchar(128))
  returns varchar(128)
  begin
    declare SWITCHNAME VARCHAR(128);
    set SWITCHNAME = 'SWITCH_'||replace(replace(TABNAME,'TABLE_',''),'TAPE_','');
    return SWITCHNAME;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH is 'Funktion zum Konvertieren von Tabellennamen zum zugehörigen SWITCH Namen.';


-- TEST

-- select
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH('TABLE_PORTFOLIO_CURRENT') AS TABLE_PORTFOLIO_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH('TABLE_PORTFOLIO_ARCHIVE') AS TABLE_PORTFOLIO_ARCHIVE,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH('TAPE_CASH_FLOW_FUTURE_CURRENT') AS TAPE_CASH_FLOW_FUTURE_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH('SPOT_UMSATZ_CURRENT') AS SPOT_UMSATZ_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH('AUTO_TABLE_GROUPS') AS AUTO_TABLE_GROUPS
-- from SYSIBM.SYSDUMMY1;