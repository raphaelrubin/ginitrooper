/* CALC.AUTO_FUNC_STAGE_TO_TEXT
 *
 * Diese Funktion nimmt eine Stage-nummer und sucht den zugehörigen Beschreibungstext aus der TABLE_MODES Tabelle
 *
 * @input: in_STAGE INT     Stage nummer
 *
 * @output VARCHAR(512)     zugehöriger Beschreibungstext
 */
drop function CALC.AUTO_FUNC_STAGE_TO_TEXT(INT);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_STAGE_TO_TEXT(in_STAGE INT)
  returns VARCHAR(512)
  begin
      declare outText VARCHAR(512);
      set outText = 'Task: '||(select DESCRIPTION from CALC.AUTO_TABLE_MODES where STAGE = in_STAGE limit 1);
      return outText;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_STAGE_TO_TEXT is 'Funktion, welche den Beschreibungstext für eine Stagenummer zurückgibt.';
