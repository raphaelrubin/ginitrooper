/* CALC.AUTO_FUNC_GET_BUILD_CODE
 *
 * Diese Funktion erstellt den Code, um eine Tabelle neu zu bauen
 *
 * @input: TAPENAME varchar(8)              Schema des aktiven Tapes
 * @input: TABSCHEMA_CURRENT varchar(8)     Schema der Tabelle, die wiederhergestellt werden soll
 * @input: TABNAME_CURRENT varchar(128)     Name der Tabelle, die wiederhergestellt werden soll
 *
 * @output CLOB(200k) Query, welche zum Bauen der Tabelle ausgeführt werden muss
 */

drop function CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME(varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME(in_TABSCHEMA varchar(8),in_TABNAME varchar(128))
  returns varchar(128)
  begin
    declare out_COLNAME varchar(128);

    set out_COLNAME = (select COLNAME from SYSCAT.COLUMNS where TABSCHEMA = in_TABSCHEMA and TABNAME = in_TABNAME and COLNAME in ('CUT_OFF_DATE','CUTOFFDATE','STICHTAG','BESTANDSDATUM') limit 1);

    return out_COLNAME;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME is 'Gibt den Spaltennamen für den Stichtag in der gewünschten Tabelle wieder.';


-- TESTS

-- select
--     CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME('NLB', 'SPOT_STAMMDATEN_CURRENT') as SPOT_STAMMDATEN_CURRENT,
--     CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME('AMC', 'TABLE_PORTFOLIO_ARCHIVE') as TABLE_PORTFOLIO_ARCHIVE,
--     CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME('AMC', 'TABLE_PORTFOLIO_CURRENT') as TABLE_PORTFOLIO_CURRENT,
--     CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME('BGA', 'TABLE_PORTFOLIO_CURRENT') as TABLE_PORTFOLIO_CURRENT,
--     CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME('NLB', 'SPOT_STAMMDATEN') as SPOT_STAMMDATEN
-- from SYSIBM.SYSDUMMY1;
