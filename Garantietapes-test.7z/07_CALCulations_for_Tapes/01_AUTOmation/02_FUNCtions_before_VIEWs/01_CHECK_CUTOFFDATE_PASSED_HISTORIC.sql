/* AMC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC
 *
 * Diese Funktion schaut in AMC.AUTO_TABLE_CHECK_CUTOFFDATE nach, ob eine Tabelle erfolgreich den Stichtagstest bestanden hat.
 *
 * @input: TABSCHEMA_IN varchar(8)          Name des Tabellen Schema
 * @input: TABNAME_IN varchar(128)          Name der Tabelle
 * @input: VERSION_IN BIGINT                Version der AUTO_BUILD Ausführung
 *
 * @output BOOLEAN                          TRUE, wenn die Tabelle erfolgreich getstet wurde, FALSE wenn die Tabelle nicht getestet wurde oder der Test nicht erfolgreich war
 */

drop function CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(varchar(8), varchar(128), BIGINT);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(TABSCHEMA_IN varchar(8), TABNAME_IN varchar(128), VERSION_IN BIGINT)
  returns BOOLEAN
  begin
    declare hasPassed BOOLEAN;
    set hasPassed = FALSE;
    if EXISTS(select PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = VERSION_IN and TABSCHEMA = TABSCHEMA_IN and TABNAME = TABNAME_IN) then
        set hasPassed = (select first_value(PASSED) over (partition by VERSION, TABSCHEMA, TABNAME order by CREATED_AT DESC) as PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = VERSION_IN and TABSCHEMA = TABSCHEMA_IN and TABNAME = TABNAME_IN limit 1 with UR);
    else
        set hasPassed = FALSE;
    end if;
    return hasPassed;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC is 'Funktion, welche in CALC.AUTO_TABLE_CHECK_CUTOFFDATE überprüft, ob eine Tabelle erfolgreich den Stichtagstest bestanden hat.';

-- TESTS
-- select first_value(PASSED) over (partition by VERSION, TABSCHEMA, TABNAME order by CREATED_AT DESC) from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = 1 and TABSCHEMA = 'NLB' and TABNAME = 'SPOT_STAMMDATEN_CURRENT' limit 1;
--
-- select
--        CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC('AMC', 'TABLE_PORTFOLIO_CURRENT', 1) as TABLE_PORTFOLIO_CURRENT
-- from SYSIBM.SYSDUMMY1;
--
-- select * from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = 1 and TABSCHEMA = 'NLB' and TABNAME = 'SPOT_STAMMDATEN_CURRENT';
