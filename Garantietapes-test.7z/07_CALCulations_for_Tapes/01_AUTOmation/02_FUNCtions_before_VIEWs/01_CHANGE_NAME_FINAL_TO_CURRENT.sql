/* CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT
 *
 * Diese Funktion nimmt den Namen eines Finalen Tapes und gibt den dazugehörigen Namen der Current Tabelle zurück.
 * Bei allen anderen Tabellen wird der gleiche Tabellenname zurückgegeben.
 * Wirft keinen Fehler falls der Ursprungsname kein Tape ist bzw. ein falscher oder unkonventioneller Name ist!
 *
 * @input: TABNAME_FINAL varchar(128)       Name der View, deren Current tablename gesucht wird
 *
 * @output varchar(128)                     Name der Current Tabelle
 */
drop function CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME_FINAL varchar(128))
  returns varchar(128)
  begin
    declare TABNAME_CURRENT VARCHAR(128);
--     declare ERROR_MESSAGE varchar(128);
--     if not CHARINDEX('TAPE_',TABNAME_FINAL) > 0 then
--         SET ERROR_MESSAGE = 'AMC.'||TABNAME_FINAL||' is not a final AMC Tape';
--         SIGNAL SQLSTATE '70002' SET MESSAGE_TEXT = ERROR_MESSAGE;
--     end if;
    set TABNAME_CURRENT = TABNAME_FINAL;

    set TABNAME_CURRENT =
        replace(replace(
        replace(replace(
        replace(replace(
        replace(replace(
            ' '||TABNAME_FINAL||' '
            ,'_FINISH ','_CURRENT')
            ,'_EY ','_CURRENT')
            ,'_EZB ','_CURRENT')
            ,'_TASSLER ','_CURRENT')
            ,'_GTM ','_CURRENT')
            ,'_PWC ','_CURRENT')
            ,'_EBA_GLOM ','_CURRENT')
            ,' TAPE_','TABLE_');
    set TABNAME_CURRENT = trim(TABNAME_CURRENT);
    return TABNAME_CURRENT;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT is 'Funktion zum Konvertieren von FINAL Viewnamen zum Tabellennamen der TAPE_*_CURRENT Tabelle.';


-- TEST

-- select
--        CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT('TAPE_CASH_FLOW_FUTURE_FINISH') AS TAPE_CASH_FLOW_FUTURE_FINISH,
--        CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT('TAPE_FACILITY_PWC') AS TAPE_FACILITY_PWC,
--        CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT('TABLE_PORTFOLIO_ARCHIVE') AS TABLE_PORTFOLIO_ARCHIVE
-- from SYSIBM.SYSDUMMY1;