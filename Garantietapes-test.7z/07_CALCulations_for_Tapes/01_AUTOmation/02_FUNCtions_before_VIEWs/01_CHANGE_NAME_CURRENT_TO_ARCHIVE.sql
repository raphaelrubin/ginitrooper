/* CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE
 *
 * Diese Funktion nimmt den Namen einer Current Tabelle und gibt den dazugehörigen Namen der Archive Tabelle zurück.
 * Wirft keinen Fehler falls der Ursprungsname keine _CURRENT Tabelle ist!
 *
 * @input: TABSCHEMA varchar(8)             Name des Schema der Current Tabelle, deren Archive Tabellenname gesucht wird
 * @input: TABNAME_CURRENT varchar(128)     Name der Current Tabelle, deren Archive Tabellenname gesucht wird
 *
 * @output varchar(128)                     Name der Archive Tabelle
 */

drop function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(varchar(8),varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(TABSCHEMA varchar(8), TABNAME_CURRENT varchar(128))
  returns varchar(128)
  begin
    declare TABNAME_ARCHIVE VARCHAR(128);

    if EXISTS(select * from CALC.AUTO_TABLE_TAPES where upper(TABSCHEMA) = NAME) then
        set TABNAME_ARCHIVE = replace(TABNAME_CURRENT,'_CURRENT','_ARCHIVE');
    else
        set TABNAME_ARCHIVE = replace(TABNAME_CURRENT,'_CURRENT','');
    end if;
    return TABNAME_ARCHIVE;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE is 'Funktion zum Konvertieren von CURRENT Tabellennamen zu ARCHIVE Tabellennamen.';


-- TEST

-- select
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE('BGA','TABLE_PORTFOLIO_CURRENT') AS TABLE_PORTFOLIO_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE('AMC','TAPE_CASH_FLOW_FUTURE_CURRENT') AS TAPE_CASH_FLOW_FUTURE_CURRENT,
--        CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE('NLB','SPOT_UMSATZ_CURRENT') AS SPOT_UMSATZ_CURRENT
-- from SYSIBM.SYSDUMMY1;

-- Kommentar für CI-Test