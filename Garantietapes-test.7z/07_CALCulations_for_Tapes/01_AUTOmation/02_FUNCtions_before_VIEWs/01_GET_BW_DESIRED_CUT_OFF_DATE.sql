/* CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE
 *
 * Diese Funktion berechnet den BW Stichtag für einen beliebigen Stichtag da BW früher nur Quartalsweise zur Verfügung stand
 *
 * @input: desired_CUTOFFDATE date          Stichtag für alle anderen Tabellen
 *
 * @output date                             zugehöriger Stichtag für BW Tabellen
 */

drop function CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE(date);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE(desired_CUTOFFDATE date)
  returns date
  begin
    declare real_CUTOFFDATE date;
    if desired_CUTOFFDATE > DATE('30.09.2019') then
         return desired_CUTOFFDATE;
    end if;
    set real_CUTOFFDATE = LAST_DAY(ADD_MONTHS(desired_CUTOFFDATE , -1*MOD(MONTH(desired_CUTOFFDATE),3)));
    return real_CUTOFFDATE;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE is 'Funktion zum Berechnen des BW Stichtages für einen beliebigen Stichtag, da BW nur Quartalsweise zur Verfügung steht.';


-- TEST:
-- select CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('31.12.2018') as D31122019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('31.03.2019') as D31122019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('30.06.2019') as D31122019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('30.09.2019') as D31122019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE(Date('30.11.2019')) as D30112019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('31.12.2019') as D31122019,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('31.01.2020') as D31012020,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('28.02.2020') as D28022020,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('31.03.2020') as D31032020,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE('30.04.2020') as D30042020,
--        CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE(Date('31.05.2020')) as D31052020
-- from SYSIBM.SYSDUMMY1;

