drop function CALC.DOUBLE_TO_STRING;
--#SET TERMINATOR &&
create or replace function CALC.DOUBLE_TO_STRING (d DOUBLE)
RETURNS VARCHAR(33)
language sql
CONTAINS SQL
no external action
deterministic
begin
    RETURN REGEXP_REPLACE(replace(varchar_format(d,'9999999999999990.0999999999999999'),'.',','),'([0-9]*,[0-9]*[1-9])0{5,}[0-9]','\1');
end
&&

