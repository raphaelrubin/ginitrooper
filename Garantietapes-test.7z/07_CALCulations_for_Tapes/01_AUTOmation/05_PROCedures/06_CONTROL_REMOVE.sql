/* CALC.AUTO_PROC_CONTROL_REMOVE
 *
 * Diese Prozedur dropped die Kontrolltabellen AUTO_TABLE_TARGETS und AUTO_TABLE_TARGET_TO_SOURCES sowie AUTO_TABLE_GROUPS
 *
 * @input: TAPE_toremove VARCHAR(8)             Name des existierenden Tapes, das gelöscht werden soll
 * @input: msgOffset VARCHAR(128)               Offset für die Logs
 */

drop procedure CALC.AUTO_PROC_CONTROL_REMOVE(VARCHAR(8),varchar(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CONTROL_REMOVE (TAPE_toremove varchar(8), msgOffset varchar(128))
    LANGUAGE SQL
BEGIN
    declare ref_Tape VARCHAR(8);

    -- Calc Controls umswitchen, damit die danach nicht obsolet sind
    set ref_Tape = (select NAME from CALC.AUTO_TABLE_TAPES where NAME <> TAPE_toremove limit 1);
    call CALC.AUTO_PROC_CONTROL_PREPARE(ref_Tape);

    -- Tabellen löschen
    call CALC.AUTO_PROC_DROP_IF_EXISTS(TAPE_toremove, 'AUTO_TABLE_TARGET_TO_SOURCES', msgOffset); -- leftover in case an old tape is dropped
    call CALC.AUTO_PROC_DROP_IF_EXISTS(TAPE_toremove, 'AUTO_TABLE_GROUPS', msgOffset);
    call CALC.AUTO_PROC_DROP_IF_EXISTS(TAPE_toremove, 'AUTO_TABLE_TARGETS', msgOffset); -- leftover in case an old tape is dropped
  end
&&

--call CALC.AUTO_PROC_CONTROL_REMOVE('TMP','');