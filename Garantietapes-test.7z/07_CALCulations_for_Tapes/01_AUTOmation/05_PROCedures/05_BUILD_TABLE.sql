/* CALC.AUTO_PROC_BUILD_TABLE
 * Baut eine spezielle Tabelle entweder aus dem Archiv oder aus der View neu.
 *
 * @input: TAPENAME VARCHAR(8)              Name des aktiven Tapes
 * @input: desired_TABSCHEMA VARCHAR(8)     Schema der neu zu bauenden Tabelle
 * @input: desired_TABNAME VARCHAR(128)     Name der neu zu bauenden Tabelle
 * @input: desired_CUT_OFF_DATE VARCHAR(10) Cut off Date
 * @input: Stage INT                        Stufe der Gründlichkeit (siehe TARGET_TO_SOURCES)
 * @input: useArchive BOOLEAN               Dürfen Archive benutzt werden obwohl die Tabelle neu gebaut werden kann?
 * @input: rebuildAll BOOLEAN               Sollen alle Ursprungstabellen neu gebau werden, auch wenn sie schon das
 *                                          gewünschte CoD beinhalten? Gilt nicht für Tabellen außerhalb des AMC Schema.
 * @input: VERSION BIGINT                   Version der Ausführung (wird benutzt um die Testergebnisse unterschiedlicher
 *                                          Läufe auseinander zu halten)
 * @input: RecursionLevel INT               Level der Rekursion (nur für Debug Zwecke relevant)
 */

-- Detailierte Prozedur für rekursive Aufrufe
drop procedure CALC.AUTO_PROC_BUILD_TABLE(VARCHAR(8), VARCHAR(8),VARCHAR(128),VARCHAR(10), INT, BOOLEAN,BOOLEAN, BIGINT, INT);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10),Stage INT, useArchive BOOLEAN, rebuildAll BOOLEAN, VERSION BIGINT, RecursionLevel INT)
    LANGUAGE SQL
  BEGIN
    -- START DEKLARATIONEN
    declare isAutomateable BOOLEAN;
    declare isRecreateable BOOLEAN;
    declare doTruncate BOOLEAN;
    declare curQuery CLOB(200K);
    declare msgOffset VARCHAR(128);
    declare TABNAME_ARCHIVE VARCHAR(128);
    declare hasPassed BOOLEAN;
    -- ENDE DEKLARATIONEN

    -- Initialisiere Variablen
    set msgOffset = repeat(' ',2 * RecursionLevel);

    -- Baue die Tabelle neu
    -- Tabelle vor dem Neubau leeren?
    SET doTruncate = (select DO_TRUNCATE_BEFORE_BUILD from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1 with UR);
    -- Kann die Tabelle automatisch neu gebaut werden?
    SET isAutomateable = (select case when IS_AUTOMATEABLE and BUILDCODE is not NULL then TRUE else FALSE end as IS_AUTOMATEABLE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1  with UR);
    -- kann die Tabelle automatisch aus dem Archiv befüllt werden?
    SET isRecreateable = (select case when RECREATECODE is NULL then FALSE else TRUE end as isRecreateable from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1  with UR);

    if isRecreateable and (not isAutomateable or (useArchive and RecursionLevel > 1)) then
        -- Nachschauen, ob die Tabelle überhaupt aus dem Archiv nachgebaut werden kann... ACHTUNG: BW soll z.B. leer gemacht werden, wenn nicht aktuell
--         set TABNAME_ARCHIVE = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(desired_TABSCHEMA, desired_TABNAME);
--         set CUT_OFF_DATE_COLNAME = (select distinct COLNAME_CUT_OFF_DATE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME );
--         call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(desired_TABSCHEMA, TABNAME_ARCHIVE,CUT_OFF_DATE_COLNAME, VERSION,desired_CUT_OFF_DATE, FALSE, hasPassed);
--         set hasPassed = CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(desired_TABSCHEMA, TABNAME_ARCHIVE,VERSION);
        -- 1) verwende das Archiv zum Neubau
        call CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE (TAPENAME,desired_TABSCHEMA,desired_TABNAME,desired_CUT_OFF_DATE,msgOffset, doTruncate);
    elseif isAutomateable then
        -- 2a) Teste ob die Tabelle so gebaut werden kann und wenn nicht, dann aktualisiere die Basistabellen (Rekursiver Aufruf)
        begin
           declare stmt STATEMENT;
           prepare stmt FROM 'call CALC.AUTO_PROC_CHECK_REQUIREMENTS (CAST(? as VARCHAR(8)), CAST(? as VARCHAR(8)), CAST(? as VARCHAR(128)), CAST(? as VARCHAR(10)), CAST(? as INT), CAST(? as BOOLEAN), CAST(? as BOOLEAN), CAST(? as BIGINT), CAST(? as INT))';
           execute stmt USING TAPENAME,desired_TABSCHEMA,desired_TABNAME,desired_CUT_OFF_DATE,Stage, useArchive, rebuildAll, VERSION, RecursionLevel;
        end;
        -- 2b) baue die Tabelle ganz neu
        call CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPENAME,desired_TABSCHEMA,desired_TABNAME,msgOffset, doTruncate);
    end if;
    -- End Procedure
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION,'insert into CALC.AUTO_TABLE_CHECK_BUILD (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION) values ('''||desired_TABSCHEMA||''', '''||desired_TABNAME||''','''||desired_CUT_OFF_DATE||''','||VERSION||');');
    insert into CALC.AUTO_TABLE_CHECK_BUILD (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION) values (desired_TABSCHEMA, desired_TABNAME,desired_CUT_OFF_DATE,VERSION); -- Log that build was completed
    COMMIT;
  end
&&



-- Hauptprozeduren zum Ausführen
--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_TABLE(VARCHAR(8),VARCHAR(8),VARCHAR(128),VARCHAR(10), INT, BOOLEAN, BOOLEAN, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10),Stage INT, useArchive BOOLEAN, rebuildAll BOOLEAN, continuePrevious BOOLEAN)
    LANGUAGE SQL
  BEGIN
    declare curVERSION BIGINT;

    SET curVERSION = 1;
    set curVERSION = coalesce((select max(VERSION) from CALC.AUTO_TABLE_CHECK_CUTOFFDATE),0);
    if not continuePrevious then
        set curVERSION = curVERSION+1;
    end if;
    call CALC.AUTO_PROC_LOG_INFO('Starting execution of CALC.AUTO_PROC_BUILD_TABLE version '||curVERSION||'.');
    -- Check if table is known to the procedure
    if not EXISTS(select * from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
        call CALC.AUTO_PROC_LOG_ERROR('I don''t know '||desired_TABSCHEMA||'.'||desired_TABNAME||'. Please add the table to CALC.AUTO_TABLE_TARGETS and CALC.AUTO_TABLE_TARGET_TO_SOURCES and try again.','73503');
    end if;
    -- List Parameters
    call CALC.AUTO_PROC_LOG_DEBUG(CALC.AUTO_FUNC_STAGE_TO_TEXT(Stage));
    call CALC.AUTO_PROC_LOG_DEBUG('Desired table is '||desired_TABSCHEMA||'.'||desired_TABNAME||'.');
    call CALC.AUTO_PROC_LOG_DEBUG('Desired cut off date is '||desired_CUT_OFF_DATE||'.');
    if useArchive then
        call CALC.AUTO_PROC_LOG_DEBUG('The use of archives is allowed.');
    else
        call CALC.AUTO_PROC_LOG_DEBUG('The use of archives is not allowed.');
    end if;

    -- Starte die eigentliche Bau Prozedur
    call CALC.AUTO_PROC_BUILD_TABLE (TAPENAME,desired_TABSCHEMA,desired_TABNAME,desired_CUT_OFF_DATE,Stage, useArchive, rebuildAll,curVERSION,0);

    -- Aufräumen
    --delete from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = curVERSION;
    --delete from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION;

    call CALC.AUTO_PROC_LOG_INFO('Finished execution of CALC.AUTO_PROC_BUILD_TABLE version '||curVERSION||' successfully.');
  end
&&



--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_TABLE(VARCHAR(8),VARCHAR(8),VARCHAR(128),VARCHAR(10), VARCHAR(16));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10),Mode VARCHAR(16))
    LANGUAGE SQL
  BEGIN
    declare Stage INT;
    declare useArchive BOOLEAN;
    declare rebuildAll BOOLEAN;

    if not EXISTS(select * from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode)) then
        set Mode = 'DEFAULT';
    end if;
    set Stage = (select STAGE from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    set useArchive = (select useArchive from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    set rebuildAll = (select rebuildAll from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    call CALC.AUTO_PROC_BUILD_TABLE ( TAPENAME,desired_TABSCHEMA,desired_TABNAME,desired_CUT_OFF_DATE,Stage, useArchive, rebuildAll, FALSE);
  end
&&

-- TESTS
-- truncate table CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE immediate;
-- truncate table CALC.AUTO_TABLE_CHECK_CUTOFFDATE immediate;
-- truncate table CALC.AUTO_TABLE_LOG immediate;
-- call CALC.AUTO_PROC_BUILD_TABLE ('AMC','AMC','TABLE_FACILITY_CORE_CURRENT','31.12.2019', 'SPOT');
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC with UR;
--
-- truncate table CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE immediate;
-- truncate table CALC.AUTO_TABLE_CHECK_CUTOFFDATE immediate;
-- truncate table CALC.AUTO_TABLE_LOG immediate;
-- call CALC.AUTO_PROC_BUILD_TABLE ('AMC','TABLE_PORTFOLIO_CURRENT','31.12.2019',6,TRUE,FALSE,TRUE);
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT;
--
-- select distinct CUTOFFDATE from IMAP.ZM_EXTNR_CURRENT;
--
-- truncate table CALC.AUTO_TABLE_LOG immediate;
-- call CALC.AUTO_PROC_BUILD_TABLE ('IMAP','ZM_EXTNR_CURRENT','31.12.2019','RESET');
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT with UR;

