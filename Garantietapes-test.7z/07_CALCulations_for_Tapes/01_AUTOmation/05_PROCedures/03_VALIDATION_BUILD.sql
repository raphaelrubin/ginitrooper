drop procedure CALC.AUTO_PROC_VALIDATION_BUILD (VARCHAR(128), DATE, INT, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_VALIDATION_BUILD (GROUP VARCHAR(128), for_CUT_OFF_DATE DATE, Stage INT, RUN BOOLEAN)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    declare activeTape VARCHAR(8); -- aktive Tapename
    declare resultTape VARCHAR(8); -- Tapename in welchem die Ergebnisse stehen werden.
    declare SQLCODE INTEGER DEFAULT 0;
    declare SQLSTATE CHAR(5 OCTETS) DEFAULT '00000';
    declare RUN_SQLCODE INTEGER DEFAULT 0;
    declare RUN_SQLSTATE CHAR(5) DEFAULT '00000';
    declare RUN_DIAGNOSTIC_STRING VARCHAR(1024) DEFAULT '';
    declare RUN_RETURN_STATUS INTEGER DEFAULT 0;
    declare ACTIVE_TABLENAME VARCHAR(256) DEFAULT '';
    declare ACTIVE_ID INTEGER DEFAULT 0;

    DECLARE CURxRT1 INSENSITIVE Cursor WITH HOLD
        for
            select distinct VALIDATIONS.*, 'call CALC.VALID_PROC_'||VALIDATIONS.PROCEDURE_NAME||'('||VALIDATIONS.PARAMETERS||',CAST(? as VARCHAR(128)), CAST(? as DATE), '||VALIDATIONS.IMPORTANCE||')' as QUERY
            from CALC.AUTO_TABLE_VALIDATIONS as VALIDATIONS
            left join CALC.AUTO_VIEW_GROUPS_EXPANDED as GROUPS
                on VALIDATIONS.TABNAME = GROUPS.TABNAME
                or VALIDATIONS.TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(GROUPS.TABNAME)
            where (GROUPS.GROUPNAME = GROUP or VALIDATIONS.TABNAME = GROUP or CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(VALIDATIONS.TABNAME) = GROUP or VALIDATIONS.TABNAME is NULL) -- Validated Table must belong to desired Group
              and for_CUT_OFF_DATE between coalesce(VALID_FROM,DATE('01.01.2015')) and COALESCE(VALID_TO,DATE('01.01.2999')) -- Validation must be valid for given cut-off-date
              and VALIDATIONS.SYSTEM_STAGE <= Stage -- Rawdata-System required for this validation has been loaded
              and (VALIDATIONS.TAPENAME = activeTape or VALIDATIONS.TAPENAME is NULL) -- validation is valid for active Tape
              and VALIDATIONS.IS_ACTIVE
    ;
    -- Errorhandler definieren
    declare CONTINUE HANDLER for SQLEXCEPTION, SQLWARNING
        begin
            GET DIAGNOSTICS RUN_RETURN_STATUS = DB2_RETURN_STATUS;
            GET DIAGNOSTICS EXCEPTION 1
                RUN_DIAGNOSTIC_STRING = MESSAGE_TEXT;
            select SQLCODE, SQLSTATE into RUN_SQLCODE, RUN_SQLSTATE from SYSIBM.SYSDUMMY1;

            call CALC.AUTO_PROC_LOG_WARNING('VALIDATING failed with SQLCODE '||RUN_SQLCODE||', SQLSTATE '||RUN_SQLSTATE||' '||RUN_DIAGNOSTIC_STRING);

            call CALC.AUTO_PROC_EXECUTE_IMMEDIATE('insert into ' || resultTape || '.TABLE_VALIDATION_RESULTS_CURRENT (TABLEGROUP, CUT_OFF_DATE, IMPORTANCE, AFFECTED_TABLE, ERRORMESSAGE,VALIDATION_ID)'||
                              ' select '''|| GROUP ||''','''|| for_CUT_OFF_DATE ||''',1 as IMPORTANCE,'''|| ACTIVE_TABLENAME || ''',''Validation failed with SQLCODE '||RUN_SQLCODE||', SQLSTATE '||RUN_SQLSTATE||' '||RUN_DIAGNOSTIC_STRING ||''','|| ACTIVE_ID ||
                              ' from SYSIBM.SYSDUMMY1', '  ');
        end;
    -- ENDE DEKLARATIONEN
    
    call CALC.AUTO_PROC_LOG_INFO('Executing validations.');
    
    set activeTape = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    set resultTape = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(activeTape,GROUP);

    set curQuery = CALC.AUTO_FUNC_GET_TRUNCATE_CODE(resultTape,'TABLE_VALIDATION_RESULTS_CURRENT');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'  ');

    for CA as CURxRT1 Cursor WITH HOLD
        for
            select distinct VALIDATIONS.*, 'call CALC.VALID_PROC_'||VALIDATIONS.PROCEDURE_NAME||'('||trim(L ',' FROM VALIDATIONS.PARAMETERS||',CAST(? as VARCHAR(128)), CAST(? as DATE), '||VALIDATIONS.IMPORTANCE||','||VALIDATIONS.ID)||')' as QUERY
            from CALC.AUTO_TABLE_VALIDATIONS as VALIDATIONS
            left join CALC.AUTO_VIEW_GROUPS_EXPANDED as GROUPS
                on VALIDATIONS.TABNAME = GROUPS.TABNAME
                or VALIDATIONS.TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(GROUPS.TABNAME)
            where (GROUPS.GROUPNAME = GROUP or VALIDATIONS.TABNAME = GROUP or CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(VALIDATIONS.TABNAME) = GROUP or VALIDATIONS.TABNAME is NULL) -- Validated Table must belong to desired Group
              and for_CUT_OFF_DATE between coalesce(VALID_FROM,DATE('01.01.2015')) and COALESCE(VALID_TO,DATE('01.01.2999')) -- Validation must be valid for given cut-off-date
              and VALIDATIONS.SYSTEM_STAGE <= Stage -- Rawdata-System required for this validation has been loaded
              and (VALIDATIONS.TAPENAME = activeTape or VALIDATIONS.TAPENAME is NULL) -- validation is valid for active Tape
              and VALIDATIONS.IS_ACTIVE
    do
        set curQuery = CA.QUERY;
        set ACTIVE_TABLENAME = CA.TABNAME;
        set ACTIVE_ID = CA.ID;
        
        -- Test ausführen:
        call CALC.AUTO_PROC_LOG_INFO('  Validation '||CA.ID||COALESCE(': '||CA.DESCRIPTION,''));
--         call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');
        begin
           declare stmt STATEMENT;
           prepare stmt FROM curQuery;
           execute stmt USING GROUP,for_CUT_OFF_DATE;
        end;
    end for;


    call CALC.AUTO_PROC_LOG_INFO('Finished executing all validations.');
end
&&



--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_VALIDATION_BUILD(VARCHAR(128), DATE, VARCHAR(32));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_VALIDATION_BUILD (GROUP VARCHAR(128), for_CUT_OFF_DATE DATE, Mode VARCHAR(32))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
    declare Stage INT;
    declare useArchive BOOLEAN;
    declare rebuildAll BOOLEAN;

    if EXISTS(select * from CALC.AUTO_TABLE_BUILD_VERSIONS where COMPLETED = FALSE) then
        signal SQLSTATE '72723' set MESSAGE_TEXT = 'An instance of AUTO_PROC_BUILD is still executing or has not completed.';
    end if;

    if not EXISTS(select * from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode)) then
        call CALC.AUTO_PROC_LOG_WARNING('Didn''t find rawdatasystems, using DEFAULT instead. Check call CALC.HELP_ME_WITH_THE_OPTIONS(); for valid rawdatasystems.');
        set Mode = 'DEFAULT';
    end if;
    set Stage = (select STAGE from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    call CALC.AUTO_PROC_VALIDATION_BUILD (GROUP, for_CUT_OFF_DATE, Stage, TRUE);
  end
&&
