/* CALC.AUTO_PROC_BACKUP_WRITE
 *
 * Diese Prozedur erstellt ein Backup von einer Tabelle
 *
 * @input: TABSCHEMA VARCHAR(8)            Name des Schema, der Tabelle
 * @input: TABNAME VARCHAR(128)            Name der Tabelle
 */

drop procedure CALC.AUTO_PROC_BACKUP_WRITE(varchar(8), varchar(200), varchar(50));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BACKUP_WRITE(in_TABSCHEMA varchar(8), TABNAME varchar(200), msgoffset varchar(50))
LANGUAGE SQL
  begin
    declare BACKUP_TABLENAME varchar(500); -- Name der Backup Tabelle
    declare BACKUP_STATEMENT CLOB(200K);
    declare CUR_TIME VARCHAR(20);

    call CALC.AUTO_PROC_LOG_INFO(msgoffset||'Creating backup for '|| in_TABSCHEMA ||'.'||TABNAME);
    SET CUR_TIME      = VARCHAR_FORMAT(CURRENT_TIMESTAMP,'YYYYMMDDHH24MISS');
    set BACKUP_TABLENAME = 'BACKUP_'||TABNAME||'_'||CUR_TIME;

    -- Create backup table
    call CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(in_TABSCHEMA, BACKUP_TABLENAME, in_TABSCHEMA, TABNAME, msgoffset||'  ');
    -- a) Hole gemeinsame Spaltennamen:
    set BACKUP_STATEMENT = (select left(COLS, LENGTH(COLS) - 2) as COLS
                        from (select xmlserialize(xmlagg(xmlconcat(xmltext(BACKUP.COLNAME), xmltext(', '))) as clob(200 k)) as COLS
                        from SYSCAT.COLUMNS as BACKUP
                        where upper(BACKUP.TABSCHEMA) = upper(in_TABSCHEMA) and upper(BACKUP.TABNAME) = upper(BACKUP_TABLENAME)
                          and upper(BACKUP.COLNAME) <> 'ID'));
    -- Fill backup table with data
    set BACKUP_STATEMENT = 'insert into '|| in_TABSCHEMA || '.'|| BACKUP_TABLENAME|| '('||BACKUP_STATEMENT||') select '||BACKUP_STATEMENT||' from '|| in_TABSCHEMA || '.'|| TABNAME|| ''; -- create table '||TABSCHEMA||'.'||BACKUP_TABLENAME||' like '||TABSCHEMA||'.'||TABNAME||';
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(BACKUP_STATEMENT,msgoffset||'  ');

    call CALC.AUTO_PROC_LOG_INFO(msgoffset|| 'Finished creating backup for '|| in_TABSCHEMA || '.'|| TABNAME);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_BACKUP_WRITE(varchar(8), varchar(200), varchar(50)) is 'Prozedur um ein Backup von einer beliebigen Tabelle zu erstellen.';
