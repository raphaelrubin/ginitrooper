/* CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW
 * Baut eine Tabelle basierend auf der zugrunde liegenden View/ entsprechend dem hinterlegten BUILD Code neu.
 *
 * @input: TAPENAME VARCHAR(8)              Name des aktiven Tapes
 * @input: desired_TABSCHEMA VARCHAR(8)     Name des Schema der zu bauenden Tabelle
 * @input: desired_TABNAME VARCHAR(128)     Name der zu bauenden Tabelle
 * @input: msgOffset VARCHAR(128)           Leerzeichen, um Log-nachrichten einzurücken
 * @input: doTruncate BOOLEAN               Muss die Tabelle vor dem Neubau geleert werden? (trifft normalerweise auf
 *                                          CURRENT und nicht auf ARCHIVE Tabellen zu)
 */

drop procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (VARCHAR(8), VARCHAR(8), VARCHAR(128), BOOLEAN, BOOLEAN, VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128), doTruncate BOOLEAN, FORCE_BUILD BOOLEAN, msgOffset VARCHAR(128))
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    declare real_TABSCHEMA VARCHAR(8);
    declare predicted_VIEWNAME VARCHAR(128);

    if desired_TABSCHEMA = 'AMC' then
        set real_TABSCHEMA = TAPENAME;
    else
        set real_TABSCHEMA = desired_TABSCHEMA;
    end if;

    -- baue die Tabelle ganz neu
    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Building "' || real_TABSCHEMA||'.'||desired_TABNAME|| '".');
    if doTruncate then
        -- Aktuell vorhandene Daten aus Tabelle löschen
        --call calc.AUTO_PROC_LOG_DEBUG(msgOffset||'Expecting cut off date to be')
        set curQuery = CALC.AUTO_FUNC_GET_TRUNCATE_CODE(real_TABSCHEMA,desired_TABNAME, CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE(real_TABSCHEMA,desired_TABNAME));
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,msgOffset);
    end if;
    -- Code zum Tabelle gefüllen generieren.
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,'select BUILDCODE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = '''||desired_TABSCHEMA||''' and TABNAME = '''||desired_TABNAME||''';');
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,'select TYPE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = '''||desired_TABSCHEMA||''' and TABNAME = '''||desired_TABNAME||''';');
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,'select BUILD_VIEW_SCHEMA from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = '''||desired_TABSCHEMA||''' and TABNAME = '''||desired_TABNAME||''';');
    set curQuery = CALC.AUTO_FUNC_GET_BUILD_CODE(TAPENAME, desired_TABSCHEMA, desired_TABNAME, FORCE_BUILD);
    -- View neu validieren, um Abbruch zu vermeiden
    set predicted_VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(desired_TABSCHEMA,desired_TABNAME);
    if exists(select * from SYSCAT.VIEWS where VIEWSCHEMA = 'CALC' and VIEWNAME = predicted_VIEWNAME) then
        call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Revalidating "CALC.' || predicted_VIEWNAME || '".');
        call SYSPROC.ADMIN_REVALIDATE_DB_OBJECTS('view','CALC',predicted_VIEWNAME);
    end if;
    if exists(select * from SYSCAT.VIEWS where VIEWSCHEMA = desired_TABSCHEMA and VIEWNAME = predicted_VIEWNAME) then
        call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Revalidating "' ||desired_TABSCHEMA||'.'|| predicted_VIEWNAME || '".');
        call SYSPROC.ADMIN_REVALIDATE_DB_OBJECTS('view',desired_TABSCHEMA,predicted_VIEWNAME);
    end if;

    -- Tabelle neu befüllen
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(curQuery, msgOffset);

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Finished building "' || real_TABSCHEMA||'.'||desired_TABNAME|| '".');
  end
&&
                                                                                                                                 
--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (VARCHAR(8), VARCHAR(8), VARCHAR(128), VARCHAR(128), BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),msgOffset VARCHAR(128), doTruncate BOOLEAN)
    LANGUAGE SQL
  BEGIN
      -- Standard Aufruf der Automatisierung (hier werden beladungsroutinen explizit nicht forciert. Falls eine Quelltabelle fälschlicherweise angefordert wird, wird diese Prozedur einen Fehler werfen.
      call CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPENAME, desired_TABSCHEMA,desired_TABNAME, doTruncate, FALSE, msgOffset);
  end
&&
