/* CALC.AUTO_PROC_DATABASE_REORG
 * REORG und RUNSTATS auf allen Tabellen ausführen
 *
 * @input: TAPE VARCHAR(8)                  Name des aktiven Tapes
 * @input: for_CUT_OFF_DATE DATE            Stichtag
 * @input: continuePrevious BOOLEAN         Soll die vorherige Ausführung fortgeführt werden?
 */

drop procedure CALC.AUTO_PROC_DATABASE_REORG();
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_DATABASE_REORG()
    LANGUAGE SQL
  BEGIN
    -- START DEKLARATIONEN
    declare curQuery VARCHAR(2048);
    -- Cursor erstellen, welcher über die angeforderten Tabellen iteriert
    DECLARE CURxRT1 INSENSITIVE Cursor
    for
        select trim(SYS.TABSCHEMA) as TABSCHEMA, trim(SYS.TABNAME) as TABNAME
        from CALC.AUTO_TABLE_TARGETS as AUTO
        inner join SYSCAT.TABLES as SYS on AUTO.TABNAME = sys.TABNAME
        where AUTO.TABNAME like '%_CURRENT' or SYS.TABNAME in ('TABLE_PORTFOLIO_ARCHIVE','TABLE_PORTFOLIO_DESIRED_CLIENTS_ARCHIVE')
          and SYS.TYPE = 'T'
         with UR
    ;
    -- ENDE DEKLARATIONEN
    delete from CALC.AUTO_TABLE_TMP_REORG where 1=1;
    -- START LOG PARAMETER
    call CALC.AUTO_PROC_LOG_INFO('Starting execution of CALC.AUTO_PROC_DATABASE_REORG.');


    -- prepare REORG and RUNSTATS for all tables
    for CA as CURxRT1 INSENSITIVE Cursor WITH HOLD
        for
            select trim(SYS.TABSCHEMA) as TABSCHEMA, trim(SYS.TABNAME) as TABNAME
            from CALC.AUTO_TABLE_TARGETS as AUTO
            inner join SYSCAT.TABLES as SYS on AUTO.TABNAME = sys.TABNAME
            where AUTO.TABNAME like '%_CURRENT' or SYS.TABNAME in ('TABLE_PORTFOLIO_ARCHIVE','TABLE_PORTFOLIO_DESIRED_CLIENTS_ARCHIVE')
              and SYS.TYPE = 'T'
             with UR
    do
        call CALC.AUTO_PROC_LOG_INFO('  Caring about '||CA.TABSCHEMA||'.'||CA.TABNAME);
        call CALC.AUTO_PROC_LOG_DEBUG('    REORG for '||CA.TABSCHEMA||'.'||CA.TABNAME);
        SET curQuery = 'REORG table '||CA.TABSCHEMA||'.'||CA.TABNAME;
        --call sysproc.admin_cmd(REORG for table );
        insert into CALC.AUTO_TABLE_TMP_REORG(ADMIN_CMD_QUERY)values(curQuery);
        call CALC.AUTO_PROC_LOG_DEBUG('    REORG for '||CA.TABSCHEMA||'.'||CA.TABNAME);
        SET curQuery = 'REORG INDEXES ALL for table '||CA.TABSCHEMA||'.'||CA.TABNAME;
        --call sysproc.admin_cmd(curQuery);
        insert into CALC.AUTO_TABLE_TMP_REORG(ADMIN_CMD_QUERY)values(curQuery);
        call CALC.AUTO_PROC_LOG_DEBUG('    RUNSTATS on '||CA.TABSCHEMA||'.'||CA.TABNAME);
        SET curQuery = 'RUNSTATS on table '||CA.TABSCHEMA||'.'||CA.TABNAME;
        --call sysproc.admin_cmd(curQuery);
        insert into CALC.AUTO_TABLE_TMP_REORG(ADMIN_CMD_QUERY)values(curQuery);
        call CALC.AUTO_PROC_LOG_DEBUG('  Finished preparing '||CA.TABSCHEMA||'.'||CA.TABNAME);
    end for;

    -- execute statements:
    call CALC.AUTO_PROC_LOG_INFO('  Executing prepared Statements.');
    while EXISTS(select * from CALC.AUTO_TABLE_TMP_REORG)
    do
        set curQuery = (select ADMIN_CMD_QUERY from CALC.AUTO_TABLE_TMP_REORG order by ID limit 1);
        delete from CALC.AUTO_TABLE_TMP_REORG where ADMIN_CMD_QUERY = curQuery;
        call CALC.AUTO_PROC_LOG_DEBUG('  About to execute "'||curQuery||'"');
        call sysproc.admin_cmd(curQuery);
    end while;

    call CALC.AUTO_PROC_LOG_INFO('Finished execution of CALC.AUTO_PROC_DATABASE_REORG successfully.');
  end
&&