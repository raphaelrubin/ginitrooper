/* CALC.AUTO_PROC_SWITCH_CREATE_ALL
 *
 * Diese Prozedur erstellt eine alle Switch Views für das gewünschte Schema.
 *
 * @input: for_Tape VARCHAR(8)              Name des aktiven Schemas
 */

drop procedure CALC.AUTO_PROC_SWITCH_CREATE_ALL(VARCHAR(8));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_SWITCH_CREATE_ALL(for_Tape VARCHAR(8))
    LANGUAGE SQL
BEGIN
    DECLARE CURxRTT INSENSITIVE Cursor WITH HOLD
        for
            select distinct TABSCHEMA, TABNAME from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = for_Tape with UR;

    call CALC.AUTO_PROC_LOG_INFO('Creating all the required Switches');
    call CALC.AUTO_PROC_CONTROL_PREPARE(for_Tape);

    for TT as CURxRTT Cursor  WITH HOLD
        for
            select distinct TABSCHEMA, TABNAME from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = for_Tape with UR
    do
        call CALC.AUTO_PROC_SWITCH_FLIP(for_Tape,TT.TABNAME,'  ');
    end for;
    call CALC.AUTO_PROC_LOG_INFO('Finished creating all the required Switches');
END
&&