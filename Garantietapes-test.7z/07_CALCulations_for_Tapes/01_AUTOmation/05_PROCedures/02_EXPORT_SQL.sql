/* CALC.AUTO_PROC_EXPORT_SQL
 * Procedure that exports the result of an SQL Command to csv
 * @input: SQL_CODE CLOB(200k)          SQL Code to execute, that produces a table that is to be exportet
 * @input: EXPORT_NAME VARCHAR(500)     Name of the export file
 * @input: PACK_OPTION VARCHAR(2)       Packing or compression option?
 * @input: EXPORT_PATH VARCHAR(32000)   Path to export into
 */

drop procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500),VARCHAR(32000),BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_SQL (SQL_CODE CLOB(200k),EXPORT_NAME VARCHAR(500),EXPORT_PATH VARCHAR(32000), ADD_TIMESTAMP BOOLEAN)
    LANGUAGE SQL
BEGIN

    declare TABNAME_NAME VARCHAR(500);
    declare CREATE_CODE CLOB(400k);
    declare delete_code CLOB(400k);
    declare EXPORT_CODE CLOB(400k);
    declare CUR_TIME VARCHAR(20);
    declare CUR_PATH CLOB(400k);
    declare ZIP_NAME CLOB(400k);
    declare ORDER_BY_CONDITION CLOB(400k);

    SET CUR_TIME      = VARCHAR_FORMAT(CURRENT_TIMESTAMP,'YYYYMMDDHH24MISS');
    SET TABNAME_NAME  = 'EXPORT_STATEMENT_' || CUR_TIME;
    if (locate_in_string(upper(SQL_CODE),'ORDER BY',-1) > coalesce(locate_in_string(upper(SQL_CODE),')',-1),0))
        then  --order by wird vom code ignoriert um später wieder an die export view angefügt zu werden.
            SET CREATE_CODE   = 'create view TMP.' || TABNAME_NAME || ' as ' || left(SQL_CODE,locate_in_string(upper(SQL_CODE),'ORDER BY',-1)-1);
            SET ORDER_BY_CONDITION = substr(SQL_CODE,locate_in_string(upper(SQL_CODE),'ORDER BY',-1)+8);

        else
            SET CREATE_CODE   = 'create view TMP.' || TABNAME_NAME || ' as ' || SQL_CODE;
            SET ORDER_BY_CONDITION = NULL;
    end if;

    SET delete_code   = 'drop view TMP.' || TABNAME_NAME;



    call CALC.AUTO_PROC_LOG_DEBUG('    About to execute: "'||LEFT(CREATE_CODE,450)||'"');
    execute immediate  CREATE_CODE;

    if(EXPORT_PATH <> '')
      then
        set CUR_PATH        = EXPORT_PATH;
      else
        set CUR_PATH        = '/data/work/dbblossom/export/';
    end if;

    if(EXPORT_NAME <> '')
      then
        set EXPORT_NAME = translate(EXPORT_NAME,'_________________',' ,.;''-?\()[]{}!~*');
        while EXPORT_NAME like '%/_/_%' escape '/'
            do
              set EXPORT_NAME = replace(EXPORT_NAME,'__','_');
              if ADD_TIMESTAMP then
                  set EXPORT_NAME = CUR_TIME || '_' || EXPORT_NAME;
              end if;
        end while;

        SET ZIP_NAME = '/data/work/$(id -nu $(cat /proc/$(cat /proc/$PPID/stat | awk ''{ print $4 }'')/status | egrep ''^Uid:'' | awk ''{ print $2 }''))/' ||CUR_TIME || '_' || EXPORT_NAME;

        if ADD_TIMESTAMP then
            set EXPORT_NAME = CUR_PATH || CUR_TIME || '_' || EXPORT_NAME;
        else
            set EXPORT_NAME = CUR_PATH || EXPORT_NAME;
        end if;

       else

        SET EXPORT_NAME = CUR_PATH ||CUR_TIME || '_' || TABNAME_NAME;
        SET ZIP_NAME = '/data/work/$(id -nu $(cat /proc/$(cat /proc/$PPID/stat | awk ''{ print $4 }'')/status | egrep ''^Uid:'' | awk ''{ print $2 }''))/' ||CUR_TIME || '_' || TABNAME_NAME;

    end if;

    Select Code into EXPORT_CODE from CALC.AUTO_VIEW_CREATE_EXTRACT_SCRIPT where TABNAME = TABNAME_NAME;

    call CALC.AUTO_PROC_LOG_DEBUG('    Found Export Code: "'||TRIM(cast(LEFT(coalesce(EXPORT_CODE,''),450) as VARCHAR(450)))||'"');

    SET EXPORT_CODE = regexp_replace(EXPORT_CODE,TABNAME_NAME,EXPORT_NAME,'1','1');


    if (ORDER_BY_CONDITION is not NULL)
        then
        SET EXPORT_CODE = left (EXPORT_CODE,length(EXPORT_CODE)-2) ||',' || ORDER_BY_CONDITION ||''')';
    end if;

    call CALC.AUTO_PROC_LOG_DEBUG('    About to execute: "'||TRIM(cast(LEFT(coalesce(EXPORT_CODE,''),450) as VARCHAR(450)))||'"');
    execute immediate  EXPORT_CODE;
    call CALC.AUTO_PROC_LOG_DEBUG('    About to execute: "'||TRIM(cast(LEFT(coalesce(delete_code,''),450) as VARCHAR(450)))||'"');
    execute immediate  delete_code;


--     if (PACK_OPTION ='N')
--         then SET ADDITIONAL_CODE = ''; --nicht Packen gewählt
--     elseif (PACK_OPTION ='P')
--         then
--             SET ADDITIONAL_CODE = '7z a -p ' || ZIP_NAME || '.7z ' || EXPORT_NAME || '.csv'; --einpacken der Datei inkl, Passwort
--             SET SEND_LINE = 'send '|| replace(EXPORT_NAME,CUR_PATH,'') || '.7z '; --send code generierung
--
--     elseif (PACK_OPTION ='PN')
--         then
--             SET ADDITIONAL_CODE = '7z a ' || ZIP_NAME || '.7z ' || EXPORT_NAME || '.csv'; --einpacken ohne Passwort
--             SET SEND_LINE = './send '|| replace(EXPORT_NAME,CUR_PATH,'') || '.7z '; --send code generierung
--     else
--       SET ADDITIONAL_CODE = ''; --in allen anderen Fällen nichts tun
--     end if;

end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500),VARCHAR(32000),BOOLEAN) is 'Prozedur zum Exportieren des Ergebnisses eines SQL Befehls.';



drop procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500),BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_SQL (SQL_CODE CLOB(200k),EXPORT_NAME VARCHAR(500), ADD_TIMESTAMP BOOLEAN)
    LANGUAGE SQL
BEGIN
    call CALC.AUTO_PROC_EXPORT_SQL (SQL_CODE,EXPORT_NAME,'', ADD_TIMESTAMP);
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500),BOOLEAN) is 'Prozedur zum Exportieren des Ergebnisses eines SQL Befehls.';



drop procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_SQL (SQL_CODE CLOB(200k),EXPORT_NAME VARCHAR(500))
    LANGUAGE SQL
BEGIN
    call CALC.AUTO_PROC_EXPORT_SQL (SQL_CODE,EXPORT_NAME,'', TRUE);
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_SQL(CLOB(200k),VARCHAR(500)) is 'Prozedur zum Exportieren des Ergebnisses eines SQL Befehls.';
