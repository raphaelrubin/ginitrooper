/* CALC.AUTO_PROC_BUILD_ARCHIVES
 * Baut alle Archivtabellen eines Tapes neu.
 *
 * @input: TAPE VARCHAR(8)                  Name des aktiven Tapes
 * @input: for_CUT_OFF_DATE DATE            Stichtag
 * @input: continuePrevious BOOLEAN         Soll die vorherige Ausführung fortgeführt werden?
 */

drop procedure CALC.AUTO_PROC_BUILD_ARCHIVES(VARCHAR(8), DATE, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_ARCHIVES (TAPE VARCHAR(8), for_CUT_OFF_DATE DATE, continuePrevious BOOLEAN)
    LANGUAGE SQL
  BEGIN
    -- START DEKLARATIONEN
     DECLARE BUILD_ERROR CONDITION FOR '42601';
--     DECLARE CONTINUE HANDLER FOR BUILD_ERROR
--         BEGIN
--             call CALC.AUTO_PROC_LOG_WARNING('Fehler wurde geworfen');
--         END;
    declare curVERSION BIGINT;
    declare desired_TABSCHEMA VARCHAR(8);
    declare desired_TABNAME VARCHAR(128);
    declare doTruncate BOOLEAN;
    declare errorCounter INTEGER DEFAULT 0;
    declare SQLCODE INTEGER DEFAULT 0;
    declare SQLSTATE CHAR(5 OCTETS) DEFAULT '00000';
    declare RUN_SQLCODE INTEGER DEFAULT 0;
    declare RUN_SQLSTATE CHAR(5) DEFAULT '00000';
    declare RUN_DIAGNOSTIC_STRING VARCHAR(1024) DEFAULT '';
    declare RUN_RETURN_STATUS INTEGER DEFAULT 0;
    -- Cursor erstellen, welcher über die angeforderten Tabellen iteriert
    DECLARE CURxRT1 INSENSITIVE Cursor
                for
                    select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME like '%_ARCHIVE' and BUILDCODE is not NULL with UR;
    -- Errorhandler definieren
    declare CONTINUE HANDLER for SQLEXCEPTION, SQLWARNING
        begin
            GET DIAGNOSTICS RUN_RETURN_STATUS = DB2_RETURN_STATUS;
            GET DIAGNOSTICS EXCEPTION 1
                RUN_DIAGNOSTIC_STRING = MESSAGE_TEXT;
            select SQLCODE, SQLSTATE into RUN_SQLCODE, RUN_SQLSTATE from SYSIBM.SYSDUMMY1;
            set errorCounter = errorCounter +1;
            --update STG.AUTO_TABLE_AIRFLOW_CONFIG set STATUS = 'FAILED', ERROR_MESSAGE = 'SQLCODE: '||RUN_SQLCODE||' SQLSTATE: '||RUN_SQLSTATE||' RETURN_STATUS: '||RUN_RETURN_STATUS||' '||RUN_DIAGNOSTIC_STRING, FAILED_AT = CURRENT_TIMESTAMP where ID = RUN_ID;
            call CALC.AUTO_PROC_LOG_WARNING('Archiving failed with SQLCODE '||RUN_SQLCODE||', SQLSTATE '||RUN_SQLSTATE||' '||RUN_DIAGNOSTIC_STRING);
        end;
    -- ENDE DEKLARATIONEN

    -- START INITIALISIERE VARIABLEN
    SET curVERSION = 1;
    set desired_TABSCHEMA = TAPE;
    -- ENDE INITIALISIERE VARIABLEN

    -- START LOG PARAMETER
    set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS),0);
    if not continuePrevious then
        set curVERSION = curVERSION+1;
        call CALC.AUTO_PROC_LOG_INFO('Starting execution of CALC.AUTO_PROC_BUILD_ARCHIVES version '||curVERSION||'.');
        insert into CALC.AUTO_TABLE_BUILD_VERSIONS (TAPENAME,GROUPNAME, CUT_OFF_DATE, arg_Stage, arg_useArchive, arg_rebuildAll, arg_VERSION) values (TAPE,'ARCHIVES', for_CUT_OFF_DATE,0,FALSE,FALSE,curVERSION); -- Argumente in Versionstabelle wegschreiben für eventuellen restart
    else
        set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS where not Completed with UR),0);
        call CALC.AUTO_PROC_LOG_INFO('Continuing execution of CALC.AUTO_PROC_BUILD_ARCHIVES version '||curVERSION||'.');
    end if;

    -- Baue alle Tabellen
    call CALC.AUTO_PROC_LOG_INFO('Ready to start building all desired archives.');
    for CA as CURxRT1 Cursor WITH HOLD
        for
            select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME
            from CALC.AUTO_VIEW_TARGETS
            where TABNAME like '%_ARCHIVE' and BUILDCODE is not NULL with UR
    do
        SET desired_TABNAME = CA.TABNAME;
        call CALC.AUTO_PROC_LOG_DEBUG('  Calling Build-Procedure for '||desired_TABSCHEMA||'.'||desired_TABNAME);
        -- Starte die eigentliche Bau Prozedur
        if not EXISTS(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION and TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
            SET doTruncate = (select DO_TRUNCATE_BEFORE_BUILD from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME with UR);
            call CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPE,desired_TABSCHEMA,desired_TABNAME,'  ', doTruncate);
        else
            call CALC.AUTO_PROC_LOG_DEBUG ('    Table already built. Skipping.');
        end if;
    end for;
    --CLOSE CURxRT2;

    -- Aufräumen
    --delete from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = curVERSION;
    --delete from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION;

    if errorCounter > 0 then
        update STG.AUTO_TABLE_AIRFLOW_CONFIG set ERROR_MESSAGE = 'Es sind '||errorCounter||' Fehler aufgetreten. Bitte schaue im Log nach!' where STATUS = 'STARTED' and PROCEDURE in ('ARCHIVE','DO_ARCHIVE_ALL');
    end if;

    update CALC.AUTO_TABLE_BUILD_VERSIONS set (COMPLETED,SUCCESS) = (TRUE,TRUE) where ARG_VERSION = curVERSION;

    call CALC.AUTO_PROC_LOG_INFO('Finished execution of CALC.AUTO_PROC_BUILD_ARCHIVES version '||curVERSION||' successfully.');
  end
&&