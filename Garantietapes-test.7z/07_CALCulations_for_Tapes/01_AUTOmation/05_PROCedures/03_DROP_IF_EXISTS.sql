/* CALC.AUTO_PROC_DROP_IF_EXISTS
 *
 * Diese Prozedur löscht eine Tabelle, falls sie existiert.
 *
 * @input: drop_TABSCHEMA VARCHAR(8)            Name des Schema, der zu löschenden Tabelle
 * @input: drop_TABNAME VARCHAR(128)            Name der zu löschenden Tabelle
 * @input: msgOffset VARCHAR(128)               Offset für die Logs
 */

drop procedure CALC.AUTO_PROC_DROP_IF_EXISTS(varchar(8), varchar(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_DROP_IF_EXISTS(drop_TABSCHEMA varchar(8), drop_TABNAME varchar(128),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare ELEMENT_TYPE varchar(8);
    declare DROP_STATEMENT CLOB(200K);

    if EXISTS(select * from SYSCAT.TABLES where TABNAME = drop_TABNAME and TABSCHEMA = drop_TABSCHEMA) then
        set ELEMENT_TYPE = (select case when TYPE = 'V' then 'view' else 'table' end AS TYPE from SYSCAT.TABLES where TABNAME = drop_TABNAME and TABSCHEMA = drop_TABSCHEMA limit 1);
        set DROP_STATEMENT = 'drop '||ELEMENT_TYPE||' '||drop_TABSCHEMA||'.'||drop_TABNAME;
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(DROP_STATEMENT,msgOffset);
    end if;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_DROP_IF_EXISTS(varchar(8), varchar(128),VARCHAR(128)) is 'Prozedur um eine Tabelle oder View zu löschen.';
