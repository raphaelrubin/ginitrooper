/* CALC.AUTO_PROC_BUILD_GROUP_CONTINUE
 * Setzt die angefangene Bau-prozedur fort.
 *
 * @throws SQLCODE 438, SQLSTATE 72849              Es gibt keine unvollständige Bau-Prozedur zum Fortsetzen.
 */

drop procedure CALC.AUTO_PROC_BUILD_GROUP_CONTINUE(BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP_CONTINUE(rebuild_last_table BOOLEAN)
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
    declare GROUP VARCHAR(128);
    declare for_CUT_OFF_DATE VARCHAR(10);
    declare Stage INT;
    declare useArchive BOOLEAN;
    declare rebuildAll BOOLEAN;
    declare curVERSION BIGINT;
    declare TAPENAME VARCHAR(8);
    declare latestTableId BIGINT;
    declare cur_LIST_ID BIGINT;

    set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS where not Completed with UR),0);

    if curVERSION = 0 then
        signal SQLSTATE '72849' set MESSAGE_TEXT = 'There is no instance of AUTO_PROC_BUILD to be continued.';
    end if;

    set GROUP = (select GROUPNAME from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set for_CUT_OFF_DATE = (select CUT_OFF_DATE from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set Stage = (select ARG_STAGE from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set useArchive = (select ARG_USEARCHIVE from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set rebuildAll = (select ARG_REBUILDALL from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set TAPENAME = (select TAPENAME from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);
    set cur_LIST_ID = (select LIST_ID from CALC.AUTO_TABLE_BUILD_VERSIONS where arg_VERSION = curVERSION limit 1 with UR);

    if rebuild_last_table then
        if Exists(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION) then
            set latestTableId = (select ID from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION order by CREATED_AT desc limit 1);
            delete from CALC.AUTO_TABLE_CHECK_BUILD where ID = latestTableId;
        end if;
    end if;
    if TAPENAME = 'BGA' then
        call CALC.AUTO_PROC_BUILD_GROUP_BGA(cur_LIST_ID, GROUP, for_CUT_OFF_DATE, Stage, useArchive, rebuildAll, TRUE);
    else
        call CALC.AUTO_PROC_BUILD_GROUP (TAPENAME,GROUP, for_CUT_OFF_DATE, Stage, useArchive, rebuildAll, TRUE);
    end if;
  END
&&



--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_GROUP_CONTINUE();
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP_CONTINUE()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
      call CALC.AUTO_PROC_BUILD_GROUP_CONTINUE(FALSE);
  end
&&
--#SET TERMINATOR ;
call sysproc.ADMIN_REVALIDATE_DB_OBJECTS('PROCEDURE','CALC','AUTO_PROC_BUILD_GROUP_CONTINUE');