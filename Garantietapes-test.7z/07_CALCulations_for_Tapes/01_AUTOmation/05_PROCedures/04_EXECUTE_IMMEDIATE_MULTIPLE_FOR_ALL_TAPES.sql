/* CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE_FOR_ALL_TAPES
 *
 * Prozedur, welche mehrere SQL Befehle entgegen nimmt und als einzelne Befehle nacheinander ausführt.
 *
 * @input QUERY_TO_EXECUTE CLOB(400k),      SQL Befehle, welche ausgeführt werden sollen (; getrennt)
 * @input REPLACEMENT_STRING VARCHAR(16)    String, der durch die Tapenamen ersetzt werden soll
 */

drop procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE_FOR_ALL_TAPES(CLOB(400k), VARCHAR(16));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE_FOR_ALL_TAPES(QUERY_TO_EXECUTE CLOB(400k), REPLACEMENT_STRING VARCHAR(16))
    LANGUAGE SQL
BEGIN
    declare cur_Queries CLOB(400k);
    declare cur_Tape VARCHAR(16);
    declare CURSOR_TAPES INSENSITIVE Cursor WITH HOLD
        for
            select distinct NAME from CALC.AUTO_TABLE_TAPES with UR;
    -- Alle tapes durchgehen
    for TAPE as CURSOR_TAPES Cursor WITH HOLD
        for
            select distinct NAME from CALC.AUTO_TABLE_TAPES with UR
    do
        -- Dummywert durch tapenamen ersetzen
        set cur_Tape = TAPE.NAME;
        set cur_Queries = replace(QUERY_TO_EXECUTE,REPLACEMENT_STRING,cur_Tape);
        -- EXECUTE MULTIPLE
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(cur_Queries,'');
    end for;
END
&&