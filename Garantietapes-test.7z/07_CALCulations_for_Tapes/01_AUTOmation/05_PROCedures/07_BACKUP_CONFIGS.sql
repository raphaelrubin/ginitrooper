drop procedure CALC.AUTO_PROC_BACKUP_CONFIGS(VARCHAR(50));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BACKUP_CONFIGS(msgOffset VARCHAR(50))
LANGUAGE SQL
BEGIN

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Creating backups for config tables.');
    -- Alle Configs werden hier gebackkupt. TODO: Neue Config Tabellen müssen hier hinzugefügt werden.
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('CALC','AUTO_TABLE_TARGETS','  '||msgOffset);
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('CALC','AUTO_TABLE_TARGET_TO_SOURCES','  '||msgOffset);
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('CALC','AUTO_TABLE_VALIDATIONS','  '||msgOffset);
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('CALC','AUTO_TABLE_GROUPS','  '||msgOffset);
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('CALC','AUTO_TABLE_TAPES','  '||msgOffset);
    call CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY('AMC','AUTO_TABLE_GROUPS','  '||msgOffset);
    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Finished creating backups for config tables.');

END
&&
