/* CALC.AUTO_PROC_LOG
 *
 * Diese Funktion logged Meldungen in unterscheidlichen Leveln und wirft einen Fehler für Level ERROR aus.
 *
 * @input: LEVEL varchar(8)                 DEBUG/INFO/WARNING/ERROR -> kann durch direktes Aufrufen von
 *                                              AUTO_PROC_LOG_DEBUG/ AUTO_PROC_LOG_INFO/ AUTO_PROC_LOG_WARNING/
 *                                              AUTO_PROC_LOG_ERROR explizit dargestellt werden.
 * @input: MESSAGE varchar(128)             Nachricht, die geloggt werden soll
 *
 * @throws SQLCODE 438, SQLSTATE 70001      Generischer Fehler beim Bauen/Checken einer Tabelle (Benötigte Tabelle
 *                                              konnte für den geforderten Stichtag nicht neu gebaut werden)
 */

drop procedure CALC.AUTO_PROC_LOG(varchar(8), varchar(512),VARCHAR(5));

--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG(LEVEL varchar(8), MESSAGE varchar(512), inSQLSTATE VARCHAR(5))
LANGUAGE SQL
  begin
    declare ERRORMESSAGE varchar(512);
    declare curWarnings INT;
    declare curVersion INT;
    insert into CALC.AUTO_TABLE_LOG (LEVEL,MESSAGE) values (LEVEL,MESSAGE);
    if LEVEL in ('WARNING','ERROR') then
        set curVersion = (select MAX(ARG_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS limit 1);
        set curWarnings = (select WARNINGS from CALC.AUTO_TABLE_BUILD_VERSIONS where ARG_VERSION = curVersion limit 1) + 1;
        update CALC.AUTO_TABLE_BUILD_VERSIONS set WARNINGS = curWarnings where ARG_VERSION = curVersion;
    end if;
    if LEVEL = 'ERROR' then
        set ERRORMESSAGE = trim(B ' ' FROM MESSAGE);
        COMMIT;
        case
            when inSQLSTATE = '70002' then
                signal SQLSTATE '70002' set MESSAGE_TEXT = ERRORMESSAGE;
            when inSQLSTATE = '72723' then
                signal SQLSTATE '72723' set MESSAGE_TEXT = ERRORMESSAGE;
            when inSQLSTATE = '73503' then
                signal SQLSTATE '73503' set MESSAGE_TEXT = ERRORMESSAGE;
            when inSQLSTATE = '7I006' then
                signal SQLSTATE '7I006' set MESSAGE_TEXT = ERRORMESSAGE; -- Input List Error
            else
                signal SQLSTATE '70001' set MESSAGE_TEXT = ERRORMESSAGE;
        end case;
    end if;
  end
&&

--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG is 'Prozedur zum Schreiben von Logs. Diese Prozedur wird von PROC_LOG_DEBUG, PROC_LOG_INFO, PROC_LOG_WARNING, PROC_LOG_ERROR aufgerufen.';



drop procedure CALC.AUTO_PROC_LOG_DEBUG(varchar(512));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG_DEBUG(MESSAGE varchar(512))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_LOG('DEBUG',MESSAGE, NULL);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG_DEBUG is 'Prozedur erstellt einen DEBUG Eintrag im Log.';



drop procedure CALC.AUTO_PROC_LOG_INFO(varchar(512));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG_INFO(MESSAGE varchar(512))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_LOG('INFO',MESSAGE, NULL);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG_INFO is 'Prozedur erstellt einen INFO Eintrag im Log.';



drop procedure CALC.AUTO_PROC_LOG_WARNING(varchar(512));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG_WARNING(MESSAGE varchar(512))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_LOG('WARNING',MESSAGE, NULL);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG_WARNING is 'Prozedur erstellt einen WARNING Eintrag im Log.';



drop procedure CALC.AUTO_PROC_LOG_ERROR(varchar(512));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG_ERROR(MESSAGE varchar(512))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_LOG('ERROR',MESSAGE, '70001');
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG_ERROR(varchar(512)) is 'Prozedur erstellt einen ERROR Eintrag im Log und schmeißt Fehler 70001.';



drop procedure CALC.AUTO_PROC_LOG_ERROR(varchar(512),VARCHAR(5));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_LOG_ERROR(MESSAGE varchar(512), inSQLSTATE VARCHAR(5))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_LOG('ERROR',MESSAGE, inSQLSTATE);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_LOG_ERROR(varchar(512),VARCHAR(5)) is 'Prozedur erstellt einen ERROR Eintrag im Log und schmeißt den gewünschten Fehler wenn bekannt und sonst 70001.';
