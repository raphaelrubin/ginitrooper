/* CALC.AUTO_PROC_SWITCH_CREATE
 *
 * Diese Prozedur erstellt eine Switch View.
 *
 * @input: TAPENAME VARCHAR(8)              Name des aktiven Schemas
 * @input: TABNAME VARCHAR(128)             Name der Tabelle, für welche die Switch View gebaut werden soll
 * @input: msgOffset VARCHAR(128)           String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                          Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu
 *                                          lesen ist.
 */

drop procedure CALC.AUTO_PROC_SWITCH_CREATE(varchar(8), varchar(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_SWITCH_CREATE(TAPENAME varchar(8), TABNAME varchar(128),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare SWITCHNAME varchar(512);
    declare TABLENAME varchar(256);
    declare CREATE_STATEMENT CLOB(200K);
    declare curQueryShort VARCHAR(450);

    set SWITCHNAME = 'CALC.'||CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH(TABNAME);
    set TABLENAME = TAPENAME||'.'||TABNAME;

    set CREATE_STATEMENT = 'create view '||SWITCHNAME||' as select * from '||TABLENAME;

   -- call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CREATE_STATEMENT,msgOffset);
    if msgOffset is not NULL then
        set curQueryShort = left(CREATE_STATEMENT,450);
        set curQueryShort = coalesce(trim(B FROM curQueryShort),'');
        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  About to execute: "' || trim(B FROM curQueryShort) ||'".');
    end if;
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,CREATE_STATEMENT);
    BEGIN ATOMIC
        EXECUTE IMMEDIATE CREATE_STATEMENT;
    END;
    COMMIT;
    if msgOffset is not NULL then
        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  Done executing.');
    end if;

    set CREATE_STATEMENT = 'grant select on '||SWITCHNAME||' to group NLB_MW_ADAP_S_GNI_TROOPER';
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CREATE_STATEMENT,msgOffset);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_SWITCH_CREATE(varchar(8), varchar(128),VARCHAR(128)) is 'Prozedur zum Erstellen eines Switches und Loggen des Vorgangs.';



drop procedure CALC.AUTO_PROC_SWITCH_CREATE(varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_SWITCH_CREATE(TAPENAME varchar(8), TABNAME varchar(128))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_SWITCH_CREATE(TAPENAME, TABNAME, NULL);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_SWITCH_CREATE(varchar(8), varchar(128)) is 'Prozedur zum Erstellen eines Switches.';
