/* CALC.AUTO_PROC_RAISE_ERROR
 *
 * Diese Prozedur schmeißt den gewünschten Fehler (Die Prozedur wird bisher nur sporadisch verwendet, aber die Idee war,
 * alle Fehlermeldungen an einem Ort zu haben.)
 *
 * @input: ERRORNAME VARCHAR(128)           SQLSTATE für den ein Fehler gemeldet werden soll.
 * @input: ERRORMESSAGE VARCHAR(70)         Nachricht, die angezeigt werden soll
 *
 * @throws Alle möglichen Fehler
 */

drop procedure CALC.AUTO_PROC_RAISE_ERROR( VARCHAR(128), VARCHAR(70));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_RAISE_ERROR(ERRORNAME VARCHAR(128), ERRORMESSAGE VARCHAR(70))
    LANGUAGE SQL
BEGIN
    declare STOREDMESSAGE VARCHAR(256);
    declare DUPLICATECOUNT INT;
    declare useStoredMessage BOOLEAN;

    set STOREDMESSAGE = '';
    set useStoredMessage = FALSE;
    if EXISTS(select * from CALC.AUTO_TABLE_ERRORS where SQLCODE = 438 and SQLSTATE = ERRORNAME) then
        SET DUPLICATECOUNT = (select COUNT(*) AS COUNT from CALC.AUTO_TABLE_ERRORS where SQLCODE = 438 and SQLSTATE = ERRORNAME limit 1);
        if DUPLICATECOUNT = 1 then
            SET STOREDMESSAGE = (select MESSAGE from CALC.AUTO_TABLE_ERRORS where SQLCODE = 438 and SQLSTATE = ERRORNAME limit 1);
            if not STOREDMESSAGE like '%*%' then
                set useStoredMessage = TRUE;
            end if;
        end if;
    end if;

    if useStoredMessage then
        set ERRORMESSAGE = STOREDMESSAGE;
    end if;

    case
        when ERRORNAME = '71542' then
            SIGNAL SQLSTATE '71542'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '72503' then
            SIGNAL SQLSTATE '72503'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '72505' then
            SIGNAL SQLSTATE '72505'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '72849' then
            SIGNAL SQLSTATE '72849'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '73503' then
            SIGNAL SQLSTATE '73503'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '73505' then
            SIGNAL SQLSTATE '73505'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '73513' then
            SIGNAL SQLSTATE '73513'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '7C000' then
            SIGNAL SQLSTATE '7C000'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '7C001' then
            SIGNAL SQLSTATE '7C001'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '7C200' then
            SIGNAL SQLSTATE '7C200'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '7T011' or lower(ERRORNAME) = 'unknown Tape' then
            set ERRORMESSAGE = ERRORMESSAGE || ' doesn''t exist as a Tape in CALC.AUTO_TABLE_TAPES';
            SIGNAL SQLSTATE '7T011'  set MESSAGE_TEXT = ERRORMESSAGE;
        when ERRORNAME = '7T010' or lower(ERRORNAME) = 'immortal amc tape' then
            SIGNAL SQLSTATE '7T010'  set MESSAGE_TEXT = ERRORMESSAGE;
        else
            SIGNAL SQLSTATE '70001'  set MESSAGE_TEXT = ERRORMESSAGE;
    end case;
END
&&