/* CALC.AUTO_PROC_EXECUTE_LATER
 *
 * Prozedur, welche einen SQL Befehl entgegen nimmt und als in den Ablaufplan TABLE_EXECUTION_PLAN schreibt.
 *
 * @input arg_VERSION BIGINT,       Versionsnummer der AUTO_BUILD Ausführung
 * @input arg_COMMAND CLOB(200K),   SQL Befehl, welcher zum Ablaufplan hinzugefügt werden soll
 * @input msgOffset VARCHAR(128)    String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                  Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu lesen
 *                                  ist.
 */

drop procedure CALC.AUTO_PROC_EXECUTE_LATER(BIGINT, CLOB(200K), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_LATER(arg_VERSION BIGINT, arg_COMMAND CLOB(200K),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare curQueryShort VARCHAR(450);
    set curQueryShort = left(arg_COMMAND,450);
    set curQueryShort = coalesce(trim(B FROM curQueryShort),'');
    call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  Adding "' || trim(B FROM curQueryShort) ||'" to execution plan.');
    insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) values (arg_VERSION,arg_COMMAND);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXECUTE_LATER is 'Prozedur zum Schreiben eines SQL Befehls in den Ausführungsplan. (wird zur Zeit nicht genutzt)';
