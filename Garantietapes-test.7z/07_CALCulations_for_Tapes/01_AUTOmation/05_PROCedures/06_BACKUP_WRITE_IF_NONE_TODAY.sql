drop procedure CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY(VARCHAR(8), VARCHAR(128), VARCHAR(50));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BACKUP_WRITE_IF_NONE_TODAY(in_TABSCHEMA VARCHAR(8),in_TABNAME VARCHAR(128),msgOffset VARCHAR(50) )
LANGUAGE SQL
BEGIN
    if not EXISTS(
select * from (
                  select TABSCHEMA,
                         trim(BOTH '_' FROM
                              trim(TRANSLATE(replace(TABNAME, 'BACKUP', ''), '', '0123456789'))) as TABNAME,
                         TABNAME                                                                 as TABNAME_BACKUP,
                         DATE(CREATE_TIME) as CREATED_AT
                  from SYSCAT.TABLES
                  where TABNAME like '%BACKUP%'
              )
where TABSCHEMA = in_TABSCHEMA
  and TABNAME = in_TABNAME
  and CREATED_AT = CURRENT_DATE ) then
        call CALC.AUTO_PROC_BACKUP_WRITE(in_TABSCHEMA,in_TABNAME,msgOffset);
  end if;

END
&&