/* CALC.AUTO_PROC_TAPE_CLONE
 *
 * Diese Prozedur erstellt ein neues Tape basierend auf einem bestehendem Tape
 *
 * @input: TAPE_toclone VARCHAR(8)              Name des existierenden Tapes, das geklont werden soll
 * @input: new_TAPE VARCHAR(8)                  Name des neuen Tapes
 * @input: TAPE_DESCRIPTION VARCHAR(128)        Beschreibung des Tapes damit alle wissen, worum es hierbei geht.
 */

drop procedure CALC.AUTO_PROC_TAPE_CLONE(VARCHAR(8),varchar(8),varchar(512));
--#SET TERMINATOR &&
-- TODO: Anpassung für CALC.AUTO_TABLE_TARGETS notwendig! Nicht alle Tabellen müssen neu eingefügt werden...
create or replace procedure CALC.AUTO_PROC_TAPE_CLONE (TAPE_toclone varchar(8),new_TAPE varchar(8),TAPE_DESCRIPTION varchar(512))
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    -- Alle Tabellen
    declare CURxT1 INSENSITIVE Cursor WITH HOLD
        for
        select new_TAPE||'.'||TABNAME as TABLENAME_NEW,
               TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               *
        from CALC.AUTO_VIEW_TARGETS
        where TABSCHEMA = TAPE_toclone and TYPE = 'T'
        with UR;
    -- Alle Tabellen die in T2S kopiert werden müssen
    declare CURxT2 INSENSITIVE Cursor WITH HOLD
        for
        select new_TAPE||'.'||TABNAME as TABLENAME_NEW,
               TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               *
        from CALC.AUTO_VIEW_TARGETS
        where BUILD_VIEW_SCHEMA = TAPE_toclone and TYPE = 'T'
        with UR;

    call CALC.AUTO_PROC_LOG_INFO('Starting to create a new Tape '||new_TAPE||' based on '||TAPE_toclone||'.');

    call CALC.AUTO_PROC_CONTROL_PREPARE(TAPE_toclone);

    -- 0) Das Tape muss zur Tabelle hinzugefügt werden.
    insert into CALC.AUTO_TABLE_TAPES (NAME, DESCRIPTION) VALUES (new_TAPE,TAPE_DESCRIPTION);
    COMMIT;

    -- 1) Die Steuerungstabellen müssen geklont werden
    --call CALC.AUTO_PROC_LOG_INFO('  Cloning control tables');
    --call CALC.AUTO_PROC_CONTROL_CLONE(TAPE_toclone,new_TAPE,'');
    --COMMIT;

    -- 2) Alle Tabellen müssen erstellt werden
    call CALC.AUTO_PROC_LOG_INFO('  Cloning tape tables');
    for BASETABLE as CURxT1 Cursor WITH HOLD
        for
        select new_TAPE||'.'||TABNAME as TABLENAME_NEW,
               TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               *
        from CALC.AUTO_VIEW_TARGETS
        where TABSCHEMA = TAPE_toclone and TYPE = 'T'
        with UR
    do
        call CALC.AUTO_PROC_LOG_DEBUG('    Cloning '||BASETABLE.TABLENAME_OLD);
        -- Tabelle Erstellen
--         set curQuery = 'create table '||BASETABLE.TABLENAME_NEW||' like '||BASETABLE.TABLENAME_OLD;
--         call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'  ');
        call CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(new_TAPE, BASETABLE.TABNAME, BASETABLE.TABSCHEMA, BASETABLE.TABNAME, '    ');
        -- Index auf CoD erstellen:
        if (BASETABLE.COLNAME_CUT_OFF_DATE is not NULL and BASETABLE.TABSCHEMA = TAPE_toclone) then
            call CALC.AUTO_PROC_LOG_DEBUG('    Creating Index on '||BASETABLE.COLNAME_CUT_OFF_DATE);
            set curQuery = 'create index '||new_TAPE||'.INDEX_'||BASETABLE.TABNAME||'_CUT_OFF_DATE on '||new_TAPE||'.'||BASETABLE.TABNAME||' ('||BASETABLE.COLNAME_CUT_OFF_DATE||')';
            call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'      ');
        end if;
        -- Tabelle zur Steuerung hinzufügen
        --call CALC.AUTO_PROC_LOG_DEBUG('    Saving '||BASETABLE.TABLENAME_OLD);
        --set curQuery = 'insert into CALC.AUTO_TABLE_TARGETS (TABSCHEMA, TABNAME, COLNAME_CUT_OFF_DATE, IS_AUTOMATEABLE, DO_TRUNCATE_BEFORE_BUILD, BUILDCODE, BUILD_VIEW_SCHEMA, RECREATECODE) ' ||
        --               'values ('''||new_TAPE||''','''||BASETABLE.TABNAME||''','||COALESCE(''''||BASETABLE.COLNAME_CUT_OFF_DATE||'''','NULL')||','||BASETABLE.IS_AUTOMATEABLE||','||COALESCE(cast(BASETABLE.DO_TRUNCATE_BEFORE_BUILD as VARCHAR(8)),'NULL')||','||
        --               COALESCE(''''||REPLACE(REPLACE(BASETABLE.BUILDCODE,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||','||
        --               COALESCE(''''||REPLACE(REPLACE(BASETABLE.BUILD_VIEW_SCHEMA,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||','||
        --               COALESCE(''''||REPLACE(REPLACE(BASETABLE.RECREATECODE,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||')';
        --call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');
    end for;
    -- 4) und zur Steuerungstabelle hinzugefügt werden
    for BASETABLE as CURxT2 Cursor WITH HOLD
        for
        select new_TAPE||'.'||TABNAME as TABLENAME_NEW,
               TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               *
        from CALC.AUTO_VIEW_TARGETS
        where BUILD_VIEW_SCHEMA = TAPE_toclone and TYPE = 'T'
        with UR
    do
        call CALC.AUTO_PROC_LOG_DEBUG('    Registering '||BASETABLE.TABLENAME_OLD);

        -- Tabelle zur Steuerung hinzufügen
        set curQuery = 'insert into CALC.AUTO_TABLE_TARGETS (TABSCHEMA, TABNAME, COLNAME_CUT_OFF_DATE, IS_AUTOMATEABLE, DO_TRUNCATE_BEFORE_BUILD, BUILDCODE, BUILD_VIEW_SCHEMA, RECREATECODE) ' ||
                      'values ('''||new_TAPE||''','''||BASETABLE.TABNAME||''','||COALESCE(''''||BASETABLE.COLNAME_CUT_OFF_DATE||'''','NULL')||','||BASETABLE.IS_AUTOMATEABLE||','||COALESCE(cast(BASETABLE.DO_TRUNCATE_BEFORE_BUILD as VARCHAR(8)),'NULL')||','||
                      COALESCE(''''||REPLACE(REPLACE(BASETABLE.BUILDCODE,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||','||
                      COALESCE(''''||REPLACE(REPLACE(BASETABLE.BUILD_VIEW_SCHEMA,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||','||
                      COALESCE(''''||REPLACE(REPLACE(BASETABLE.RECREATECODE,TAPE_toclone||'.',new_TAPE||'.'),'''','''''')||'''','NULL')||')';
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');
    end for;

    -- 3) Alle Anderen Tabellen müssen zur Steuerung hinzugefügt werden.

    -- TODO: select * from CALC.AUTO_VIEW_TARGET_TO_SOURCES where BUILD_VIEW_SCHEMA_SOURCE = 'FKW' or BUILD_VIEW_SCHEMA_TARGET = 'FKW';

    -- AUTO_TABLE_TARGET_TO_SOURCES
    set curQuery = 'insert into CALC.AUTO_TABLE_TARGET_TO_SOURCES (TABSCHEMA_TARGET, TABNAME_TARGET, TABSCHEMA_SOURCE, TABNAME_SOURCE, REQUIRED, STAGE_REQUIRED_AT, VALID_FROM, VALID_UNTIL) ' ||
                   'select ' ||
                   'REPLACE(TABSCHEMA_TARGET,'''||TAPE_toclone||''','''||new_TAPE||''') AS TABSCHEMA_TARGET, ' ||
                   'TABNAME_TARGET, ' ||
                   'REPLACE(TABSCHEMA_SOURCE,'''||TAPE_toclone||''','''||new_TAPE||''') AS TABSCHEMA_SOURCE, ' ||
                   'TABNAME_SOURCE, ' ||
                   'REQUIRED, ' ||
                   'STAGE_REQUIRED_AT, ' ||
                   'VALID_FROM, ' ||
                   'VALID_UNTIL ' ||
                   'from CALC.AUTO_TABLE_TARGET_TO_SOURCES ' ||
                   'where (BUILD_VIEW_SCHEMA_SOURCE = '''||TAPE_toclone||''' or BUILD_VIEW_SCHEMA_TARGET = '''||TAPE_toclone||''')';
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'  ');

    call CALC.AUTO_PROC_LOG_INFO('Finished to create the new Tape '||new_TAPE||' based on '||TAPE_toclone||'.');
end
&&