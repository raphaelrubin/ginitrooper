/* CALC.AUTO_PROC_BUILD_GROUP
 * Baut alle Tabellen, die zur gewünschten Gruppe gehören neu.
 *
 * @input: TAPE VARCHAR(8)                  Name des aktiven Tapes
 * @input: GROUP VARCHAR(128)
 *                                          a) Tablename as defined in CALC.AUTO_TABLE_GROUPS (needs to be an AMC Table to be in there)
 *                                          b) Groupname as defined in CALC.AUTO_TABLE_GROUPS
 * @input: for_CUT_OFF_DATE VARCHAR(10)     Cut off date in the a valid date format (i.e. 30.09.2019)
 * @input: Stage INT                        Stufe der Gründlichkeit (siehe Stages in TARGET_TO_SOURCES)
 * @input: useArchive BOOLEAN               Dürfen Archive benutzt werden obwohl die Tabelle neu gebaut werden kann?
 * @input: rebuildAll BOOLEAN               Müssen alle Tabellen neu gebaut werden?
 * @input: continuePrevious BOOLEAN         Soll die vorherige Ausführung fortgesetzt werden?
 * @throws SQLCODE 438, SQLSTATE 70001, Invalid table name *.   Eine der zu bauenden Tabellen ist nicht in CALC.AUTO_TABLE_TARGETS definiert.
 */

drop procedure CALC.AUTO_PROC_BUILD_GROUP(VARCHAR(8),VARCHAR(128),VARCHAR(10), INT, BOOLEAN, BOOLEAN, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP (TAPE VARCHAR(8), GROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10), Stage INT, useArchive BOOLEAN, rebuildAll BOOLEAN, continuePrevious BOOLEAN)
    LANGUAGE SQL
  BEGIN
    -- START DEKLARATIONEN
    declare curVERSION BIGINT;
    declare CUT_OFF_DATE_COLNAME VARCHAR(64);
    declare desired_TABSCHEMA VARCHAR(8);
    declare desired_TABNAME VARCHAR(128);
    declare hasPassed BOOLEAN;
    declare ERROR_MESSAGE VARCHAR(128);
    declare MESSAGE VARCHAR(256);
    -- Cursor erstellen, welcher über die angeforderten Tabellen iteriert
    DECLARE CURxRT1 INSENSITIVE Cursor
                for
                    select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
                    union all
                    select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP  with UR; --TODO: switch to VIEW
    DECLARE CURxRT2 INSENSITIVE Cursor WITH HOLD
                for
                    select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
                    union all
                    select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP  with UR; -- TODO order by TABNAME
    DECLARE CURxRT3 INSENSITIVE Cursor WITH HOLD
                for
                    select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
                    union all
                    select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP  with UR;
    -- ENDE DEKLARATIONEN

    -- START INITIALISIERE VARIABLEN
    SET curVERSION = 1;
    set desired_TABSCHEMA = TAPE;
    -- ENDE INITIALISIERE VARIABLEN

    -- START LOG PARAMETER
    set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS),0);
    if not continuePrevious then
        set curVERSION = curVERSION+1;
        call CALC.AUTO_PROC_LOG_INFO('Starting execution of CALC.AUTO_PROC_BUILD_GROUP version '||curVERSION||'.');
        insert into CALC.AUTO_TABLE_BUILD_VERSIONS (TAPENAME,GROUPNAME, CUT_OFF_DATE, arg_Stage, arg_useArchive, arg_rebuildAll, arg_VERSION) values (TAPE,GROUP, for_CUT_OFF_DATE,Stage,useArchive,rebuildAll,curVERSION); -- Argumente in Versionstabelle wegschreiben für eventuellen restart
    else
        set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS where not Completed with UR),0);
        if not EXISTS(select * from (select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC limit 1) as LAST where LEVEL in ('ERROR','WARNING')) then
            -- Letzter Eintrag im Log ist kein Fehler. Deswegen stellen wir ihn nochmal als Fehler ein.
            set MESSAGE = (select MESSAGE from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC limit 1);
            call CALC.AUTO_PROC_LOG_WARNING('Procedure stopped after "'||trim(MESSAGE)||'".');
        end if;
        call CALC.AUTO_PROC_LOG_INFO('Continuing execution of CALC.AUTO_PROC_BUILD_GROUP version '||curVERSION||'.');
    end if;
    -- Check CUT OFF DATE
    if not EXISTS(select * from CALC.AUTO_TABLE_CUTOFFDATES where CUT_OFF_DATE = for_CUT_OFF_DATE) then
        -- neues COD
        if not EXISTS(select * from CALC.AUTO_TABLE_CUTOFFDATES where CUT_OFF_DATE > for_CUT_OFF_DATE) and last_day(DATE(for_CUT_OFF_DATE)) = DATE(for_CUT_OFF_DATE) then
            -- neues COD ist gültig und sollte daher hinzugefügt werden.
            insert into CALC.AUTO_TABLE_CUTOFFDATES (CUT_OFF_DATE) values (DATE(for_CUT_OFF_DATE));
        else
            -- ungültiges COD
            call CALC.AUTO_PROC_LOG_ERROR('Invalid cutoffdate "'||for_CUT_OFF_DATE||'".');
        end if;
    end if;
    update CALC.AUTO_TABLE_CUTOFFDATES set IS_ACTIVE = FALSE where IS_ACTIVE = TRUE;
    update CALC.AUTO_TABLE_CUTOFFDATES set IS_ACTIVE = TRUE where CUT_OFF_DATE = for_CUT_OFF_DATE;

    -- List Parameters
    call CALC.AUTO_PROC_LOG_DEBUG(CALC.AUTO_FUNC_STAGE_TO_TEXT(Stage));
    call CALC.AUTO_PROC_LOG_DEBUG('Desired group is '||GROUP||'.');
    call CALC.AUTO_PROC_LOG_DEBUG('Desired cut off date is '||for_CUT_OFF_DATE||'.');
    if useArchive then
        call CALC.AUTO_PROC_LOG_DEBUG('The use of archives is allowed.');
    else
        call CALC.AUTO_PROC_LOG_DEBUG('The use of archives is not allowed.');
    end if;
    -- ENDE LOG PARAMETER

    -- Checke alle Tabellen
    call CALC.AUTO_PROC_LOG_INFO('Checking if all required tables are in my database.');
    for CA as CURxRT1 Cursor
        for
            select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
            union all
            select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP with UR
    do
        SET desired_TABNAME = CA.TABNAME;
        call CALC.AUTO_PROC_LOG_DEBUG('  Checking '||desired_TABSCHEMA||'.'||desired_TABNAME);
        -- Check if table is known to the procedure
        if not EXISTS(select * from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
            call CALC.AUTO_PROC_LOG_ERROR('I don''t know '||desired_TABSCHEMA||'.'||desired_TABNAME||'. Please add the table to CALC.AUTO_TABLE_TARGETS and CALC.AUTO_TABLE_TARGET_TO_SOURCES and try again.','73503');
        end if;
    end for;
    --CLOSE CURxRT1;

    if not rebuildAll then
        -- Leere alle Tabellen um zu verhindern, dass alte Versionen eigener Tabellen genutzt werden wenn rebuildAll=false
        call CALC.AUTO_PROC_LOG_INFO('Truncating all group tables before building.');
        for CA as CURxRT3 Cursor WITH HOLD
            for
                select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
                union all
                select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP with UR
        do
            SET desired_TABNAME = CA.TABNAME;
            -- Nur leeren falls noch nicht gebaut (fuer continue)
            if not EXISTS(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION and TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
                call CALC.AUTO_PROC_LOG_DEBUG('  Truncating '||desired_TABSCHEMA||'.'||desired_TABNAME);
                -- Aktuell vorhandene Daten aus Tabelle löschen
                call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CALC.AUTO_FUNC_GET_TRUNCATE_CODE(desired_TABSCHEMA,desired_TABNAME),'  ');
            else
                call CALC.AUTO_PROC_LOG_DEBUG ('    Table already built. Skipping truncate.');
            end if;
        end for;
    end if;

    -- Kontrolltabellen vorbereiten
    --call CALC.AUTO_PROC_CONTROL_PREPARE(TAPE);
    -- Baue alle Tabellen
    call CALC.AUTO_PROC_LOG_INFO('Ready to start building all desired tables.');
    for CA as CURxRT2 Cursor WITH HOLD
        for
            select distinct CALC.AUTO_FUNC_CHANGE_NAME_FINAL_TO_CURRENT(TABNAME) as TABNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
            union all
            select TABNAME as TABNAME from CALC.AUTO_VIEW_TARGETS where TABNAME = GROUP with UR--TODO: order by TABNAME
    do
        SET desired_TABNAME = CA.TABNAME;
        call CALC.AUTO_PROC_LOG_DEBUG('  Calling Build-Procedure for '||desired_TABSCHEMA||'.'||desired_TABNAME);
        -- Überprüfe, ob die tabelle schon gebaut wurde
        if not EXISTS(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION and TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
            -- Starte die eigentliche Bau Prozedur
            call CALC.AUTO_PROC_BUILD_TABLE (TAPE,desired_TABSCHEMA,desired_TABNAME,for_CUT_OFF_DATE,Stage, useArchive, rebuildAll, curVERSION,1);
            -- Überprüfe ob der gewünschte Stichtag im Ergebnis enthalten ist.
            set CUT_OFF_DATE_COLNAME = (select COLNAME_CUT_OFF_DATE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME);
            call CALC.AUTO_PROC_LOG_DEBUG('call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED('||desired_TABSCHEMA||', '||desired_TABNAME||','||CUT_OFF_DATE_COLNAME||', '||curVERSION||','||for_CUT_OFF_DATE||', TRUE, hasPassed);');
            call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(desired_TABSCHEMA, desired_TABNAME,CUT_OFF_DATE_COLNAME, curVERSION,for_CUT_OFF_DATE, TRUE, hasPassed);
            set hasPassed = CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(desired_TABSCHEMA,desired_TABNAME, curVERSION);
            if not hasPassed then
                SET ERROR_MESSAGE = '  ' || desired_TABSCHEMA || '.' || desired_TABNAME || ' failed to rebuild for ' || for_CUT_OFF_DATE;
                call CALC.AUTO_PROC_LOG_ERROR(ERROR_MESSAGE);
            end if;
        else
            call CALC.AUTO_PROC_LOG_DEBUG ('    Table already built. Skipping.');
        end if;
    end for;

    -- Aufräumen
    --delete from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = curVERSION;
    --delete from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = curVERSION;
    call CALC.AUTO_PROC_BACKUP_CONFIGS('');  -- Backups der wichtigen Config Tabellen erstellen
                                                        -- (wir führen diese Prozedur ständig aus, deswegen hier)

    call CALC.AUTO_PROC_BACKUP_DELETE_UNNECESSARY('');

    update CALC.AUTO_TABLE_BUILD_VERSIONS set (COMPLETED,SUCCESS) = (TRUE,TRUE) where ARG_VERSION = curVERSION;

    call CALC.AUTO_PROC_LOG_INFO('Finished execution of CALC.AUTO_PROC_BUILD_GROUP version '||curVERSION||' successfully.');
  end
&&



-- OVERLOADED PROCEDURES
--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_GROUP( VARCHAR(8),VARCHAR(128),VARCHAR(10), VARCHAR(32));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP (TAPE VARCHAR(8), GROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10), Mode VARCHAR(32))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
    declare Stage INT;
    declare useArchive BOOLEAN;
    declare rebuildAll BOOLEAN;

    if EXISTS(select * from CALC.AUTO_TABLE_BUILD_VERSIONS where COMPLETED = FALSE) then
        signal SQLSTATE '72723' set MESSAGE_TEXT = 'An instance of AUTO_PROC_BUILD is still executing or has not completed.';
    end if;

    if not EXISTS(select * from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode)) then
        call CALC.AUTO_PROC_LOG_WARNING('Didn''t find system-group, using DEFAULT instead. Check call CALC.HELP_ME_WITH_THE_OPTIONS(); for valid system-groups.');
        set Mode = 'DEFAULT';
    end if;
    set Stage = (select STAGE from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    set useArchive = (select useArchive from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    set rebuildAll = (select rebuildAll from CALC.AUTO_TABLE_MODES where upper(NAME) = upper(Mode) limit 1 with UR);
    call CALC.AUTO_PROC_BUILD_GROUP (TAPE,GROUP, for_CUT_OFF_DATE, Stage, useArchive, rebuildAll, FALSE);
  end
&&



--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_GROUP(varchar(8),VARCHAR(128),VARCHAR(10));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP (TAPE varchar(8), GROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
      declare Stage INT;
      declare useArchive BOOLEAN;
      set Stage = 4;
      set useArchive = true;
      call CALC.AUTO_PROC_BUILD_GROUP (TAPE, GROUP, for_CUT_OFF_DATE, Stage, useArchive, TRUE, FALSE);
  end
&&