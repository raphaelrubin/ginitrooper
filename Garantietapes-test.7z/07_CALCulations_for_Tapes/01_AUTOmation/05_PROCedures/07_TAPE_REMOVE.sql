/* CALC.AUTO_PROC_TAPE_REMOVE
 *
 * Diese Prozedur löscht ein bestehendes Tape
 *
 * @input: TAPE_toremove VARCHAR(8)             Name des existierenden Tapes, das gelöscht werden soll
 */

drop procedure CALC.AUTO_PROC_TAPE_REMOVE(VARCHAR(8));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_TAPE_REMOVE (TAPE_toremove varchar(8))
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    declare ref_Tape VARCHAR(8);
    declare ERRORMESSAGE VARCHAR(75);
    declare CURxT1 INSENSITIVE Cursor WITH HOLD
        for
        select TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               TABNAME
        from CALC.AUTO_VIEW_TARGETS
        where TABSCHEMA = TAPE_toremove
        with UR;

    if TAPE_toremove = 'AMC' then
        call CALC.AUTO_PROC_RAISE_ERROR('7T010', '');
    end if;

    if not EXISTS(select * from CALC.AUTO_TABLE_TAPES where NAME = TAPE_toremove) then
        call CALC.AUTO_PROC_RAISE_ERROR('unknown tape', TAPE_toremove);
    end if;

    call CALC.AUTO_PROC_LOG_INFO('Removing tape '||TAPE_toremove);

    call CALC.AUTO_PROC_CONTROL_PREPARE(TAPE_toremove);
    call CALC.AUTO_PROC_LOG_INFO('Prepared control tables '||TAPE_toremove);

    -- 1) Alle Tabellen müssen gelöscht werden
    for BASETABLE as CURxT1 Cursor WITH HOLD
        for
        select TABSCHEMA||'.'||TABNAME as TABLENAME_OLD,
               TABNAME
        from CALC.AUTO_VIEW_TARGETS
        where TABSCHEMA = TAPE_toremove
        with UR
    do
        call CALC.AUTO_PROC_LOG_INFO('Removing '||TAPE_toremove||'.'||BASETABLE.TABNAME);
        --set curQuery = 'drop table '||BASETABLE.TABLENAME_OLD;
        call CALC.AUTO_PROC_DROP_IF_EXISTS(TAPE_toremove, BASETABLE.TABNAME,'');
        --call CALC.AUTO_PROC_LOG_WARNING(curQuery);
    end for;

    -- 2) Die Steuerungstabellen müssen gelöscht werden.
    call CALC.AUTO_PROC_LOG_INFO('  Removing control tables.');
    call CALC.AUTO_PROC_CONTROL_REMOVE(TAPE_toremove,'');

    -- todo: Die TARGET und T2S müssen bereinigt werden (alles mit BUILD_VIEW_SCHEMA = Tape raus)

    -- 3) Das Tape muss aus der Tabelle entfernt werden.
    call CALC.AUTO_PROC_LOG_INFO('  Removing the Tape.');
    delete from CALC.AUTO_TABLE_TAPES where NAME = TAPE_toremove;

    -- AUfräumen
    call CALC.AUTO_PROC_LOG_INFO('  Tidying up.');
    set ref_Tape = (select NAME from CALC.AUTO_TABLE_TAPES limit 1);
    call CALC.AUTO_PROC_CONTROL_PREPARE(ref_Tape);

    call CALC.AUTO_PROC_LOG_INFO('Finished removing the tape.');
  end
&&

-- Kommentar für CI-Test
