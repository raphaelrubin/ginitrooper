/* CALC.AUTO_PROC_ALPACA_CLONE
 * Nutzt die verdienten Sterne, um Alpaka zu klonen.
 *
 * @input: desiredNumber INT                Wie viele Alpaka sollen geklont werden?
 * @throws SQLCODE 438, SQLSTATE 7A100      Du hast nicht die Berechtigung Alpaka zu klonen.
 * @throws SQLCODE 438, SQLSTATE 7A200      Du hast keine Alpaka mehr, die geklont werden könnten.
 * @throws SQLCODE 438, SQLSTATE 7A201      Du kannst keine negative Anzahl an Alpaka klonen.
 * @throws SQLCODE 438, SQLSTATE 7A202      Du hast nicht genügend Sterne zum Alpaka klonen.
 */
drop procedure CALC.AUTO_PROC_ALPACA_CLONE(INT);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_ALPACA_CLONE(desiredNumber INT)
LANGUAGE SQL
  begin
    declare ERRORMESSAGE varchar(512);
    declare CurStars BIGINT;
    declare CurAlpacas BIGINT;

    --if (SESSION_USER <> 'DB124560') then
    --    set ERRORMESSAGE = 'The authorization ID does not have the privilege to clone alpaca.';
    --    signal SQLSTATE '7A100' set MESSAGE_TEXT = ERRORMESSAGE;
    --end if;

    set CurStars = (select STARS from CALC.AUTO_VIEW_ALPACA limit 1);
    set CurAlpacas = (select ALPACA from CALC.AUTO_VIEW_ALPACA limit 1);

    if (CurAlpacas < 1) then
        set ERRORMESSAGE = 'Insufficient alpacas remain for cloning.';
        signal SQLSTATE '7A200' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;

    if (desiredNumber < 0) then
        set ERRORMESSAGE = 'Your request doesn''t make sense.';
        signal SQLSTATE '7A201' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;

    if (desiredNumber*200 > CurStars) then
        set ERRORMESSAGE = 'Insufficient stars to clone that many alpaca.';
        signal SQLSTATE '7A202' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;

    insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (desiredNumber,-200*desiredNumber);

  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_ALPACA_CLONE is 'Prozedur zum Klonen männlicher weißer Alpaka mit Hilfe magischer Sterne.';
