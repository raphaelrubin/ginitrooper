
drop procedure CALC.AUTO_PROC_BACKUP_DELETE_UNNECESSARY(VARCHAR(50));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BACKUP_DELETE_UNNECESSARY(msgOffset VARCHAR(50))
LANGUAGE SQL
BEGIN
    DECLARE CODE CLOB(200k);
    DECLARE CURxRT1 INSENSITIVE Cursor WITH HOLD
        for
            select DROP_STATEMENT from CALC.AUTO_VIEW_BACKUPS_TO_DROP;


    call CALC.AUTO_PROC_LOG_INFO('Dropping old backups');

    for CA as CURxRT1 Cursor WITH HOLD
        for
            select DROP_STATEMENT from CALC.AUTO_VIEW_BACKUPS_TO_DROP
    do
        SET CODE = CA.DROP_STATEMENT;
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CODE,'  '||msgOffset);
    end for;

    call CALC.AUTO_PROC_LOG_INFO('Dropped all unnecessary backups');

end
&&