/* CALC.AUTO_PROC_EXECUTE_LATER_MULTIPLE
 *
 * Prozedur, welche mehrere SQL Befehle entgegen nimmt und als einzelne Befehle in den Ablaufplan TABLE_EXECUTION_PLAN
 * schreibt.
 *
 * @input arg_VERSION BIGINT,       Versionsnummer der AUTO_BUILD Ausführung
 * @input COMMANDS CLOB(204800),    SQL Befehle, welche zum Ablaufplan hinzugefügt werden sollen (; getrennt)
 * @input msgOffset VARCHAR(128)    String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                  Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu lesen
 *                                  ist.
 */

drop procedure CALC.AUTO_PROC_EXECUTE_LATER_MULTIPLE(BIGINT, CLOB(204800), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_LATER_MULTIPLE(arg_VERSION BIGINT, COMMANDS CLOB(204800),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare curQuery CLOB(204800);
    declare remainderQuery CLOB(204800);

    set remainderQuery = COMMANDS;

    while(LENGTH(remainderQuery) > 5) do
        set curQuery = SUBSTR(remainderQuery, 1, LOCATE(';',remainderQuery||';')-1);
        set remainderQuery = SUBSTR(remainderQuery, LOCATE(';',remainderQuery||';')+1);
        call CALC.AUTO_PROC_EXECUTE_LATER(arg_VERSION, curQuery,msgOffset);
    end while;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXECUTE_LATER_MULTIPLE is 'Prozedur zum Schreiben mehrerer SQL Befehle in den Ausführungsplan. (wird zur Zeit nicht genutzt)';
