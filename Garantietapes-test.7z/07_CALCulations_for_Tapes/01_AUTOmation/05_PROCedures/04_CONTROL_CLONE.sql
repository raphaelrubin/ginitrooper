/* CALC.AUTO_PROC_CONTROL_CLONE
 *
 * Diese Prozedur erstellt die Kontrolltabellen AUTO_TABLE_TARGETS und AUTO_TABLE_TARGET_TO_SOURCES sowie AUTO_TABLE_GROUPS
 *
 * @input: TAPE_toclone VARCHAR(8)              Name des existierenden Tapes, das geklont werden soll
 * @input: new_TAPE VARCHAR(8)                  Name des neuen Tapes
 * @input: msgOffset VARCHAR(128)               Offset für die Logs
 */

drop procedure CALC.AUTO_PROC_CONTROL_CLONE(varchar(8),VARCHAR(8),varchar(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CONTROL_CLONE (TAPE_toclone varchar(8),new_TAPE varchar(8), msgOffset varchar(128))
    LANGUAGE SQL
BEGIN

    declare curQuery CLOB(200k);
    declare curLongQuery CLOB(200k);
    DECLARE CURxMod1 INSENSITIVE Cursor
        for
            select distinct NAME from CALC.AUTO_TABLE_MODES with UR;


    -- Tabellen erstellen
    call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'creating control tables');
    --call CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(new_TAPE, 'AUTO_TABLE_TARGETS', TAPE_toclone, 'AUTO_TABLE_TARGETS', '      ');
    --call CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(new_TAPE, 'AUTO_TABLE_TARGET_TO_SOURCES', TAPE_toclone, 'AUTO_TABLE_TARGET_TO_SOURCES', '      ');
    call CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(new_TAPE, 'AUTO_TABLE_GROUPS', TAPE_toclone, 'AUTO_TABLE_GROUPS', '      ');
    -- Gruppen befüllen
    call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  filling group table');
    set curQuery = 'insert into '||new_TAPE||'.AUTO_TABLE_GROUPS (TABNAME, GROUPNAME, EXPORTNAME) select TABNAME, GROUPNAME, EXPORTNAME from '||TAPE_toclone||'.AUTO_TABLE_GROUPS except select TABNAME, GROUPNAME, EXPORTNAME from '||new_TAPE||'.AUTO_TABLE_GROUPS';
    EXECUTE IMMEDIATE curQuery;
    -- Constraints hinzufügen
    --call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  adding constraints');
    --set curQuery = 'alter table '||new_TAPE||'.AUTO_TABLE_TARGETS add CONSTRAINT TABLENAME PRIMARY KEY (TABSCHEMA,TABNAME)';
    --EXECUTE IMMEDIATE curQuery;
    --call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'      ');
    --set curQuery = 'alter table '||new_TAPE||'.AUTO_TABLE_TARGET_TO_SOURCES add CONSTRAINT TABLENAME_TARGET FOREIGN KEY (TABSCHEMA_TARGET,TABNAME_TARGET) REFERENCES '||new_TAPE||'.AUTO_TABLE_TARGETS(TABSCHEMA,TABNAME)';
    --EXECUTE IMMEDIATE curQuery;
    --set curQuery = 'alter table '||new_TAPE||'.AUTO_TABLE_TARGET_TO_SOURCES add CONSTRAINT TABLENAME_SOURCE FOREIGN KEY (TABSCHEMA_SOURCE,TABNAME_SOURCE) REFERENCES '||new_TAPE||'.AUTO_TABLE_TARGETS(TABSCHEMA,TABNAME)';
    --EXECUTE IMMEDIATE curQuery;
--     -- Create the new Group View...
--     call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  updating the group view');
--     set curLongQuery = 'create or replace view CALC.AUTO_VIEW_GROUPS as
--     with CLEANED_DATA as ( ';
--     for TAPE as CURxMod1 Cursor
--         for
--             select distinct NAME from CALC.AUTO_TABLE_TAPES with UR
--     do
--         set curLongQuery = curLongQuery||'select distinct '''||TAPE.NAME||''' as TAPENAME, GROUPNAME, CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME) as TABNAME from '||TAPE.NAME||'.AUTO_TABLE_GROUPS union all ';
--     end for;
--     set curLongQuery = SUBSTR(curLongQuery,1,LENGTH(curLongQuery)-10);
--     set curLongQuery = curLongQuery||' ), AGGREGATED_DATA as (
--         select distinct
--             TAPENAME,
--             GROUPNAME,
--             LISTAGG(TABNAME || '','') over (partition by TAPENAME,GROUPNAME order by TABNAME) as TABLES,
--             ROW_NUMBER() over (partition by TAPENAME,GROUPNAME order by TABNAME DESC) as ORDER_NUMBER
--         from CLEANED_DATA
--     )
--     select distinct TAPENAME,GROUPNAME,TRIM(B '','' FROM TABLES) as TABLES from AGGREGATED_DATA where ORDER_NUMBER = 1';
--     --call CALC.AUTO_PROC_LOG_DEBUG(curLongQuery);
--     EXECUTE IMMEDIATE curLongQuery;
    call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'finished creating control tables');
END
&&