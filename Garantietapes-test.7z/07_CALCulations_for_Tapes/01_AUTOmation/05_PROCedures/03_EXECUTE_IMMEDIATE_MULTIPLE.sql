/* CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE
 *
 * Prozedur, welche mehrere SQL Befehle entgegen nimmt und als einzelne Befehle nacheinander ausführt.
 *
 * @input COMMANDS CLOB(204800),    SQL Befehle, welche ausgeführt werden sollen (; getrennt)
 * @input msgOffset VARCHAR(128)    String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                  Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu lesen
 *                                  ist.
 */

drop procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(CLOB(204800), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(COMMANDS CLOB(204800),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare curQuery CLOB(204800);
    declare remainderQuery CLOB(204800);
    declare curQueryShort VARCHAR(450);

    set remainderQuery = COMMANDS; --trim(B ';' FROM COMMANDS);

    while(LENGTH(remainderQuery) > 5) do
        set curQuery = SUBSTR(remainderQuery, 1, LOCATE(';',remainderQuery||';')-1);
        set remainderQuery = SUBSTR(remainderQuery, LOCATE(';',remainderQuery||';')+1);

        call  CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,msgOffset);

    end while;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(CLOB(204800),VARCHAR(128)) is 'Prozedur zum Ausführen und Loggen mehrerer SQL Statements.';



drop procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(CLOB(204800));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(COMMANDS CLOB(204800))
LANGUAGE SQL
  begin
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(COMMANDS,NULL);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(CLOB(204800)) is 'Prozedur zum Ausführen mehrerer SQL Statements.';
