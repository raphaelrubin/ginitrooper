/* CALC.AUTO_PROC_EXPORT_GROUP
 * Procedure that exports a group of AMC Tapes to csv
 * @input: in_TABNAME VARCHAR(128)
 *          a) Tablename as defined in CALC.AUTO_TABLE_GROUPS (needs to be an AMC Table to be in there)
 *          b) Groupname as defined in CALC.AUTO_TABLE_GROUPS
 * @input: in_CUT_OFF_DATE VARCHAR(10)  Cut off date in the a valid date format (i.e. 30.09.2019)
 * @input: in_MIN_Version INT           Minimum Version number. This input can be used to skip version if required. If
 *                                      the version counter is already beyond in_MIN_Version, then the larger number is
 *                                      used.
 * @output: 7ZIP COMMAND                Linux command to execute on nlb-srv-db-02 to archive the exported files
 * @output: SEND                        Linux command to copy the created 7z file to the sftp server
 * @output: Getötete Alpaka             Number of alpaca killed due to the execution of this procedure.
 */

drop procedure CALC.AUTO_PROC_EXPORT_GROUP(varchar(8), VARCHAR(128),VARCHAR(10), INT, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_GROUP (TAPE varchar(8), GROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10), with_MIN_VERSION INT, FORCED BOOLEAN)
  DYNAMIC RESULT SETS 1
    LANGUAGE SQL
BEGIN
    declare cur_TABNAME VARCHAR(128);
    declare cur_EXPORTNAME VARCHAR(512);
    declare cur_GROUPNAME VARCHAR(128);
    declare cur_CODE VARCHAR(512);
    declare cur_VERSION BIGINT;
    declare cur_CUT_OFF_DATE DATE;
    declare cur_CUT_OFF_STRING VARCHAR(10);
    declare cur_CUT_OFF_STRING_DE VARCHAR(10);
    declare glob_zip_command VARCHAR(10000);
    declare glob_send_command VARCHAR(512);
    declare ERROR_MESSAGE VARCHAR(70);
    declare Getoetete_Alpaka INT;
    declare Gesammelte_Sterne INT;
    declare glob_Getoetete_Alpaka INT;
    declare glob_zip_filename VARCHAR(256);
    declare filename_addon VARCHAR(512);
    declare EXPORT_SERVER_STRING VARCHAR(32);


    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CLIENT
        for
         select glob_zip_command, '7ZIP COMMAND' from SYSIBM.SYSDUMMY1
            union all
         select glob_send_command, 'SEND COMMAND' from SYSIBM.SYSDUMMY1
            union all
         select cast(glob_Getoetete_Alpaka as VARCHAR(3)),'Getötete Alpaka' from SYSIBM.SYSDUMMY1
         ;
    -- Cursor erstellen, der den Vergleich der angeforderten Tabellen mit der Syscat übernimmt
    DECLARE CURx1T INSENSITIVE Cursor WITH HOLD
                for
                    select distinct ECG.TABNAME, ECG.EXPORTNAME, SCT.TABSCHEMA from CALC.SWITCH_AUTO_GROUPS AS ECG left join SYSCAT.TABLES AS SCT on SCT.TABNAME = ECG.TABNAME where (ECG.TABNAME = GROUP or ECG.GROUPNAME = GROUP) AND (SCT.TABSCHEMA = 'AMC' or SCT.TABSCHEMA is NULL) with UR;
    -- Cursor erstellen, welcher über die angeforderten Tabellen iteriert
    DECLARE CURx1 INSENSITIVE Cursor WITH HOLD
                for
                    select distinct TABNAME, EXPORTNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP with UR;
    -- Cursor erstellen, welcher die derzeitige Version herausfindet
    DECLARE Curx2 CURSOR WITH HOLD
                for
                        select MAX(VERSION) AS VERSION from CALC.AUTO_TABLE_EXPORT_VERSIONS where CUT_OFF_DATE = cur_CUT_OFF_DATE with UR;

    call CALC.AUTO_PROC_LOG_INFO('Starting execution of CALC.AUTO_PROC_EXPORT_GROUP for '||GROUP||'.');

    if EXISTS(select * from CALC.AUTO_TABLE_BUILD_VERSIONS where COMPLETED = FALSE) and not FORCED then
        --signal SQLSTATE '72723' set MESSAGE_TEXT = 'An instance of AUTO_PROC_BUILD is still executing or has not completed.';
        call CALC.AUTO_PROC_LOG_ERROR('An instance of AUTO_PROC_BUILD is still executing or has not completed.','72723');
    end if;

    SET cur_CUT_OFF_DATE = DATE(for_CUT_OFF_DATE);
    SET cur_CUT_OFF_STRING = rtrim(char(year(cur_CUT_OFF_DATE))) || substr( digits (month(cur_CUT_OFF_DATE)),9) || substr( digits (day(cur_CUT_OFF_DATE)),9); -- Stichtag im Format: yyyymmdd
    SET cur_CUT_OFF_STRING_DE = substr( digits (day(cur_CUT_OFF_DATE)),9) || '.' || substr( digits (month(cur_CUT_OFF_DATE)),9) || '.' || rtrim(char(year(cur_CUT_OFF_DATE))); -- Stichtag im Format: dd.mm.yyyy
    SET glob_zip_command = '';
    SET glob_Getoetete_Alpaka = 0;
    set EXPORT_SERVER_STRING = STG.FUNC_GET_EXPORT_SERVER_STRING();

    --call CALC.AUTO_PROC_CONTROL_PREPARE(TAPE);
    --COMMIT;

    call CALC.AUTO_PROC_LOG_DEBUG('  Checking if all required tables are in my database.');
    -- Überprüfe ob alle Tabellen existieren:
    for CAT as CURx1T Cursor WITH HOLD
        for
            select distinct ECG.TABNAME, ECG.EXPORTNAME, SCT.TABSCHEMA from CALC.SWITCH_AUTO_GROUPS AS ECG left join SYSCAT.TABLES AS SCT on SCT.TABNAME = ECG.TABNAME where (ECG.TABNAME = GROUP or ECG.GROUPNAME = GROUP) AND (SCT.TABSCHEMA = 'AMC' or SCT.TABSCHEMA is NULL) with UR
    do
        IF CAT.TABSCHEMA is NULL THEN
            SET ERROR_MESSAGE = TAPE||'.'||CAT.TABNAME||' doesn''t exist in SYSCAT. Nothing exported.';
            SIGNAL SQLSTATE '73513' SET MESSAGE_TEXT = ERROR_MESSAGE;
        end if;
    end for;
    -- ENDE Überprüfe ob alle Tabellen existieren

    -- Finde die neueste Version heraus:
    call CALC.AUTO_PROC_LOG_DEBUG('  Determine the current version.');
    SET cur_VERSION = 0;
    IF EXISTS (select * from CALC.AUTO_TABLE_EXPORT_VERSIONS where CUT_OFF_DATE = cur_CUT_OFF_DATE and TAPENAME = TAPE) THEN
        for CB as CURx2 Cursor
                for
                    select MAX(VERSION) AS VERSION from CALC.AUTO_TABLE_EXPORT_VERSIONS where CUT_OFF_DATE = cur_CUT_OFF_DATE and TAPENAME = TAPE with UR
        do

            SET cur_VERSION = CB.VERSION;

        end for;
        --CLOSE CURx2;
    END IF;
    SET cur_VERSION = MAX(cur_VERSION + 1,with_MIN_VERSION);
    call CALC.AUTO_PROC_LOG_DEBUG('  Executing with version '||cur_VERSION||'.');
    -- Neueste Version gefunden und um 1 inkrementiert


    set filename_addon = cur_CUT_OFF_STRING || '_V' || LPAD(cur_VERSION,2,'0') || coalesce(nullif('_' || EXPORT_SERVER_STRING,'_'),'');
    -- Finde alle relevanten Tabellen
    for CA as CURx1 Cursor WITH HOLD
                for
                    select distinct TABNAME, EXPORTNAME from CALC.SWITCH_AUTO_GROUPS where TABNAME = GROUP or GROUPNAME = GROUP
    do
        SET cur_TABNAME = CA.TABNAME;
        SET cur_GROUPNAME = GROUP;
        SET cur_EXPORTNAME = CA.EXPORTNAME;
        call CALC.AUTO_PROC_LOG_INFO('  Exporting '||TAPE||'.'||cur_TABNAME);
        -- Exportiere die Datei
        if EXISTS(select * from SYSCAT.COLUMNS where TABSCHEMA = TAPE and TABNAME = cur_TABNAME and COLNAME = 'CUT_OFF_DATE')  then
            SET cur_CODE = 'select * from '||TAPE||'.'||cur_TABNAME||' where CUT_OFF_DATE = '''||cur_CUT_OFF_STRING_DE||'''';
        else
            SET cur_CODE = 'select * from '||TAPE||'.'||cur_TABNAME;
        end if;
        --   order by clause als Zwischenlösung für Cash Flows
        if cur_TABNAME like '%CASH_FLOW%' then
            SET cur_CODE = cur_CODE || ' order by FACILITY_ID';
        end if;
        SET cur_EXPORTNAME = TAPE||'_'||cur_EXPORTNAME || '_' ||filename_addon;
        call CALC.AUTO_PROC_LOG_DEBUG('  About to export '||cur_CODE||' into '||cur_EXPORTNAME);
        call STG.PROC_EXPORT_SQL_AUTOMATION(cur_CODE,cur_EXPORTNAME);
        -- Berechne Alpaka und Sterne
        SET Getoetete_Alpaka = 0;
        IF (SESSION_USER = 'DB117265' OR SESSION_USER = 'DB124780' OR SESSION_USER <> 'DB124560') THEN SET Getoetete_Alpaka = ROUND(0.55*RAND()); END IF;
        SET glob_Getoetete_Alpaka = glob_Getoetete_Alpaka + Getoetete_Alpaka;
        SET Gesammelte_Sterne = (10+ROUND(10*RAND()));
        -- Speichere den Erfolgreichen Export
        SET cur_CODE = 'insert into CALC.AUTO_TABLE_EXPORT_VERSIONS (TAPENAME, TABNAME, GROUPNAME, CUT_OFF_DATE, VERSION, EXPORTNAME_FULL, EXPORT_QUERY,GETOETETE_ALPAKA,STERNE) VALUES ('''||TAPE||''','''||cur_TABNAME||''','''||cur_GROUPNAME||''','''||cur_CUT_OFF_DATE||''','||cur_VERSION||','''||cur_EXPORTNAME||''','''||REPLACE(cur_CODE,'''','''''')||''','||Getoetete_Alpaka||','||Gesammelte_Sterne||')';
        call CALC.AUTO_PROC_LOG_DEBUG('About to execute: "'||TRIM(cast(LEFT(cur_CODE,450) as VARCHAR(450)))||'"');
        EXECUTE IMMEDIATE cur_CODE;
        -- Alpaka- und Sterne-Änderung speichern
        insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (-1*Getoetete_Alpaka,Gesammelte_Sterne);
        -- gerade exportierte Datei zu ZIP-Befehl hinzufügen
        --SET glob_zip_command = glob_zip_command || ' /data/work/dbblossom/export/*_' || cur_EXPORTNAME || '.csv';
        SET glob_zip_command = glob_zip_command || ' *_' || cur_EXPORTNAME || '.csv';
        call CALC.AUTO_PROC_LOG_INFO('  Completed export of '||cur_TABNAME||'.');
    end for;
    --CLOSE CURx1T;
    --CLOSE CURx1;
    -- ZIP und send Befehl für den Output zusammenbauen
    SET glob_zip_filename = TAPE||'_'||GROUP||'_'||filename_addon||'.7z';
    --SET glob_zip_command = '7z a -p /data/work/n2'||SUBSTRING(SESSION_USER ,3,6)||'/'||glob_zip_filename|| glob_zip_command;
    set glob_zip_command = STG.FUNC_GET_7Z_ZIP_CODE(glob_zip_filename,glob_zip_command, TRUE);
    SET glob_send_command = STG.FUNC_GET_SEND_CODE(glob_zip_filename);
    update CALC.AUTO_TABLE_EXPORT_VERSIONS set (COMPLETED,SUCCESS) = (TRUE,TRUE) where VERSION = cur_VERSION;
    COMMIT;
    call CALC.AUTO_PROC_LOG_INFO('  Zip Code:'||LEFT(glob_zip_command,500));
    call CALC.AUTO_PROC_LOG_INFO('  Send Code:'||glob_send_command);
    call CALC.AUTO_PROC_LOG_INFO('Finished exporting '||GROUP);
    OPEN curOUT;
    --RETURN;
    --CLOSE curOUT;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_GROUP(varchar(8), VARCHAR(128),VARCHAR(10), INT, BOOLEAN) is 'Prozedur zum Exportieren einer Gruppe an Tapes. Dies ist die detailierte Version, welche von anderen Prozeduren aufgerufen wird.';



-- Overload procedure, assuming the next Version
drop procedure CALC.AUTO_PROC_EXPORT_GROUP(varchar(8),VARCHAR(128),VARCHAR(10));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_GROUP (in_TAPE varchar(8), in_TABNAME VARCHAR(128),in_CUT_OFF_DATE VARCHAR(10))
  DYNAMIC RESULT SETS 1
    LANGUAGE SQL
BEGIN
    call CALC.AUTO_PROC_EXPORT_GROUP (in_TAPE, in_TABNAME,in_CUT_OFF_DATE,1,FALSE);
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_GROUP(varchar(8),VARCHAR(128),VARCHAR(10)) is 'Prozedur zum Exportieren einer Gruppe an Tapes.';



drop procedure CALC.AUTO_PROC_EXPORT_GROUP_FORCED( varchar(8),VARCHAR(128),VARCHAR(10));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_GROUP_FORCED(in_Tape varchar(8),in_TABNAME VARCHAR(128),in_CUT_OFF_DATE VARCHAR(10))
  DYNAMIC RESULT SETS 1
    LANGUAGE SQL
BEGIN
    call CALC.AUTO_PROC_EXPORT_GROUP (in_Tape, in_TABNAME,in_CUT_OFF_DATE,1,TRUE);
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_GROUP_FORCED(varchar(8),VARCHAR(128),VARCHAR(10)) is 'Prozedur zum Exportieren einer Gruppe an Tapes selbst wenn gerade eine Bau-Prozedur läuft.';



-- Overload procedure, assuming the last cut off date and the next Version
drop procedure CALC.AUTO_PROC_EXPORT_GROUP(VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXPORT_GROUP (in_TABNAME VARCHAR(128))
  DYNAMIC RESULT SETS 1
    LANGUAGE SQL
BEGIN
    DECLARE in_CUT_OFF_DATE VARCHAR(10);
    DECLARE in_TAPE VARCHAR(10);
    --SET in_CUT_OFF_DATE = MAP.GETPREVIOUSQUARTERCOD(CURRENT_DATE );
    SET in_CUT_OFF_DATE = (select VERSIONS.CUT_OFF_DATE from CALC.AUTO_TABLE_BUILD_VERSIONS as VERSIONS inner join CALC.AUTO_TABLE_TAPES as TAPES on VERSIONS.TAPENAME = TAPES.NAME where VERSIONS.GROUPNAME <> 'ARCHIVES' and VERSIONS.COMPLETED and VERSIONS.SUCCESS and TAPES.IS_ACTIVE order by VERSIONS.CREATED_AT DESC limit 1 with UR);
    SET in_TAPE = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1 with UR);
    call CALC.AUTO_PROC_EXPORT_GROUP (in_TAPE,in_TABNAME,in_CUT_OFF_DATE,1,FALSE);
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXPORT_GROUP(VARCHAR(128)) is 'Prozedur zum Exportieren einer Gruppe an Tapes für den aktuellen Stichtag.';
