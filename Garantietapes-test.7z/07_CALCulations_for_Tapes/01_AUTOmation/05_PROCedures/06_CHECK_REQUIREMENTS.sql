/* CALC.AUTO_PROC_CHECK_REQUIREMENTS (desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10),Stage INT, useArchive BOOLEAN,VERSION BIGINT)
 *
 * Diese Prozedur wird von CALC.AUTO_PROC_BUILD_TABLE aufgerufen und sollte nicht manuell aufgerufen werden.
 * Die Prozedur schaut, ob alle Ursprungstabellen einer Tabelle aktuell sind und wenn nicht, ruft die "Bau-Prozedur" auf, um sie zu aktualisieren.
 *
 * @input: desired_TABSCHEMA VARCHAR(8)     Schema der neu zu bauenden Tabelle
 * @input: desired_TABNAME VARCHAR(128)     Name der neu zu bauenden Tabelle
 * @input: desired_CUT_OFF_DATE VARCHAR(10) Cut off Date
 * @input: Stage INT                        Stufe der Gründlichkeit (Siehe Stages in TARGET_TO_SOURCES)
 * @input: useArchive BOOLEAN               Dürfen Archive benutzt werden obwohl die Tabelle neu gebaut werden kann?
 * @input: in_VERSION BIGINT                Version der Ausführung (wird benutzt um die Testergebnisse unterschiedlicher Läufe auseinander zu halten)
 * @input: RecursionLevel INT               Level der Rekursion (nur für Debug Zwecke relevant)
 */

drop procedure CALC.AUTO_PROC_CHECK_REQUIREMENTS(VARCHAR(8),VARCHAR(8), VARCHAR(128),VARCHAR(10), INT,BOOLEAN,BOOLEAN,BIGINT, INT);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CHECK_REQUIREMENTS(TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8), desired_TABNAME VARCHAR(128), desired_CUT_OFF_DATE VARCHAR(10), Stage INT, useArchive BOOLEAN, rebuildAll BOOLEAN, in_VERSION BIGINT, RecursionLevel INT)
    LANGUAGE SQL
begin
    -- START DEKLARATIONEN
    declare ERROR_MESSAGE VARCHAR(128);
    declare hasPassed BOOLEAN;
    declare msgOffset VARCHAR(128);
    declare maxStage BIGINT;
    declare BWStage BIGINT;
    declare local_desired_CUT_OFF_DATE date;
    declare CURx1T INSENSITIVE Cursor WITH HOLD
        for
        select TABLENAME,
               TABSCHEMA,
               TABNAME,
               CUT_OFF_DATE_COLNAME,
               IS_REQUIRED_AT_ALL,
               STAGE_REQUIRED_AT,
               case
                   when STAGE_REQUIRED_AT <= Stage then
                       TRUE
                   else
                       FALSE
                   end                                   as IS_REQUIRED_AT_STAGE
        from CALC.AUTO_VIEW_TARGET_TO_SOURCES
        where TABSCHEMA_TARGET = desired_TABSCHEMA
          and TABNAME_TARGET = desired_TABNAME
          and (VALID_FROM is NULL or VALID_FROM <= desired_CUT_OFF_DATE)
          and (VALID_UNTIL is NULL or VALID_UNTIL >= desired_CUT_OFF_DATE)
        with UR;
    -- ENDE DEKLARATIONEN

    -- Initialisiere Variablen
    set msgOffset = repeat(' ',2 * RecursionLevel);
    set maxStage = (select MAX(Stage) from CALC.AUTO_TABLE_MODES);
    set BWStage = (select INT(AVG(STAGE_REQUIRED_AT)+0.5) from CALC.AUTO_VIEW_TARGET_TO_SOURCES where TABNAME like '%BW%');

    -- START Überprüfe ob alle Tabellen auf neuestem Stand sind
    call CALC.AUTO_PROC_LOG_DEBUG(msgOffset || 'Check prerequisites of '||desired_TABSCHEMA||'.'||desired_TABNAME||' before rebuilding it.');
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select TABLENAME, TABSCHEMA, TABNAME, CUT_OFF_DATE_COLNAME, IS_REQUIRED_AT_ALL, STAGE_REQUIRED_AT, case when STAGE_REQUIRED_AT <= '||Stage||' then TRUE else FALSE end as IS_REQUIRED_AT_STAGE from CALC.AUTO_VIEW_TARGET_TO_SOURCES where TABSCHEMA_TARGET = '''||desired_TABSCHEMA||''' and TABNAME_TARGET = '''||desired_TABNAME||''' and (VALID_FROM is NULL or VALID_FROM <= '''||desired_CUT_OFF_DATE||''') and (VALID_UNTIL is NULL or VALID_UNTIL >= '''||desired_CUT_OFF_DATE||''') with UR;');
    for BASETABLE as CURx1T Cursor WITH HOLD
        for
        select TABLENAME,
               TABSCHEMA,
               TABNAME,
               CUT_OFF_DATE_COLNAME,
               IS_REQUIRED_AT_ALL,
               STAGE_REQUIRED_AT,
               case
                   when STAGE_REQUIRED_AT <= Stage then
                       TRUE
                   else
                       FALSE
                   end                                   as IS_REQUIRED_AT_STAGE
        from CALC.AUTO_VIEW_TARGET_TO_SOURCES
        where TABSCHEMA_TARGET = desired_TABSCHEMA
          and TABNAME_TARGET = desired_TABNAME
          and (VALID_FROM is NULL or VALID_FROM <= desired_CUT_OFF_DATE)
          and (VALID_UNTIL is NULL or VALID_UNTIL >= desired_CUT_OFF_DATE)
        with UR
        do
            -- Log schreiben
            call CALC.AUTO_PROC_LOG_DEBUG(msgOffset || '  Checking "' || BASETABLE.TABLENAME || '".');
            -- Für BW Fall das CoD anpassen:
            if (BASETABLE.STAGE_REQUIRED_AT = BWStage and DATE(desired_CUT_OFF_DATE) < DATE('30.09.2019')) then -- Anmerkung LW: nicht mehr notwendig ab September 19 dank neuer monatlicher BW Daten
                set local_desired_CUT_OFF_DATE = CALC.AUTO_FUNC_GET_BW_DESIRED_CUT_OFF_DATE(desired_CUT_OFF_DATE);
            else
                set local_desired_CUT_OFF_DATE = desired_CUT_OFF_DATE;
            end if;
            -- Fall auswählen
            if (Stage = maxStage or BASETABLE.IS_REQUIRED_AT_STAGE) and BASETABLE.IS_REQUIRED_AT_ALL then
                -- Für Stage 0-5 sollen alle getestet/neu gebaut werden, die nicht aktuell sind und für diese Stage benötigt werden.
                -- Für Stage 6 sollen alle getestet/neu gebaut werden, die neu gebaut werden können
                if rebuildAll then -- and
                    -- Tabelle neu bauen, auch wenn sie schon aktuell sind solange sie in diesem Durchlauf noch nicht neu gebaut wurde.
                    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = '||in_VERSION||' and TABSCHEMA = '''||BASETABLE.TABSCHEMA||''' and TABNAME = '''||BASETABLE.TABNAME||''';');
                    if EXISTS(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = in_VERSION and TABSCHEMA = BASETABLE.TABSCHEMA and TABNAME = BASETABLE.TABNAME) then
                        set hasPassed = TRUE;
                    else
                        set hasPassed = FALSE;
                        if BASETABLE.TABSCHEMA not in ('AMC',TAPENAME) then -- ROhtabellen immer neu zubauen ist Blödsinn. Wir bauen sie also nur neu, wenn sie noch nicht vorher gebaut wurden und ein veralteten Stichtag haben
                            call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(BASETABLE.TABSCHEMA, BASETABLE.TABNAME,BASETABLE.CUT_OFF_DATE_COLNAME, in_VERSION,local_desired_CUT_OFF_DATE, FALSE, hasPassed);
                            set hasPassed = CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(BASETABLE.TABSCHEMA, BASETABLE.TABNAME,in_VERSION);
                        end if;
                    end if;
                else
                    -- Tabelle nur neu bauen, wenn sie noch nicht den gewünschten Stichtag enthält und in diesem Durchlauf noch nicht neu gebaut wurde.
                    if EXISTS(select * from CALC.AUTO_TABLE_CHECK_BUILD where VERSION = in_VERSION and TABSCHEMA = BASETABLE.TABSCHEMA and TABNAME = BASETABLE.TABNAME) then
                        set hasPassed = TRUE;
                    else
                        call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(BASETABLE.TABSCHEMA, BASETABLE.TABNAME,BASETABLE.CUT_OFF_DATE_COLNAME, in_VERSION,local_desired_CUT_OFF_DATE, FALSE, hasPassed);
                        --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||in_VERSION||' and TABSCHEMA = '''||BASETABLE.TABSCHEMA||''' and TABNAME = '''||BASETABLE.TABNAME||''';');
                        --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select first_value(PASSED) over (partition by VERSION, TABSCHEMA, TABNAME order by CREATED_AT DESC) as PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||in_VERSION||' and TABSCHEMA = '''||BASETABLE.TABSCHEMA||''' and TABNAME = '''||BASETABLE.TABNAME||''' limit 1 with UR;');
                        set hasPassed = CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(BASETABLE.TABSCHEMA, BASETABLE.TABNAME,in_VERSION);
                    end if;
                end if;
                if not hasPassed then
                    SET ERROR_MESSAGE = msgOffset || '  ' || BASETABLE.TABSCHEMA || '.' || BASETABLE.TABNAME || ' needs to be rebuild for ' || local_desired_CUT_OFF_DATE;
                    call CALC.AUTO_PROC_LOG_INFO(ERROR_MESSAGE);
                    -- Baue Tabelle neu
                    call CALC.AUTO_PROC_BUILD_TABLE(TAPENAME, BASETABLE.TABSCHEMA, BASETABLE.TABNAME, local_desired_CUT_OFF_DATE, Stage,useArchive,rebuildAll, in_VERSION, RecursionLevel + 1);
                    -- Schaue nach, ob der Neubau erfolgreich war
                    call CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(BASETABLE.TABSCHEMA, BASETABLE.TABNAME,BASETABLE.CUT_OFF_DATE_COLNAME, in_VERSION,local_desired_CUT_OFF_DATE, TRUE, hasPassed);
                    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||in_VERSION||' and TABSCHEMA = '''||BASETABLE.TABSCHEMA||''' and TABNAME = '''||BASETABLE.TABNAME||''';');
                    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'select first_value(PASSED) over (partition by VERSION, TABSCHEMA, TABNAME order by CREATED_AT DESC) as PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||in_VERSION||' and TABSCHEMA = '''||BASETABLE.TABSCHEMA||''' and TABNAME = '''||BASETABLE.TABNAME||''' limit 1 with UR;');
                    set hasPassed = CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(BASETABLE.TABSCHEMA,BASETABLE.TABNAME, in_VERSION);
                    if not hasPassed then
                    --    insert into CALC.AUTO_TABLE_CHECK_BUILD (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION) values (BASETABLE.TABSCHEMA, BASETABLE.TABNAME,local_desired_CUT_OFF_DATE,in_VERSION); -- Log that build was completed
                    --else
                        if BASETABLE.CUT_OFF_DATE_COLNAME is not NULL then
                            SET ERROR_MESSAGE = msgOffset || '  ' || BASETABLE.TABSCHEMA || '.' || BASETABLE.TABNAME || ' failed to rebuild for ' || local_desired_CUT_OFF_DATE;
                        else
                            SET ERROR_MESSAGE = msgOffset || '  ' || BASETABLE.TABSCHEMA || '.' || BASETABLE.TABNAME || ' failed to rebuild';
                        end if;
                        if Stage = maxStage then
                            -- Für Stage 6 soll kein Fehler geworfen werden
                            if BASETABLE.IS_REQUIRED_AT_ALL then
                                call CALC.AUTO_PROC_LOG_WARNING(ERROR_MESSAGE);
                            else
                                call CALC.AUTO_PROC_LOG_INFO(ERROR_MESSAGE);
                            end if;
                        else
                            -- Für Stage 0-5 soll ein Fehler geworfen werden wenn die wichtige Tabelle nicht erneuert werden konnte
                            call CALC.AUTO_PROC_LOG_ERROR(ERROR_MESSAGE);
                        end if;
                    end if;
                else
                    if rebuildAll and BASETABLE.TABSCHEMA in ('AMC',TAPENAME) then
                        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset || '  Table has already been build.');
                    else
                        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset || '  Table already contains the desired cut off date.');
                    end if;
                end if;
            else
                call CALC.AUTO_PROC_LOG_DEBUG(msgOffset || '  Table is not required for this run.');
            end if;
            -- Switch muss umgestellt werden, falls es sich um eine Tape Tabelle handelt
            if BASETABLE.TABSCHEMA in ('AMC',TAPENAME) then
                call CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME,BASETABLE.TABNAME,msgOffset);
            end if;
            COMMIT;
        end for;
    -- ENDE Überprüfe ob alle Tabellen auf neuestem Stand sind

    -- Aufräumen
    insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (in_VERSION,'delete from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = '||in_VERSION||';');
    delete from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = in_VERSION;
    --close CURx1T;
    -- End Procedure
    COMMIT;
end
&&




-- truncate table CALC.AUTO_TABLE_LOG immediate;
-- call CALC.AUTO_PROC_CHECK_REQUIREMENTS ('AMC','TABLE_BW_STAMMDATEN_CURRENT','31.12.2019',0, FALSE, 2);
-- select * from CALC.AUTO_TABLE_LOG;
--
--
--
-- -- TESTS
--
--
-- select 'select * from ' || TABSCHEMA_SOURCE || '.' || TABNAME_SOURCE || ' where CUT_OFF_DATE = ' || '''31.12.2019''' AS TABLENAME, case when TRUE then REQUIRED_FOR_FINAL else REQUIRED end as REQUIRED from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABSCHEMA_TARGET = 'AMC' and TABNAME_TARGET = 'TABLE_PORTFOLIO_CURRENT';
--
-- select TABSCHEMA_SOURCE || '.' || TABNAME_SOURCE as TABLENAME, 'select ''passed'' into cur_TEST from ' || TABSCHEMA_SOURCE || '.' || TABNAME_SOURCE || ' where ' || CUT_OFF_DATE_SOURCE || ' = ''' || '31.12.2019' || ''' group by ' || CUT_OFF_DATE_SOURCE || ' ' AS QUERY, case when TRUE  then REQUIRED_FOR_FINAL else REQUIRED end as REQUIRED from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABSCHEMA_TARGET = 'AMC' and TABNAME_TARGET = 'TABLE_PORTFOLIO_CURRENT';
--
--
-- select * from CALC.VIEW_SURROGATE; where CUT_OFF_DATE = '31.12.2019' group by CUT_OFF_DATE;
--
-- insert into CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,COLNAME,CUT_OFF_DATE,ERROR_MESSAGE)
-- select distinct 'AMC' as TABSCHEMA, 'TAPE_SHIP_COLLATERALS_FINISH' as TABNAME, 'CUT_OFF_DATE' as COLNAME, '30.09.2019' as CUT_OFF_DATE, 'CALC.TAPE_SHIP_COLLATERALS_FINISH.CUT_OFF_DATE enthällt nicht den 30.09.2019' as ERROR_MESSAGE
-- from (select COUNT(*) AS COUNT from CALC.TAPE_SHIP_COLLATERALS_FINISH where CUT_OFF_DATE = '30.09.2019') where COUNT <= 0;
--
-- truncate table CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE immediate;
-- select * from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE;




--select distinct 'AMC' as TABSCHEMA, 'TAPE_SHIP_COLLATERALS_FINISH' as TABNAME, 'CUT_OFF_DATE' as COLNAME, '30.09.2019' as CUT_OFF_DATE, 'CALC.TAPE_SHIP_COLLATERALS_FINISH.CUT_OFF_DATE enthällt nicht den 30.09.2019' as ERROR_MESSAGE, NULL as CUT_OFF_DATE
--from (select COUNT(*) AS COUNT from CALC.TAPE_SHIP_COLLATERALS_FINISH where CUT_OFF_DATE = '30.09.2019') where COUNT <= 0
