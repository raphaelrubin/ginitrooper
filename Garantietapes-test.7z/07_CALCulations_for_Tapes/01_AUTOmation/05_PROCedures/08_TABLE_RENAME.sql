-- TODO: unfertig! Idee ist, dass man Tabellennamen schneller anpassen kann (siehe notwendige Schritte in der Wiki)
drop procedure CALC.AUTO_PROC_TABLE_RENAME(VARCHAR(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_TABLE_RENAME (TABNAME_old VARCHAR(128),TABNAME_new VARCHAR(128))
    LANGUAGE SQL
BEGIN
    -- START DEKLARATIONEN
    DECLARE curTABNAME_old VARCHAR(128);
    DECLARE curTABNAME_new VARCHAR(128);
    DECLARE curQuery CLOB(200k);
    DECLARE CURxRT1 INSENSITIVE Cursor
        for
            select distinct TRIM(B ' ' FROM TABSCHEMA) AS SCHEMA, TABNAME AS NAME, TRIM(B ' ' FROM TABSCHEMA)||'.'||TABNAME AS FULLNAME from SYSCAT.TABLES where TABNAME = TABNAME_old or TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(LEFT(TABSCHEMA,8),TABNAME_old) with UR;

    -- Check if the Tablename is valid:



    call CALC.AUTO_PROC_LOG_INFO('Starting to alter table name '||TABNAME_old||' to '||TABNAME_new||'.');
    -- Get all the Current and Archive tables
    for TABLE as CURxRT1 Cursor
        for
            select distinct TRIM(B ' ' FROM TABSCHEMA) AS SCHEMA, TABNAME AS NAME, TRIM(B ' ' FROM TABSCHEMA)||'.'||TABNAME AS FULLNAME from SYSCAT.TABLES where TABNAME = TABNAME_old or TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(LEFT(TABSCHEMA,8),TABNAME_old) with UR
    do
        set curTABNAME_old = TABLE.NAME;
        if TABLE.NAME = TABNAME_old then
            set curTABNAME_new = TABNAME_new;
        else
            set curTABNAME_new = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(TABLE.SCHEMA,TABNAME_new);
        end if;
        call CALC.AUTO_PROC_LOG_INFO('  About to change '||TABLE.FULLNAME|| ' to '||TABLE.SCHEMA||'.'||curTABNAME_new||'.');

        -- Issue a rename on the table
        set curQuery = 'RENAME TABLE '||TABLE.FULLNAME||' TO '||TABLE.SCHEMA||'.'||curTABNAME_new;
        call CALC.AUTO_PROC_LOG_DEBUG(curQuery);

        -- alter the name in the Command Tables and adjust the BUILD code and RECREATE code
        set curQuery = 'INSERT INTO TABLE CALC.AUTO_TABLE_TARGETS (TABSCHEMA, TABNAME, COLNAME_CUT_OFF_DATE, TYPE, IS_AUTOMATEABLE, DO_TRUNCATE_BEFORE_BUILD, BUILDCODE, RECREATECODE, CREATED_AT, CREATED_BY) ' ||
                       'select TABSCHEMA, '''||curTABNAME_new||''' as TABNAME, COLNAME_CUT_OFF_DATE, TYPE, IS_AUTOMATEABLE, DO_TRUNCATE_BEFORE_BUILD, ' ||
                       'REPLACE(BUILDCODE,'''||CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME_old)||''','''||CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME_new)||''') as BUILDCODE, ' ||
                       'REPLACE(RECREATECODE,'''||CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME_old)||''','''||CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME_new)||''') as RECREATECODE, ' ||
                       'CREATED_AT, CREATED_BY from CALC.AUTO_TABLE_TARGETS ' ||
                       'where TABSCHEMA = '''||TABLE.SCHEMA||''' and TABNAME = '''||curTABNAME_old||''' limit 1';
        call CALC.AUTO_PROC_LOG_DEBUG(curQuery);

        set curQuery = 'UPDATE CALC.AUTO_TABLE_TARGET_TO_SOURCES SET TABNAME_TARGET = '''||TABNAME_new||''' WHERE TABNAME_TARGET = '''||TABNAME_old||''' AND TABSCHEMA_TARGET = '''||TABLE.SCHEMA||'''';
        call CALC.AUTO_PROC_LOG_DEBUG(curQuery);

        set curQuery = 'UPDATE CALC.AUTO_TABLE_TARGET_TO_SOURCES SET TABNAME_SOURCE = '''||TABNAME_new||''' WHERE TABNAME_SOURCE = '''||TABNAME_old||''' AND TABSCHEMA_TARGET = '''||TABLE.SCHEMA||'''';
        call CALC.AUTO_PROC_LOG_DEBUG(curQuery);

        set curQuery = 'DELETE FROM CALC.AUTO_TABLE_TARGETS WHERE TABNAME = '''||TABNAME_old||''' AND TABSCHEMA = '''||TABLE.SCHEMA||'''';
        call CALC.AUTO_PROC_LOG_DEBUG(curQuery);


    end for;

    call CALC.AUTO_PROC_LOG_INFO('Finished to alter table name '||TABNAME_old||' to '||TABNAME_new||'.');

END
&&