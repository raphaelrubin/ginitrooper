/* CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS
 *
 * Diese Prozedur erstellt eine Tabelle, falls sie nicht schon existiert.
 *
 * @input: create_TABSCHEMA VARCHAR(8)          Name des Schema, der zu erstellenden Tabelle
 * @input: create_TABNAME VARCHAR(128)          Name der zu erstellenden Tabelle
 * @input: like_TABSCHEMA VARCHAR(8)            Name des Schema, der Tabelle auf welcher die neue Tabelle basiert
 * @input: like_TABNAME VARCHAR(128)            Name der Tabelle auf welcher die neue Tabelle basiert
 * @input: msgOffset VARCHAR(128)               Offset für die Logs
 */

drop procedure CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(varchar(8), varchar(128),varchar(8),VARCHAR(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(create_TABSCHEMA varchar(8), create_TABNAME varchar(128),like_TABSCHEMA varchar(8), like_TABNAME varchar(128),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare CREATE_STATEMENT CLOB(200K);
    declare COD_COLNAME VARCHAR(128);
    -- Überprüfen, ob die tabelle schon in der SYSCAT steht
    if not EXISTS(select * from SYSCAT.TABLES where TABSCHEMA = create_TABSCHEMA and TABNAME = create_TABNAME) then
        -- Tabelle ist neu - erstelle die Query zum Tabellen erstellen.
        set CREATE_STATEMENT = 'create table '||create_TABSCHEMA||'.'||create_TABNAME||' like '||like_TABSCHEMA||'.'||like_TABNAME||'';
        set CREATE_STATEMENT = CREATE_STATEMENT||' including identity including defaults';
        -- Wenn es keine Current Tabelle ist
        if not create_TABNAME like '%_CURRENT' then
            -- Diese Prozedur wird nur beim Klonen ausgeführt - die zu klonende Tabelle wird mit gleichen Namen nur anderem Schema also schon in der TARGETS Tabelle stehen
            set COD_COLNAME = (select COLNAME_CUT_OFF_DATE from CALC.AUTO_VIEW_TARGETS where TABNAME = create_TABNAME limit 1);
            -- Aber es eine Stichtagsspalte gibt
            if COD_COLNAME is not NULL then
                -- Dann handelt es sich um eine Archiv und der Stichtag sollte über Partitionen verteilt werden
                set CREATE_STATEMENT = CREATE_STATEMENT||' partition by RANGE ('||COD_COLNAME||') (starting ''1.1.2015'' ending ''31.12.2030'' EVERY 1 Month) in SPACE_'||create_TABSCHEMA||'_A,SPACE_'||create_TABSCHEMA||'_B,SPACE_'||create_TABSCHEMA||'_C,SPACE_'||create_TABSCHEMA||'_D,SPACE_'||create_TABSCHEMA||'_E,SPACE_'||create_TABSCHEMA||'_F';
            end if;
        end if;
        -- Erstellen der Tabelle ausführen.
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CREATE_STATEMENT,msgOffset);
    end if;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_CREATE_IF_NOT_EXISTS(varchar(8), varchar(128),varchar(8),VARCHAR(128),VARCHAR(128)) is 'Prozedur um eine Tabelle zu erstellen.';
