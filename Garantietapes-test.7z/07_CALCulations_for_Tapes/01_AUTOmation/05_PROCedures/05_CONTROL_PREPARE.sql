/* CALC.AUTO_PROC_CONTROL_PREPARE
 *
 * Diese Prozedur erstellt die Switches für die Kontrolltabellen neu, sodass sie auf das gewünschte Tape zeigen.
 *
 * @input: TAPENAME VARCHAR(8)                  Name des Tapes, auf das umgeschaltet werden soll
 */

drop procedure CALC.AUTO_PROC_CONTROL_PREPARE(VARCHAR(8));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CONTROL_PREPARE (TAPENAME varchar(8))
    LANGUAGE SQL
BEGIN
    --call CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME,'AUTO_TABLE_TARGETS','');
    --call CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME,'AUTO_TABLE_TARGET_TO_SOURCES','');
    call CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME,'AUTO_TABLE_GROUPS','');
    call CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME,'TABLE_VALIDATION_RESULTS_CURRENT','');
end
&&

--call CALC.AUTO_PROC_CONTROL_PREPARE ('AMC');