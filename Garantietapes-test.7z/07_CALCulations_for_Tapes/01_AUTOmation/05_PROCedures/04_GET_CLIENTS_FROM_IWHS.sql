/* CALC.AUTO_PROC_GET_CLIENTS_FROM_IWHS
 * Befüllt die BGA Kundenliste aus dem IWHS basierend auf einer Liste von OE Nummern oder NACE Codes.
 *
 * @input: desired_CUTOFFDATE DATE          Gewünschtes CUT_OFF_DATE für das IWHS
 * @input: NACE_OR_OE VARCHAR(16)           NACE, OE-Service, OE-Berater, ALL, PRIVATE oder COMPANIES
 * @input: CODE_LIST VARCHAR(512)           Liste der NACE oder OEs die in Betracht gezogen werden sollen
 * @input: INCLUDE_PRIVATE BOOLEAN          Privatkunden mit einbeziehen?
 * @input: INCLUDE_KFW BOOLEAN              KFW mit einbeziehen?
 * @input: msgOffset VARCHAR(128)           Leerzeichen, um Log-nachrichten einzurücken
 */

drop procedure CALC.AUTO_PROC_GET_CLIENTS_FROM_IWHS (DATE, VARCHAR(16), VARCHAR(512), BOOLEAN, BOOLEAN, VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_GET_CLIENTS_FROM_IWHS (desired_CUTOFFDATE DATE, NACE_OR_OE VARCHAR(16), CODE_LIST VARCHAR(512),INCLUDE_PRIVATE BOOLEAN, INCLUDE_KFW BOOLEAN, msgOffset VARCHAR(128))
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    declare current_CUTOFFDATE DATE;

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Start retrieving clients.');

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Updating IWHS_KUNDE_CURRENT');
    set current_CUTOFFDATE = (select CUTOFFDATE from NLB.IWHS_KUNDE_CURRENT limit 1);
    if not coalesce(current_CUTOFFDATE,'01.01.1900') = desired_CUTOFFDATE then
        call CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE('BGA','NLB','IWHS_KUNDE_CURRENT',desired_CUTOFFDATE,msgOffset||'    ',TRUE);
    end if;

    set current_CUTOFFDATE = (select CUTOFFDATE from BLB.IWHS_KUNDE_CURRENT limit 1);
    if not coalesce(current_CUTOFFDATE,'01.01.1900') = desired_CUTOFFDATE then
        call CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE('BGA','BLB','IWHS_KUNDE_CURRENT',desired_CUTOFFDATE,msgOffset||'    ',TRUE);
    end if;

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Clearing BGA_MANUAL_LISTS');
    delete from STG.BGA_MANUAL_LISTS where 1=1;

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Getting NLB clients for "' || NACE_OR_OE||' '||CODE_LIST|| '.');
    set curQuery = CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('NLB', NACE_OR_OE, CODE_LIST, INCLUDE_PRIVATE, INCLUDE_KFW, msgOffset||'    ');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,msgOffset||'  ');

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Getting BLB clients for "' || NACE_OR_OE||' '||CODE_LIST|| '.');
    set curQuery = CALC.AUTO_FUNC_GET_IWHS_LOAD_CODE('BLB', NACE_OR_OE, CODE_LIST, INCLUDE_PRIVATE, INCLUDE_KFW, msgOffset||'    ');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,msgOffset||'  ');

    --call CALC.AUTO_PROC_LOG_INFO(msgOffset||'  Setting meta data');
    --update STG.BGA_MANUAL_CLIENT_LISTS set PORTFOLIO = 'TEST' where 1=1;

    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Finished retrieving clients.');
  end
&&

--#SET TERMINATOR ;

-- TEST

-- call CALC.AUTO_PROC_GET_CLIENTS_FROM_IWHS ('31.12.2019', 'NACE', '''T98'',''O84''',FALSE, FALSE, '')
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
-- select * from STG.BGA_MANUAL_CLIENT_LISTS;
--
-- select distinct CUTOFFDATE from BLB.IWHS_KUNDE; -- where NACE in ('T98','O84') and PERSONTYPE not in ('N','P') and BORROWERID not in (1022,1041)
