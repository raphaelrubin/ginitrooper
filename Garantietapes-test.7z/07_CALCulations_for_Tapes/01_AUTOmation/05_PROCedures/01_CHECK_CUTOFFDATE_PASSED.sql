/* CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED
 *
 * Diese Prozedur testet, ob eine Tabelle das gewünschte Cut Off Date enthällt.
 *
 * @input: TABSCHEMA_IN VARCHAR(8)              Schema der zu testenden Tabelle
 * @input: TABNAME_IN VARCHAR(128)              Name der zu testenden Tabelle
 * @input: CUT_OFF_DATE_COLNAME VARCHAR(10)     Spaltenname des Stichtages der zu testenden Tabelle
 * @input: in_VERSION BIGINT                    Version der Ausführung
 * @input: CUT_OFF_DATE_DESIRED DATE            Cut off Date auf welches getestet wird
 * @input: Forced BOOLEAN                       Muss die Tabelle trotz vorheriger tests nochmal getestet werden?
 * @input/output: OUTPUT BOOLEAN                Global definierte Variable um den Output zurückzugeben
 */


drop procedure CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(varchar(8), varchar(128), varchar(64), BIGINT, DATE, BOOLEAN, BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED(TABSCHEMA_IN varchar(8), TABNAME_IN varchar(128), CUT_OFF_DATE_COLNAME varchar(64), VERSION_IN BIGINT, CUT_OFF_DATE_DESIRED DATE, Forced BOOLEAN, OUTPUT BOOLEAN)
LANGUAGE SQL
  --returns BOOLEAN
  --  MODIFIES SQL DATA
  begin
    -- Declare
    declare hasPassed BOOLEAN;
    declare curQuery CLOB(200k);

    -- Initiate
    delete from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = VERSION_IN;
    COMMIT;
    SET hasPassed = TRUE;
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'select PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||VERSION_IN||' and TABSCHEMA = '''||TABSCHEMA_IN||''' and TABNAME = '''||TABNAME_IN||''';');
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'select first_value(PASSED) over (partition by VERSION, TABSCHEMA, TABNAME order by CREATED_AT DESC) as PASSED from CALC.AUTO_TABLE_CHECK_CUTOFFDATE where VERSION = '||VERSION_IN||' and TABSCHEMA = '''||TABSCHEMA_IN||''' and TABNAME = '''||TABNAME_IN||''' limit 1 with UR;');
    if CUT_OFF_DATE_COLNAME is not NULL and (FORCED or not CALC.AUTO_FUNC_CHECK_CUTOFFDATE_PASSED_HISTORIC(TABSCHEMA_IN, TABNAME_IN, VERSION_IN)) then
        -- entweder die Tabelle muss neu getestet werden (forced) oder sie ist beim letzten Test durchgefallen
        --if CUT_OFF_DATE_COLNAME is not NULL then -- Wenn es eine CUTOFFDATE Spalte gibt
            -- erstelle Query
            set curQuery =  'select '                                                                                           ||
                            '   '''||cast(CUT_OFF_DATE_DESIRED as VARCHAR(16))||'''      as CUT_OFF_DATE, '                             ||
                            'from '||TABSCHEMA_IN || '.' || TABNAME_IN||' ' ||
                            'where '||CUT_OFF_DATE_COLNAME||' = '''||CUT_OFF_DATE_DESIRED||' limit 1';
            -- erstelle Query für Ergebnis
            set curQuery =  'insert into CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,ERROR_MESSAGE) '   ||
                            'select '                                                                                           || -- distinct
                            '   '''||TABSCHEMA_IN||'''              as TABSCHEMA,'                                                      ||
                            '   '''||TABNAME_IN||'''                as TABNAME,'                                                        ||
                            '   '''||cast(CUT_OFF_DATE_DESIRED as VARCHAR(16))||'''      as CUT_OFF_DATE, '                             ||
                            '   '||VERSION_IN||'                    as VERSION,'                                                        ||
                            '   '''||TABSCHEMA_IN || '.' || TABNAME_IN||'.' || CUT_OFF_DATE_COLNAME || ' enthällt den ' || cast(CUT_OFF_DATE_DESIRED as VARCHAR(16)) || ''' as ERROR_MESSAGE ' ||
                            'from '||TABSCHEMA_IN || '.' || TABNAME_IN||' where '||CUT_OFF_DATE_COLNAME||' = '''||CUT_OFF_DATE_DESIRED||''' limit 1'; --''' group by '||CUT_OFF_DATE_COLNAME;

            --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,curQuery||';');
            EXECUTE IMMEDIATE curQuery; -- Teste ob COD in NROW enthalten - teuer, daher nur ausführen, wenn nötig!
            COMMIT;
            --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'select * from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = '||VERSION_IN||';');
            if not EXISTS(select * from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = VERSION_IN) then
                -- Tabelle ist nicht up to date
                --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values ('''||TABSCHEMA_IN||''', '''||TABNAME_IN||''','''||CUT_OFF_DATE_DESIRED||''','||VERSION_IN||',FALSE);');
                insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values (TABSCHEMA_IN, TABNAME_IN,CUT_OFF_DATE_DESIRED,VERSION_IN,FALSE);
                SET hasPassed = FALSE;
            else
                -- Tabelle ist up to date
                --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values ('''||TABSCHEMA_IN||''', '''||TABNAME_IN||''','''||CUT_OFF_DATE_DESIRED||''','||VERSION_IN||',TRUE);');
                insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values (TABSCHEMA_IN, TABNAME_IN,CUT_OFF_DATE_DESIRED,VERSION_IN,TRUE);
            end if;
        --end if;
    elseif CUT_OFF_DATE_COLNAME is NULL then
        -- Tabelle ohne Stichtag Spalte ist immer up to date, wenn sie nicht leer sind.
        -- erstelle Query
        set curQuery =  'insert into CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,ERROR_MESSAGE) '   ||
                        'select distinct'                                                                                           ||
                        '   '''||TABSCHEMA_IN||'''              as TABSCHEMA,'                                                      ||
                        '   '''||TABNAME_IN||'''                as TABNAME,'                                                        ||
                        '   '''||cast(CUT_OFF_DATE_DESIRED as VARCHAR(16))||'''      as CUT_OFF_DATE, '                             ||
                        '   '||VERSION_IN||'                    as VERSION,'                                                        ||
                        '   '''||TABSCHEMA_IN || '.' || TABNAME_IN || ' enthällt Daten (keine Stichtagspalte) '' as ERROR_MESSAGE ' ||
                        'from '||TABSCHEMA_IN || '.' || TABNAME_IN || ' limit 1';
        insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,curQuery||';');
        EXECUTE IMMEDIATE curQuery; -- Teste ob COD in NROW enthalten - teuer, daher nur ausführen, wenn nötig!
        if not EXISTS(select * from CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE where VERSION = VERSION_IN) then
            -- Tabelle ist nicht up to date
            --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values ('''||TABSCHEMA_IN||''', '''||TABNAME_IN||''','''||CUT_OFF_DATE_DESIRED||''','||VERSION_IN||',FALSE);');
            insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values (TABSCHEMA_IN, TABNAME_IN,CUT_OFF_DATE_DESIRED,VERSION_IN,FALSE);
            SET hasPassed = FALSE;
        else
            -- Tabelle ist up to date
            --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (VERSION_IN,'insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values ('''||TABSCHEMA_IN||''', '''||TABNAME_IN||''','''||CUT_OFF_DATE_DESIRED||''','||VERSION_IN||',TRUE);');
            insert into CALC.AUTO_TABLE_CHECK_CUTOFFDATE (TABSCHEMA,TABNAME,CUT_OFF_DATE,VERSION,PASSED) values (TABSCHEMA_IN, TABNAME_IN,CUT_OFF_DATE_DESIRED,VERSION_IN,TRUE);
        end if;
    end if;
    --return hasPassed;
    set OUTPUT = hasPassed;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_CHECK_CUTOFFDATE_PASSED is 'Prozedur zum Testen, ob eine Tabelle den gewünschten Stichtag enthällt';

-- Kommentar für CI-Test
