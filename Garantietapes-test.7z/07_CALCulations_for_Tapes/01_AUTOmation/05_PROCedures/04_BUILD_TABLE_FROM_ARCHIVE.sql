/* CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE
 * Baut eine Tabelle basierend auf dem Archiv neu.
 *
 * @input: TAPE VARCHAR(8)                  Name des aktiven Tapes
 * @input: desired_TABSCHEMA VARCHAR(8)     Name des Schema der zu bauenden Tabelle
 * @input: desired_TABNAME VARCHAR(128)     Name der zu bauenden Tabelle
 * @input: desired_CUT_OFF_DATE VARCHAR(10) Stichtag im gültigen Format (z.B. 30.09.2019)
 * @input: msgOffset VARCHAR(128)           Leerzeichen, um Log-nachrichten einzurücken
 * @input: doTruncate BOOLEAN               Muss die Tabelle vor dem Neubau geleert werden? (trifft normalerweise auf
 *                                          CURRENT und nicht auf ARCHIVE Tabellen zu)
 */

drop procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE( VARCHAR(8),VARCHAR(8),VARCHAR(128),VARCHAR(10),  VARCHAR(128), BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10),msgOffset VARCHAR(128), doTruncate BOOLEAN)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
     declare real_TABSCHEMA VARCHAR(8);

    if desired_TABSCHEMA = 'AMC' then
        set real_TABSCHEMA = TAPENAME;
    else
        set real_TABSCHEMA = desired_TABSCHEMA;
    end if;

    -- Aus dem Archiv bauen
    call CALC.AUTO_PROC_LOG_INFO(msgOffset||'Recreating "' || desired_TABSCHEMA||'.'||desired_TABNAME|| '" from archive.');
    if doTruncate then
        -- Aktuell vorhandene Daten aus Tabelle löschen
        set curQuery = CALC.AUTO_FUNC_GET_TRUNCATE_CODE(real_TABSCHEMA,desired_TABNAME);
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,msgOffset);
    end if;
    -- Tabelle neu befüllen
    set curQuery = CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE(TAPENAME,desired_TABSCHEMA, desired_TABNAME, desired_CUT_OFF_DATE);
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE_MULTIPLE(curQuery, msgOffset);
  end
&&



--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE(VARCHAR(8),VARCHAR(8),VARCHAR(128),VARCHAR(10));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE (TAPENAME VARCHAR(8), desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),desired_CUT_OFF_DATE VARCHAR(10))
    LANGUAGE SQL
  BEGIN
    declare msgOffset VARCHAR(128);
    declare doTruncate BOOLEAN;

    set msgOffset = '';
    SET doTruncate = (select DO_TRUNCATE_BEFORE_BUILD from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1 with UR);

    call CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE ( TAPENAME, desired_TABSCHEMA,desired_TABNAME,desired_CUT_OFF_DATE,msgOffset, doTruncate);
  end
&&

