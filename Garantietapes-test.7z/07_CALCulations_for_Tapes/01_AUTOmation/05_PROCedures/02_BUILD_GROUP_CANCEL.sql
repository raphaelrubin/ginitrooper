/* CALC.AUTO_PROC_BUILD_GROUP_CANCEL
 * Markiert die laufende Bau-Prozedur als fehlgeschlagen.
 *
 * @throws SQLCODE 438, SQLSTATE 72849              Es gibt keine unvollständige Bau-Prozedur zum Abbrechen.
 */

drop procedure CALC.AUTO_PROC_BUILD_GROUP_CANCEL();
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_GROUP_CANCEL()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
  BEGIN
    declare curVERSION BIGINT;

    set curVERSION = coalesce((select max(arg_VERSION) from CALC.AUTO_TABLE_BUILD_VERSIONS where not Completed),0);

    if curVERSION = 0 then
        signal SQLSTATE '72849' set MESSAGE_TEXT = 'There is no incomplete instance of AUTO_PROC_BUILD.';
    end if;

    call CALC.AUTO_PROC_LOG_WARNING('User '||SESSION_USER ||' marked the execution of AUTO_PROC_BUILD as failed. This did not affect any potentially running routines.' );

    update CALC.AUTO_TABLE_BUILD_VERSIONS set (COMPLETED,SUCCESS) = (TRUE,FALSE) where ARG_VERSION = curVERSION;
  END
&&
