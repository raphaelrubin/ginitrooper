/* CALC.AUTO_PROC_EXECUTE_IMMEDIATE
 *
 * Prozedur, welche einen SQL Befehl entgegen nimmt und ausführt.
 *
 * @input arg_COMMAND CLOB(200K),   SQL Befehl, welcher ausgeführt werden soll
 * @input msgOffset VARCHAR(128)    String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                  Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu lesen
 *                                  ist.
 */
drop procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE(CLOB(800K), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE(in_COMMAND CLOB(800K),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare curQueryShort VARCHAR(450);
    if msgOffset is not NULL then
        set curQueryShort = left(in_COMMAND,450);
        set curQueryShort = coalesce(trim(B FROM curQueryShort),'');
        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  About to execute: "' || trim(B FROM curQueryShort) ||'".');
    end if;
    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) values (1,in_COMMAND);
    COMMIT;
    BEGIN ATOMIC
        EXECUTE IMMEDIATE in_COMMAND;
    END;
    --call CALC.AUTO_PROC_EXECUTE_LATER(1,COMMAND,msgOffset);
    COMMIT;
    if msgOffset is not NULL then
        call CALC.AUTO_PROC_LOG_DEBUG(msgOffset||'  Done executing.');
    end if;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_EXECUTE_IMMEDIATE is 'Prozedur zum Ausführen und Loggen eines SQL Statements.';
