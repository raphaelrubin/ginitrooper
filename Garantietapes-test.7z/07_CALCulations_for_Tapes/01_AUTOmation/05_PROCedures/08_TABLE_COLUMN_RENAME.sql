-- TODO: unfertig! Idee ist, dass man Spaltennamen schneller anpassen kann (siehe notwendige Schritte in der Wiki)
drop procedure CALC.AUTO_PROC_TABLE_COLUMN_RENAME(VARCHAR(128),VARCHAR(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_TABLE_COLUMN_RENAME (TABNAME_old VARCHAR(128), COLNAME_old VARCHAR(128), COLNAME_new VARCHAR(128))
    LANGUAGE SQL
BEGIN
    -- START DEKLARATIONEN
    declare curQuery CLOB(200k);
    DECLARE CURxRT1 INSENSITIVE Cursor
        for
            select distinct TRIM(B ' ' FROM TABSCHEMA) AS SCHEMA, TABNAME AS NAME, TRIM(B ' ' FROM TABSCHEMA)||'.'||TABNAME AS FULLNAME from SYSCAT.COLUMNS where COLNAME = COLNAME_old and (TABNAME = TABNAME_old or TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(LEFT(TABSCHEMA,8),TABNAME_old)) with UR;

    -- Check if the Tablename is valid:



    call CALC.AUTO_PROC_LOG_INFO('Starting to alter table column '||TABNAME_old||'.'||COLNAME_old||' to '||COLNAME_new);
    -- Get all the Current and Archive tables
    for TABLE as CURxRT1 Cursor
        for
            select distinct TRIM(B ' ' FROM TABSCHEMA) AS SCHEMA, TABNAME AS NAME, TRIM(B ' ' FROM TABSCHEMA)||'.'||TABNAME AS FULLNAME from SYSCAT.COLUMNS where COLNAME = COLNAME_old and (TABNAME = TABNAME_old or TABNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(LEFT(TABSCHEMA,8),TABNAME_old)) with UR
    do

        call CALC.AUTO_PROC_LOG_INFO('  About to change '||TABLE.FULLNAME||'.');

        -- Issue a rename on the column

        set curQuery = 'ALTER TABLE '||TABLE.FULLNAME||' RENAME COLUMN '||COLNAME_old||' TO '||COLNAME_new||'';

        -- alter the merge command of the archive tables

        set curQuery = 'update CALC.AUTO_TABLE_TARGETS set (BUILDCODE, RECREATECODE, COLNAME_CUT_OFF_DATE) = (REPLACE(BUILDCODE,'''||COLNAME_old||''','''||COLNAME_new||''') as BUILDCODE, REPLACE(RECREATECODE,'''||COLNAME_old||''','''||COLNAME_new||''') as RECREATECODE, REPLACE(COLNAME_CUT_OFF_DATE,'''||COLNAME_old||''','''||COLNAME_new||''') as COLNAME_CUT_OFF_DATE) where TABNAME = '''||TABLE.NAME||'''';

    end for;

    call CALC.AUTO_PROC_LOG_INFO('Finished altering table column '||TABNAME_old||'.'||COLNAME_old||' to '||COLNAME_new);

END
&&