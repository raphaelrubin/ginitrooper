-- Diese Prozedur wird von Airflow alle paar Minuten aufgerufen und führt den geforderten Code aus STG.AUTO_TABLE_AIRFLOW_CONFIG aus.

drop procedure CALC.AUTO_PROC_AIRFLOW_EXECUTION();
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_AIRFLOW_EXECUTION()
    LANGUAGE SQL
BEGIN
    declare SQLCODE INTEGER DEFAULT 0;
    declare SQLSTATE CHAR(5 OCTETS) DEFAULT '00000';
    declare RUN_SQLCODE INTEGER DEFAULT 0;
    declare RUN_SQLSTATE CHAR(5) DEFAULT '00000';
    declare RUN_DIAGNOSTIC_STRING VARCHAR(1024) DEFAULT '';
    declare RUN_RETURN_STATUS INTEGER DEFAULT 0;
    declare RUN_ID BIGINT;
    declare RUN_PROCEDURE_LABEL VARCHAR(64);
    declare RUN_PROCEDURE VARCHAR(64);
    declare RUN_ARGUMENTS VARCHAR(1024);
    declare RUN_QUERY CLOB(200k);
    declare CONTINUE HANDLER for SQLEXCEPTION, SQLWARNING
        begin
            GET DIAGNOSTICS RUN_RETURN_STATUS = DB2_RETURN_STATUS;
            GET DIAGNOSTICS EXCEPTION 1
                RUN_DIAGNOSTIC_STRING = MESSAGE_TEXT;
            select SQLCODE, SQLSTATE into RUN_SQLCODE, RUN_SQLSTATE from SYSIBM.SYSDUMMY1;
            update STG.AUTO_TABLE_AIRFLOW_CONFIG set STATUS = 'FAILED', ERROR_MESSAGE = 'SQLCODE: '||RUN_SQLCODE||' SQLSTATE: '||RUN_SQLSTATE||' RETURN_STATUS: '||RUN_RETURN_STATUS||' '||RUN_DIAGNOSTIC_STRING, FAILED_AT = CURRENT_TIMESTAMP where ID = RUN_ID;
            call CALC.AUTO_PROC_LOG_WARNING('Airflow execution failed with SQLCODE '||RUN_SQLCODE||' and SQLSTATE '||RUN_SQLSTATE);
        end;

    if not EXISTS(select * from STG.AUTO_TABLE_AIRFLOW_CONFIG where STATUS = 'STARTED') then
        -- aktuell wird nichts ausgeführt
        if EXISTS(select * from STG.AUTO_TABLE_AIRFLOW_CONFIG where STATUS = 'REQUESTED') then
            -- wenn es einen requested gibt, dann
            -- a) Lese Parameter und setze den Status auf STARTED
            set RUN_ID = (select ID from STG.AUTO_TABLE_AIRFLOW_CONFIG where STATUS = 'REQUESTED' order by CREATED_AT limit 1);
            update STG.AUTO_TABLE_AIRFLOW_CONFIG set STATUS = 'STARTED', STARTED_AT = CURRENT_TIMESTAMP where ID = RUN_ID;
            -- b) Validiere den Input
            set RUN_PROCEDURE_LABEL = (select PROCEDURE from STG.AUTO_TABLE_AIRFLOW_CONFIG where ID = RUN_ID);
            set RUN_ARGUMENTS = (select ARGUMENTS from STG.AUTO_TABLE_AIRFLOW_CONFIG where ID = RUN_ID);
            -- Argumente vor SQL Injection bewahren:
            set RUN_ARGUMENTS = upper(replace(RUN_ARGUMENTS,';',','));
            set RUN_ARGUMENTS = replace(RUN_ARGUMENTS,'CHAR(','');
            set RUN_ARGUMENTS = replace(replace(RUN_ARGUMENTS,'(',''),')','');


            -- Prozedur als Valide überprüfen:
            set RUN_PROCEDURE = NULL;
            if RUN_PROCEDURE_LABEL = 'SWITCHTAPE' 
		or RUN_PROCEDURE_LABEL = 'DO_SWITCH_TO_TAPE' then
                    set RUN_PROCEDURE = 'CALC.DO_SWITCH_TO_TAPE';
                elseif  RUN_PROCEDURE_LABEL = 'BUILD' 
				  or RUN_PROCEDURE_LABEL = 'DO_BUILD_A_GROUP' then
                    set RUN_PROCEDURE = 'CALC.DO_BUILD_A_GROUP';
                elseif  RUN_PROCEDURE_LABEL = 'CONTINUE' 
				  or RUN_PROCEDURE_LABEL = 'DO_CONTINUE_BUILDING' then
                    set RUN_PROCEDURE = 'CALC.DO_CONTINUE_BUILDING';
                elseif  RUN_PROCEDURE_LABEL = 'CANCEL' 
				  or RUN_PROCEDURE_LABEL = 'DO_CANCEL_BUILDING' then
                    set RUN_PROCEDURE = 'CALC.DO_CANCEL_BUILDING';
                elseif  RUN_PROCEDURE_LABEL = 'ARCHIVE' 
				  or RUN_PROCEDURE_LABEL = 'DO_ARCHIVE_ALL' then
                    set RUN_PROCEDURE = 'CALC.DO_ARCHIVE_ALL';
                elseif  RUN_PROCEDURE_LABEL = 'VALIDATE' 
				  or RUN_PROCEDURE_LABEL = 'DO_RUN_VALIDATIONS' then
                    set RUN_PROCEDURE = 'CALC.DO_RUN_VALIDATIONS';
                elseif  RUN_PROCEDURE_LABEL = 'EXPORT' 
				  or RUN_PROCEDURE_LABEL = 'EXPORT GROUP' 
				  or RUN_PROCEDURE_LABEL = 'DO_EXPORT_A_GROUP' then
                    set RUN_PROCEDURE = 'CALC.DO_EXPORT_A_GROUP';
		elseif  RUN_PROCEDURE_LABEL = 'EXPORT TABLE' 
				  or RUN_PROCEDURE_LABEL = 'PROC_EXPORT_TABLE' then
					set RUN_PROCEDURE = 'STG.PROC_EXPORT_TABLE'; -- STSK0012821
                elseif  RUN_PROCEDURE_LABEL = 'EXPORT_BW_CLIENTS' 
				  or RUN_PROCEDURE_LABEL = 'DO_EXPORT_DESIRED_BW_CLIENTS' then
                    set RUN_PROCEDURE = 'CALC.DO_EXPORT_DESIRED_BW_CLIENTS';
                elseif  RUN_PROCEDURE_LABEL = 'BUILD EXPLICIT' 
		  or RUN_PROCEDURE_LABEL = 'LOAD'
		  or RUN_PROCEDURE_LABEL = 'LOAD CURRENT'
		  or RUN_PROCEDURE_LABEL = 'LOAD ARCHIVE'
		  or RUN_PROCEDURE_LABEL = 'DO_BUILD_A_TABLE_EXPLICITELY' then
		    if RUN_ARGUMENTS like '%____-__-__%' and RUN_PROCEDURE_LABEL = 'LOAD CURRENT' then
		        set RUN_PROCEDURE = 'CALC.AUTO_PROC_BUILD_TABLE_FROM_ARCHIVE';
		    else
		        set RUN_PROCEDURE = 'CALC.DO_BUILD_A_TABLE_EXPLICITELY';
		    end if;

		elseif  RUN_PROCEDURE_LABEL = 'DPK PREPARE' 
				  or RUN_PROCEDURE_LABEL = 'PROC_PREPARE_DATA_AND_TABLES' then
					set RUN_PROCEDURE = 'DPK.PROC_PREPARE_DATA_AND_TABLES'; -- STSK0012819
		elseif  RUN_PROCEDURE_LABEL = 'DPK RUN' 
				  or RUN_PROCEDURE_LABEL = 'PROC_EXECUTE_TREE' then
					set RUN_PROCEDURE = 'DPK.PROC_EXECUTE_TREE'; -- STSK0012820

                -- BGA Sondertapes
                elseif  RUN_PROCEDURE_LABEL = 'GET IWHS CLIENTS'
				  or RUN_PROCEDURE_LABEL = 'GENERATE CLIENTSLIST'
                  or RUN_PROCEDURE_LABEL = 'DO_GENERATE_A_CLIENTSLIST' then
					set RUN_PROCEDURE = 'CALC.DO_GENERATE_A_CLIENTSLIST';  -- STRY3006209
                elseif  RUN_PROCEDURE_LABEL = 'LOAD EXTRA CLIENTS'
                  or RUN_PROCEDURE_LABEL = 'LOAD EXTRA FACILITIES'
                  or RUN_PROCEDURE_LABEL = 'LOAD CLIENT LIST'
				  or RUN_PROCEDURE_LABEL = 'LOAD BGA'
                  or RUN_PROCEDURE_LABEL = 'LOAD EXTRA LISTS' then
					set RUN_PROCEDURE = 'CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS';
		 elseif RUN_PROCEDURE_LABEL = 'BUILD EXTRA CLIENTS'
                  or RUN_PROCEDURE_LABEL = 'BUILD EXTRA FACILITIES'
                  or RUN_PROCEDURE_LABEL = 'BUILD CLIENT LIST'
				  or RUN_PROCEDURE_LABEL = 'BUILD BGA'
                  or RUN_PROCEDURE_LABEL = 'BUILD EXTRA LISTS' then
					set RUN_PROCEDURE = 'CALC.AUTO_PROC_BUILD_GROUP_BGA';
				-- Change auf Prod
                elseif  RUN_PROCEDURE_LABEL = 'PROD_CHANGE'
				  or RUN_PROCEDURE_LABEL = 'PROD CHANGE' then
					set RUN_PROCEDURE = 'CALC.AUTO_PROC_PROD_CHANGE';
				else
                    set RUN_PROCEDURE = NULL;
            end if;

            set RUN_QUERY = 'call '||RUN_PROCEDURE||'('||RUN_ARGUMENTS||')';
            -- c) Führe die Prozedur aus
            if not RUN_QUERY is NULL then
                --call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(RUN_QUERY,'');
                begin
                   declare stmt STATEMENT;
                   prepare stmt FROM RUN_QUERY;
                   execute stmt;
                end;
                update STG.AUTO_TABLE_AIRFLOW_CONFIG set STATUS = 'COMPLETED', COMPLETED_AT = CURRENT_TIMESTAMP where ID = RUN_ID and STATUS = 'STARTED';
                -- wenn der Befehl einen bekannten Fehler wirft, setze den Status auf FAILED.
                -- wenn der Befehl durchläuft, setze den Status auf COMPLETED.

                -- Im Falle eines unbekannten Fehlers bricht diese Prozedur ab. Airflow verschickt eine Email an uns und wir müssen den aktuell laufenden Eintrag manuell auf "Failed" setzen.
                -- -> langfristig könnte Airflow einen Eintrag in einer Datenbanktabelle erstellen, den diese Prozedur beim nächsten auslesen feststellt.
            end if;
            update STG.AUTO_TABLE_AIRFLOW_CONFIG set STATUS = 'FAILED', ERROR_MESSAGE = 'Invalid command supplied', FAILED_AT = CURRENT_TIMESTAMP where ID = RUN_ID and STATUS = 'STARTED';
        end if;
    end if;

END
&&
--#SET TERMINATOR ;
