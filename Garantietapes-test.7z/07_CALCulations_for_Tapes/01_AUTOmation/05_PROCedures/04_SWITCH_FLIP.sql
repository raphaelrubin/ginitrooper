/* CALC.AUTO_PROC_SWITCH_FLIP
 *
 * Diese Prozedur erstellt eine Switch View (neu).
 *
 * @input: TAPENAME VARCHAR(8)              Name des aktiven Schemas
 * @input: TABNAME VARCHAR(128)             Name der Tabelle, für welche die Switch View gebaut werden soll
 * @input: msgOffset VARCHAR(128)           String, der vor alle Log-Nachrichten gepackt wird. Hier kommen normalerweise
 *                                          Leerzeichen rein, um einen Offset zu definieren, damti der Log einfacher zu
 *                                          lesen ist.
 */

drop procedure CALC.AUTO_PROC_SWITCH_FLIP(varchar(8), varchar(128),VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_SWITCH_FLIP(TAPENAME varchar(8), TABNAME varchar(128),msgOffset VARCHAR(128))
LANGUAGE SQL
  begin
    declare SWITCHNAME varchar(512);
    declare DROP_STATEMENT CLOB(200K);

    set SWITCHNAME = CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_SWITCH(TABNAME);

    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,'select * from SYSCAT.VIEWS where VIEWNAME = '''||SWITCHNAME||''' and VIEWSCHEMA = ''CALC'';');
    if EXISTS(select * from SYSCAT.VIEWS where VIEWNAME = SWITCHNAME and VIEWSCHEMA = 'CALC') then
        set DROP_STATEMENT = 'drop view CALC.'||SWITCHNAME;
        --call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(DROP_STATEMENT,msgOffset);
        --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,DROP_STATEMENT);
        EXECUTE IMMEDIATE DROP_STATEMENT;
    end if;

    call CALC.AUTO_PROC_SWITCH_CREATE(TAPENAME,TABNAME,msgOffset);
    COMMIT;
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_SWITCH_FLIP(varchar(8), varchar(128),VARCHAR(128)) is 'Prozedur zum Umstellen eines Switches. Die Switchview wird gelöscht falls sie existiert und dann neu gebaut.';

-- Kommentar für CI-Test