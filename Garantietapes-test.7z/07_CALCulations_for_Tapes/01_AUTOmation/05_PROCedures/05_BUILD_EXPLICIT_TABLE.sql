
drop procedure CALC.AUTO_PROC_BUILD_EXPLICIT_TABLE (VARCHAR(8), VARCHAR(128), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_EXPLICIT_TABLE (desired_TABSCHEMA VARCHAR(8),desired_TABNAME VARCHAR(128),msgOffset VARCHAR(128))
    LANGUAGE SQL
  BEGIN
    declare TAPENAME VARCHAR(8);
    declare doTruncate BOOLEAN;
    SET doTruncate = (select DO_TRUNCATE_BEFORE_BUILD from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1 with UR);
    SET TAPENAME = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1 with UR);

    -- Standard Aufruf der Automatisierung (hier werden beladungsroutinen explizit nicht forciert. Falls eine Quelltabelle fälschlicherweise angefordert wird, wird diese Prozedur einen Fehler werfen.
    call CALC.AUTO_PROC_BUILD_TABLE_FROM_VIEW (TAPENAME, desired_TABSCHEMA,desired_TABNAME, doTruncate, TRUE, msgOffset);
  end
&&