/* CALC.AUTO_PROC_ALPACA_MATE
 * Sperrt zwei virtuelle männliche weiße Alpaka in einen Raum, um sie zu paaren.
 *
 * @throws SQLCODE 438, SQLSTATE 7A100      Du hast nicht die Berechtigung Alpaka zu klonen.
 * @throws SQLCODE 438, SQLSTATE 7A300      Du hast keine Alpaka mehr, die gepaart werden könnten.
 * @throws SQLCODE 438, SQLSTATE 7A342      Das Paaren zweier männlicher Alpaka hat einen Fehler geworfen. Siehe Nachricht für Details.
 */

drop procedure CALC.AUTO_PROC_ALPACA_MATE();
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_ALPACA_MATE()
    LANGUAGE SQL
begin
    declare ERRORMESSAGE varchar(512);
    declare CurStars BIGINT;
    declare CurAlpacas BIGINT;
    declare MatingOutcome INT;

--     if (SESSION_USER <> 'DB124560') then
--         set ERRORMESSAGE = 'The authorization ID does not have the privilege to mate alpaca.';
--         signal SQLSTATE '7A100' set MESSAGE_TEXT = ERRORMESSAGE;
--     end if;

    set CurStars = (select STARS from CALC.AUTO_VIEW_ALPACA limit 1);
    set CurAlpacas = (select ALPACA from CALC.AUTO_VIEW_ALPACA limit 1);

    if (CurAlpacas < 2) then
        set ERRORMESSAGE = 'Insufficient alpacas remain for mating.';
        signal SQLSTATE '7A300' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;

    set MatingOutcome = 60*RAND(MICROSECOND(CURRENT_TIMESTAMP));

    case
        when MatingOutcome = 1 then
            set ERRORMESSAGE = 'The two male white alpaca didn''t even look at each other.';
        when MatingOutcome = 2 then
            set ERRORMESSAGE = 'The two male white alpaca are gay but that didn''t help the case.';
        when MatingOutcome = 3 then
            set ERRORMESSAGE = 'The two alpaca started fighting. You managed to separate them.';
        when MatingOutcome = 4 then
            set ERRORMESSAGE = 'The two alpaca started fighting. One of them died.';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (-1,0);
        when MatingOutcome = 5 then
            set ERRORMESSAGE = 'The two alpaca started fighting. Both of them died.';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (-2,0);
        when MatingOutcome = 6 then
            set ERRORMESSAGE = 'The alpaca decided to handcraft some stars for you.';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (0,300);
        when MatingOutcome = 7 then
            set ERRORMESSAGE = 'One alpaca mistakes this for a birthday party and gifts you a star';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (0,1);
        when MatingOutcome = 8 then
            set ERRORMESSAGE = 'The alpaca look very grumpy.';
        when MatingOutcome = 9 then
            set ERRORMESSAGE = 'Do you enjoy trying to mate male alpaca? They certainly don''t.';
        when MatingOutcome = 10 then
            set ERRORMESSAGE = 'The alpaca gaze at you, wet grass hanging from their mouth.';
        when MatingOutcome = 11 then
            set ERRORMESSAGE = 'The two isolated alpaca turn out to have Corona and die.';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (-2,0);
        when MatingOutcome = 12 then
            set ERRORMESSAGE = 'The two isolated alpaca turn out to have Corona and get drunk.';
        when MatingOutcome = 13 then
            set ERRORMESSAGE = 'The alpaca gaze at you, wet grass hanging from their mouth.';
        when MatingOutcome = 14 then
            set ERRORMESSAGE = 'On close inspection, one alpaca turns out to be a donkey with a lot of stars on it.';
            insert into CALC.AUTO_TABLE_ALPACA (CHANGE,STARS_CHANGE) values (-1,600);
        else
            set ERRORMESSAGE = 'Nothing happened when mating two male white alpaca.';
    end case;
    signal SQLSTATE '7A342' set MESSAGE_TEXT = ERRORMESSAGE;
END
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_ALPACA_MATE is 'Prozedur zum Paaren männlicher weißer Alpaka.';
