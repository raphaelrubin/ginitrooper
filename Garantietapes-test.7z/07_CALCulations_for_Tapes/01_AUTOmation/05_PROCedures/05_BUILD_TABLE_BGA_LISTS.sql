-- Diese Prozedur Läd Daten aus STG.MANUAL_LISTS oder IMAP.MANUAL_LISTS (ARCHIVE) nach IMAP.MANUAL_LISTS_CURRENT und BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS/FACILITIES_CURRENT

drop procedure CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS (VARCHAR(500),BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS (requester VARCHAR(500), desired_list_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare SQL_truncate_code CLOB(200k);
    declare SQL_insert_code CLOB(200k);
    declare SQL_count INTEGER default 0;
    declare SQL_state BOOLEAN default true;

    if(requester is NULL) then
        set requester = 'Unbekannt';
    end if;

    -- wenn keine list ID gegeben ist, dann sollte eine neue List ID generiert werden und die Daten aus der T-View ins Archiv geladen werden.
    if (desired_list_ID is NULL) then
        -- get new list ID:
        set desired_list_ID = (select max(coalesce(LIST_ID,0))+1 from IMAP.MANUAL_LISTS);
        -- load Data into Archive
        set SQL_insert_code = 'insert into IMAP.MANUAL_LISTS (LIST_ID, CUT_OFF_DATE, BRANCH_CLIENT, CLIENT_NO, BRANCH_FACILITY, FACILITY_ID, PORTFOLIO_CODE, PORTFOLIO, REQUESTED_BY, PROJECT, COMMENT, VALID_FROM_DATE, VALID_TO_DATE, TIMESTAMP_LOAD, ETL_NR, QUELLE, USER)
        select distinct '||coalesce(desired_list_ID,1)||' as LIST_ID, CUT_OFF_DATE, BRANCH_CLIENT, CLIENT_NO, BRANCH_FACILITY, FACILITY_ID, PORTFOLIO_CODE, PORTFOLIO, '''||requester||''' as REQUESTED_BY, PROJECT, COMMENT, VALID_FROM_DATE, VALID_TO_DATE, TIMESTAMP_LOAD, ETL_NR, QUELLE, USER from STG.T_VIEW_MANUAL_LISTS where PORTFOLIO_CODE = ''BGA''';
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_insert_code,'  ');
        call CALC.AUTO_PROC_LOG_INFO('Neue Liste für '||requester||' mit ID '||desired_list_ID||' angelegt.');
    end if;

    -- in jedem Fall müssen die Daten für die gewünschte/neue List ID in die Current Tabelle geladen werden.
    set SQL_truncate_code = CALC.AUTO_FUNC_GET_TRUNCATE_CODE('IMAP','MANUAL_LISTS_CURRENT');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_truncate_code,'  ');
    set SQL_insert_code = 'insert into IMAP.MANUAL_LISTS_CURRENT (LIST_ID, CUT_OFF_DATE, BRANCH_CLIENT, CLIENT_NO, BRANCH_FACILITY, FACILITY_ID, PORTFOLIO_CODE, PORTFOLIO, REQUESTED_BY, PROJECT, COMMENT, VALID_FROM_DATE, VALID_TO_DATE, TIMESTAMP_LOAD, ETL_NR, QUELLE, USER)
    select distinct LIST_ID, CUT_OFF_DATE, BRANCH_CLIENT,CLIENT_NO, BRANCH_FACILITY, FACILITY_ID, PORTFOLIO_CODE, PORTFOLIO, REQUESTED_BY, PROJECT, COMMENT,COALESCE(VALID_FROM_DATE,''01/01/2023''), VALID_TO_DATE, TIMESTAMP_LOAD, ETL_NR, QUELLE, USER from IMAP.MANUAL_LISTS where LIST_ID = '||desired_list_ID;
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_insert_code,'  ');
    call CALC.AUTO_PROC_LOG_INFO('Liste '||desired_list_ID||' geladen.');

    -- leeren der BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT
    set SQL_truncate_code = CALC.AUTO_FUNC_GET_TRUNCATE_CODE('BGA','TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_truncate_code,'  ');
    set SQL_count = (select count(*) from IMAP.MANUAL_LISTS_CURRENT where LIST_ID = desired_list_ID and CLIENT_NO is not null);
    -- Wenn weder CLIENT_NO, BRANCH_CLIENT, FACILITY_ID, BRANCH_FACILITY gefuellt ist, kann keine Liste erzeugt werden und es wird abgebrochen.
    if SQL_count > 0 then
      set SQL_state = false;
    -- Wenn CLIENT_NO und BRANCH_CLIENT gefuellt sind, soll die Kundenliste in die TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT geladen werden
        -- beladen der BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT aus IMAP.MANUAL_LISTS_CURRENT
        set SQL_insert_code = 'insert into BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT (LIST_ID,BRANCH_CLIENT,CLIENT_NO,PORTFOLIO, SOURCE, VALID_FROM_DATE,VALID_TO_DATE,REQUESTED_BY)
        select distinct '||coalesce(desired_list_ID,1)||' as LIST_ID, BRANCH_CLIENT, CLIENT_NO, PORTFOLIO, QUELLE, VALID_FROM_DATE, VALID_TO_DATE, REQUESTED_BY from IMAP.MANUAL_LISTS_CURRENT WHERE CLIENT_NO is not null and BRANCH_CLIENT is not null';
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_insert_code,'  ');
        call CALC.AUTO_PROC_LOG_INFO('Neue Kundenliste für '||requester||' mit ID '||desired_list_ID||' nach BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT geladen.');
    else
        call CALC.AUTO_PROC_LOG_INFO('Not writing to BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT because CLIENT_NO or BRANCH_CLIENT is NULL.');
    end if;

    -- leeren der BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT
    set SQL_truncate_code = CALC.AUTO_FUNC_GET_TRUNCATE_CODE('BGA','TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT');
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_truncate_code,'  ');
    set SQL_count = (select count(*) from IMAP.MANUAL_LISTS_CURRENT where LIST_ID = desired_list_ID and FACILITY_ID is not null);
    if SQL_count > 0 then
     set SQL_state = false;
    -- Wenn FACILITY_ID und BRANCH_FACILITY gefuellt sind, soll die Kontenliste in die TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT geladen werden
        -- beladen der BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT aus IMAP.MANUAL_LISTS_CURRENT
        set SQL_insert_code = 'insert into BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT (LIST_ID,BRANCH_FACILITY,FACILITY_ID,PORTFOLIO, SOURCE, VALID_FROM_DATE,VALID_TO_DATE,REQUESTED_BY)
        select distinct '||coalesce(desired_list_ID,1)||' as LIST_ID, BRANCH_FACILITY, FACILITY_ID, PORTFOLIO, QUELLE, VALID_FROM_DATE, VALID_TO_DATE, REQUESTED_BY from IMAP.MANUAL_LISTS_CURRENT WHERE FACILITY_ID is not null and BRANCH_FACILITY is not null';
        call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(SQL_insert_code,'  ');
        call CALC.AUTO_PROC_LOG_INFO('Neue Kontenliste für '||requester||' mit ID '||desired_list_ID||' nach BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT geladen.');
    else
         call CALC.AUTO_PROC_LOG_INFO('Not writing to BGA.TABLE_PORTFOLIO_FACILITY_MANUAL_CURRENT because FACILITY_ID or BRANCH_FACILITY is NULL.');
    end if;

    if SQL_state then
        call CALC.AUTO_PROC_LOG_ERROR('Weder eine Kunden- noch Kontenliste kann erzeugt werden, da es weder CLIENT_NOs noch FACILITY_IDs für diese LISTEN_ID gibt!');
        return;
    end if;
  END
&&
--#SET TERMINATOR ;
drop procedure CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS (VARCHAR(500));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS (newRequesterName_or_oldListId VARCHAR(500))
    LANGUAGE SQL
  BEGIN
    declare newRequesterName VARCHAR(500);
    declare oldListId BIGINT;

    if (LENGTH(TRIM(TRANSLATE(newRequesterName_or_oldListId,'',' 0123456789')))=0) then
        set oldListId = cast(newRequesterName_or_oldListId as BIGINT);
        set newRequesterName = NULL;
        call CALC.AUTO_PROC_LOG_INFO('Alte Liste '||oldListId||' laden.');
    else
        set newRequesterName = cast(newRequesterName_or_oldListId as VARCHAR(500));
        set oldListId = NULL;
        call CALC.AUTO_PROC_LOG_INFO('Neue Liste für '||newRequesterName||' laden.');
    end if;

    call CALC.AUTO_PROC_BUILD_TABLE_BGA_LISTS (newRequesterName, oldListId);
  END
&&


-- Test
--select distinct LIST_ID from BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_ARCHIVE;
--call CALC.AUTO_PROC_BUILD_TABLE_BGA_CLIENTS (1);
--select * from BGA.TABLE_PORTFOLIO_MANUAL_CLIENTS_CURRENT;

--select LENGTH(TRIM(TRANSLATE(1,'',' 0123456789'))) from SYSIBM.SYSDUMMY1;

--select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;