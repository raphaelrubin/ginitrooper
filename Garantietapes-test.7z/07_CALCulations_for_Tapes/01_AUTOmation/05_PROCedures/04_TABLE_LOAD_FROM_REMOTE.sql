
drop procedure CALC.AUTO_PROC_TABLE_LOAD_FROM_REMOTE(VARCHAR(20),VARCHAR(10),VARCHAR(50));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_TABLE_LOAD_FROM_REMOTE(REMOTE VARCHAR(20),SCHEMA VARCHAR(10),TABLE VARCHAR(50))
LANGUAGE SQL
  begin
    declare REPLACABLE VARCHAR(128);
    declare ERRORMESSAGE VARCHAR(128);
    declare CODE CLOB(200k);
    declare is_TAPE BOOLEAN;

    -- START INPUT CHECK
    -- Tabelle nicht automatisiert/verfügbar/o.ä
    if not EXISTS(select * from SYSCAT.TABLES where TABNAME = TABLE and TABSCHEMA = SCHEMA) then
        set ERRORMESSAGE = 'Table '||TABLE||' not in SYSCAT';
        signal SQLSTATE '7C101' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;
    if not EXISTS(select * from Calc.AUTO_TABLE_TARGETS where TABNAME = TABLE and TABSCHEMA = SCHEMA or BUILD_VIEW_SCHEMA = 'CALC') then
        set ERRORMESSAGE = 'Table '||TABLE||' not in TARGETS config';
        signal SQLSTATE '7C102' set MESSAGE_TEXT = ERRORMESSAGE;
    end if;
    -- Remote nicht Verfübar (Rem Option sind: Von Dev aus: REM_BLOSSOM, REM_AGR_TEST; von TEST aus: REM_BLOSSOM, REM_AGR_DEV; von PROD aus: REM_AGR_DEV,REM_AGR_TEST
    if REMOTE not in ('REM_BLOSSOM','REM_AGR_TEST','REM_AGR_DEV') or REMOTE = 'REM_'||upper(CURRENT_SERVER) then
        signal SQLSTATE '7C103' set MESSAGE_TEXT = 'REMOTE doesn''t exist or invalid';
    end if;
    -- ENDE INPUT CHECK

    call CALC.AUTO_PROC_LOG_INFO('Copying '||SCHEMA||'.'||TABLE||' from remote DB '||REMOTE||'.'||SCHEMA||'.'||TABLE);

    set is_TAPE = false;
    if EXISTS(select * from CALC.AUTO_TABLE_TAPES where NAME = SCHEMA) then
        set is_TAPE = true;
    end if;

    -- Ursprungstabelle/view in dieser DB ausfindig machen
    case
        when upper(right(TABLE,7)) = 'CURRENT' and is_TAPE then
            set REPLACABLE = 'CALC.'||CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(SCHEMA,TABLE);
         when upper(right(TABLE,7)) = 'CURRENT' and not is_TAPE then
            set REPLACABLE = 'STG.'||CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(SCHEMA,TABLE);
        else
            set REPLACABLE = SCHEMA||'.'||CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT(SCHEMA,TABLE);
    end case;

    call CALC.AUTO_PROC_LOG_DEBUG('replacing '||REPLACABLE);

    -- Baucode für die Tabelle bestimmen und Ursprungstabelle/view mit Namen der remote Tabelle ersetzen
    set code = (
        select
            replace(
                CALC.AUTO_FUNC_GET_BUILD_CODE(TABSCHEMA,SCHEMA,TABNAME, TRUE),
                REPLACABLE,
                REMOTE ||'.' || SCHEMA || '.' || TABNAME
            )  as CODE
        from CALC.AUTO_TABLE_TARGETS where TABNAME = TABLE limit 1
    );
    if code is NULL then
        signal SQLSTATE '7C104' set MESSAGE_TEXT = 'No Buildcode for table found';
    end if;
    -- ausführen
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(code,'  ');
    --call CALC.AUTO_PROC_LOG_INFO(code);

    call CALC.AUTO_PROC_LOG_INFO('Finished copying '||SCHEMA||'.'||TABLE||' from remote DB '||REMOTE||'.'||SCHEMA||'.'||TABLE);
END
&&
