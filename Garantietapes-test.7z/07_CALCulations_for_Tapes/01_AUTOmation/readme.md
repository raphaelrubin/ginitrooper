## AUTOmation

Dieser Ordner beinhaltet den Code, der mit der Automatisierung der Tapes zu tun hat.