/* CALC.AUTO_TABLE_MODES
 * Table to keep track of all the execution modes
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_MODES_UPDATE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_MODES');
create table CALC.AUTO_TABLE_MODES
(
	ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	NAME VARCHAR(32) not null,
	STAGE INT not null,
	useArchive BOOLEAN not null,
	rebuildAll BOOLEAN not null,
	DESCRIPTION VARCHAR(512),
	CREATED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) default USER,
	LAST_CHANGED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128) default USER,
	PRIMARY KEY(STAGE)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_MODES');
grant select on CALC.AUTO_TABLE_TARGET_TO_SOURCES to group NLB_MW_ADAP_S_GNI_TROOPER;

--#SET TERMINATOR &&
-- Trigger to monitor changes on a row
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_MODES_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_MODES
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&
