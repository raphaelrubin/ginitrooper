/* CALC.AUTO_TABLE_EXECUTION_PLAN
 * Hier gab es mal die Idee, alle Schritte der Automatisierung in einen Plan wegzuschreiben und dann am Stück auszuführen.
 * Momentan wird das nur zum Debuggen verwendet.
 */

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_EXECUTION_PLAN');
create table CALC.AUTO_TABLE_EXECUTION_PLAN(
    VERSION BIGINT,
    COMMAND CLOB(200K),
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_EXECUTION_PLAN');
comment on table CALC.AUTO_TABLE_EXECUTION_PLAN is 'Ausführungsplan für die SQL Queries (zur Zeit nicht genutzt)';

