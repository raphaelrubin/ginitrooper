/* CALC.AUTO_TABLE_CHECK_CUTOFFDATE
 * Tabelle um die Tests für einzelne Versionen der AMC Tape Ausführung zu tracken. Damit kann das mehrfache Checken der Aktualität von Tabellen vermieden werden.
 */

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_CHECK_CUTOFFDATE');
create table CALC.AUTO_TABLE_CHECK_CUTOFFDATE(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    TABSCHEMA VARCHAR(128) NOT NULL,     -- Schema wie in SYSCAT der Tabelle, die getestet wurde
    TABNAME VARCHAR(128) NOT NULL,       -- Tabellenname wie in SYSCAT der Tabelle, die getestet wurde
    CUT_OFF_DATE DATE,                  -- Cut off date für das AMC neu gebaut wurde
    VERSION BIGINT NOT NULL,            -- Version der Ausführung
    PASSED BOOLEAN,                  -- wurde der Test bestanden (das Cut off date gefunden)?
    MESSAGE VARCHAR(128),               -- Fehlernachricht
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_CHECK_CUTOFFDATE');
comment on table CALC.AUTO_TABLE_CHECK_CUTOFFDATE is 'Ergebnis der Cut Off Dates Checks - um Wiederholungen der Tests in CALC.AUTO_PROC_CHECK_REQUIREMENTS zu vermeiden';


call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_TMP_CHECK_CUTOFFDATE');
create table CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    TABSCHEMA VARCHAR(128) NOT NULL,     -- Schema wie in SYSCAT der Tabelle, die getestet wurde
    TABNAME VARCHAR(128) NOT NULL,       -- Tabellenname wie in SYSCAT der Tabelle, die getestet wurde
    CUT_OFF_DATE DATE,                  -- Cut off date für das AMC neu gebaut wurde
    VERSION BIGINT NOT NULL,            -- Version der Ausführung
    ERROR_MESSAGE VARCHAR(128) NOT NULL,                  -- Fehlermeldung
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_TMP_CHECK_CUTOFFDATE');
comment on table CALC.AUTO_TABLE_TMP_CHECK_CUTOFFDATE is 'temporärer Speicher für das letzte Ergebnis des CUT_OFF_DATE checks';

