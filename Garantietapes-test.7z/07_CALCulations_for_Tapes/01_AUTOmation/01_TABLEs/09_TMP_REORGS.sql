call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_TMP_REORG');
create table CALC.AUTO_TABLE_TMP_REORG
(
    ID              BIGINT        not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
    ADMIN_CMD_QUERY VARCHAR(2048) not NULL
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_TMP_REORG');
