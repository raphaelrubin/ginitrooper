/* CALC.AUTO_TABLE_LOG
 *
 * Diese Tabelle logged Meldungen in unterscheidlichen Leveln. Wird befüllt durch CALC.AUTO_PROC_LOG
 *
 * @column: ID BIGINT not NULL,             Identifikationsnummer der Zeile
 * @column: LEVEL VARCHAR(8) not NULL,      Level der Fehlermeldung (DEBUG/INFO/WARNING/ERROR)
 * @column: MESSAGE CLOB(200k),             Nachricht, die geloggt werden soll
 * @column: CREATED_AT TIMESTAMP,           Zeile wurde erstellt am (automatisch)
 * @column: CREATED_BY VARCHAR(128),        Zeile wurde erstellt von (automatisch)
 *
 */

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_LOG');
create table CALC.AUTO_TABLE_LOG(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    LEVEL VARCHAR(8) NOT NULL,                  -- Level der Fehlermeldung (DEBUG/INFO/WARNING/ERROR)
    MESSAGE CLOB(200k),                  -- Fehlermeldung
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(ID)
);
comment on table CALC.AUTO_TABLE_LOG is 'Log für die Prozeduren, welche automatisch Tapes bauen';
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_LOG');

