/* CALC.AUTO_TABLE_GROUPS
 * Table to keep track of all the groups and contained tables
 * ACHTUNG! Diese tabelle enthällt nur die Gruppen. Jedes Tape hat eine eigene Zuordnung Gruppe->Tabellen
 */
--Kommentar damit die CI die Tabelle neu baut, da sie Probleme beim Test bereitet.
-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_AGR;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_AMC;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_AMA;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_BGA;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_FKW;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_KOM;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_NSA;
drop trigger CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_SFK;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_AGR;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_AMC;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_AMA;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_BGA;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_FKW;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_KOM;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_NSA;
drop trigger CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_SFK;

-- TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_GROUPS');
create table CALC.AUTO_TABLE_GROUPS
(
	ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	GROUPNAME VARCHAR(128) not null,
	DESCRIPTION VARCHAR(1024),
	CREATED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) default USER,
	LAST_CHANGED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128) default USER,
    PRIMARY KEY(GROUPNAME)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_GROUPS');

------------------------------------------------------------------------------------------------------------------------

-- TRIGGER BEFORE UPDATE erstellen
--#SET TERMINATOR &&
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_GROUPS_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_GROUPS
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&
------------------------------------------------------------------------------------------------------------------------

-- CI START FOR ALL TAPES
--#SET TERMINATOR &&
-- TRIGGER BEFORE PK UPDATE erstellen
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_GROUPS_UPDATE_GROUPNAME_TRIGGER_AMC
    NO CASCADE BEFORE UPDATE of GROUPNAME
    ON CALC.AUTO_TABLE_GROUPS
    REFERENCING OLD AS OROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key AMC GROUPNAME
     IF EXISTS (select * from AMC.AUTO_TABLE_GROUPS where GROUPNAME = OROW.GROUPNAME) THEN
         SET ERROR_MESSAGE = 'Groupname '||OROW.GROUPNAME||' still in use in AMC.';
         SIGNAL SQLSTATE '73504' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------


-- TRIGGER BEFORE DELETE erstellen
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_GROUPS_DELETE_TRIGGER_AMC
    NO CASCADE BEFORE DELETE
    ON CALC.AUTO_TABLE_GROUPS
    REFERENCING OLD AS OROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key AMC GROUPNAME
     IF EXISTS (select * from AMC.AUTO_TABLE_GROUPS where GROUPNAME = OROW.GROUPNAME) THEN
         SET ERROR_MESSAGE = 'Groupname '||OROW.GROUPNAME||' still in use in AMC.';
         SIGNAL SQLSTATE '73504' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------

-- CI END FOR ALL TAPES
