/* CALC.AUTO_TABLE_TAPES
 * Table to keep track of all the different Tapes (Schema)
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_TAPES_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_TAPES_INSERT_TRIGGER;
drop trigger CALC.AUTO_TABLE_TAPES_UPDATE_NAME_TRIGGER;
drop trigger CALC.AUTO_TABLE_TAPES_DELETE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_TAPES');
create table CALC.AUTO_TABLE_TAPES
(
	ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	NAME VARCHAR(8) not null,   -- Tapename identical to the SCHEMANAME
	DESCRIPTION VARCHAR(512),   -- Text Beschreibung des Tapes
	IS_ACTIVE BOOLEAN DEFAULT FALSE,    -- Wird dieses Tape gerade von der Automatisierung verwendet? (Es kann immer nur ein Tape zu Zeit gebaut werden)
	INCLUDE_PRIVATE_CLIENTS BOOLEAN DEFAULT FALSE, -- Sind privatkunden in diesem Tape erlaubt?
	INCLUDE_ALL_DERIVATIVES_BY_DEFAULT BOOLEAN DEFAULT FALSE, -- Sollen alle Derivate und Kunden mit Derivaten automatisch ins Tape aufgenommen werden?
	CREATED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) default USER,
	LAST_CHANGED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128) default USER,
	PRIMARY KEY(NAME)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_TAPES');
comment on table CALC.AUTO_TABLE_TAPES is 'Liste aller Tapes.';


--#SET TERMINATOR &&

create or replace trigger CALC.AUTO_TABLE_TAPES_INSERT_TRIGGER
    before insert
    on CALC.AUTO_TABLE_TAPES
    referencing NEW as NEW_TABNAME
    for each row mode DB2SQL
begin
    atomic
    declare ERROR_MESSAGE VARCHAR(70);
    if not EXISTS(select * from SYSCAT.SCHEMATA where SCHEMANAME = NEW_TABNAME.NAME) then
        set ERROR_MESSAGE = 'Invalid NAME ' || COALESCE(NEW_TABNAME.NAME,'') || '.';
        signal SQLSTATE '73513' set MESSAGE_TEXT = ERROR_MESSAGE;

    end if;
end
&&

-- Trigger to monitor changes on a row
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TAPES_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_TAPES
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&

-- TRIGGER BEFORE PK UPDATE erstellen
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TAPES_UPDATE_NAME_TRIGGER
    NO CASCADE BEFORE UPDATE of NAME
    ON CALC.AUTO_TABLE_TAPES
    REFERENCING OLD AS OROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key VALIDATIONS.TAPENAME
     IF EXISTS (select * from CALC.AUTO_TABLE_VALIDATIONS where TAPENAME = OROW.NAME) THEN
         SET ERROR_MESSAGE = 'Tape '||OROW.NAME||' still in use in VALIDATIONS (CALC.AUTO_TABLE_VALIDATIONS)';
         SIGNAL SQLSTATE '73504' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------

-- TRIGGER BEFORE DELETE erstellen
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TAPES_DELETE_TRIGGER
    NO CASCADE BEFORE DELETE
    ON CALC.AUTO_TABLE_TAPES
    REFERENCING OLD AS OROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key VALIDATIONS.TAPENAME
     IF EXISTS (select * from CALC.AUTO_TABLE_VALIDATIONS where TAPENAME = OROW.NAME) THEN
         SET ERROR_MESSAGE = 'Tape '||OROW.NAME||' still in use in VALIDATIONS (CALC.AUTO_TABLE_VALIDATIONS)';
         SIGNAL SQLSTATE '73504' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------

--#SET TERMINATOR ;
