/* CALC.AUTO_TABLE_CHECK_BUILD
 * Tabelle um das Bauen eizelner Tabellen für einzelne Versionen der AMC Tape Ausführung zu tracken. Damit kann das mehrfache Bauen von Tabellen vermieden werden.
 */

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_CHECK_BUILD');
create table CALC.AUTO_TABLE_CHECK_BUILD(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    TABSCHEMA VARCHAR(128) NOT NULL,     -- Schema wie in SYSCAT der Tabelle, die getestet wurde
    TABNAME VARCHAR(128) NOT NULL,       -- Tabellenname wie in SYSCAT der Tabelle, die getestet wurde
    CUT_OFF_DATE DATE,                  -- Cut off date für das die tabelle neu gebaut wurde
    VERSION BIGINT NOT NULL,            -- Version der Ausführung
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_CHECK_BUILD');

comment on table CALC.AUTO_TABLE_CHECK_BUILD is 'In dieser Tabelle wird geloggt, wann welche Tabelle für welchen Stichtag neu gebaut wurde. Dies vermeidet, dass Tabellen mehrfach neu gebaut werden.';
