/* CALC.AUTO_TABLE_RELEVANT_PROCEDURES
 * Table to keep track of the procedure calls that make sense at specific times of the month
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_RELEVANT_PROCEDURES_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_RELEVANT_PROCEDURES_INSERT_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_RELEVANT_PROCEDURES');
create table CALC.AUTO_TABLE_RELEVANT_PROCEDURES
(
	ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	CODE VARCHAR(2048) not null,
	DESCRIPTION VARCHAR(1024) not null,
	RELEVANT_FROM_DAY_OF_MONTH INT not null,
	RELEVANT_UNTIL_DAY_OF_MONTH INT not null,
	CREATED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) default USER,
	LAST_CHANGED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128) default USER,
	PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_RELEVANT_PROCEDURES');
comment on table CALC.AUTO_TABLE_RELEVANT_PROCEDURES is 'Definition aller Prozeduraufrufe die zu einem bestimmten Zeitpunkt im Monat relevant sind.';


--#SET TERMINATOR &&
-- Trigger to monitor changes on a row
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_RELEVANT_PROCEDURES_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_RELEVANT_PROCEDURES
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&

-- Trigger to check Tablenames since SYSCAT cannot be referenced in a foreign key
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_RELEVANT_PROCEDURES_INSERT_TRIGGER
     AFTER INSERT ON CALC.AUTO_TABLE_RELEVANT_PROCEDURES
     REFERENCING NEW AS NEW_TABNAME
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     IF NOT RELEVANT_FROM_DAY_OF_MONTH between 1 and 31 THEN
         SET ERROR_MESSAGE = 'Invalid RELEVANT_FROM_DAY_OF_MONTH. Must be between 1 and 31.';
         SIGNAL SQLSTATE '73514' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
     IF NOT RELEVANT_UNTIL_DAY_OF_MONTH between 1 and 31 THEN
         SET ERROR_MESSAGE = 'Invalid RELEVANT_UNTIL_DAY_OF_MONTH. Must be between 1 and 31.';
         SIGNAL SQLSTATE '73514' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&




-- insert into CALC.AUTO_TABLE_RELEVANT_PROCEDURES (CODE,DESCRIPTION,RELEVANT_FROM_DAY_OF_MONTH,RELEVANT_UNTIL_DAY_OF_MONTH) values (
-- '-- AMC Tape auswählen
-- call CALC.DO_SWITCH_TO_TAPE(''AMC'');
-- -- Automatisierung ausführen
-- call CALC.DO_BUILD_A_GROUP(''FACILITY'',''{$COD}'',''SPOT'');',
-- 'Baue die FACILITY Tabellen für den neuen Stichtag mit SPOT Daten.',1,3);
--
-- insert into CALC.AUTO_TABLE_RELEVANT_PROCEDURES (CODE,DESCRIPTION,RELEVANT_FROM_DAY_OF_MONTH,RELEVANT_UNTIL_DAY_OF_MONTH) values (
-- '-- AMC Tape auswählen
-- call CALC.DO_SWITCH_TO_TAPE(''AMC'');
-- -- Automatisierung ausführen
-- call CALC.DO_BUILD_A_GROUP(''BESICHERUNG_FULL'',''{$COD}'',''SPOT+IWHS'');',
-- 'Baue die Tabellen für den neuen Stichtag mit SPOT und IWHS Daten.',2,8);
--
-- insert into CALC.AUTO_TABLE_RELEVANT_PROCEDURES (CODE,DESCRIPTION,RELEVANT_FROM_DAY_OF_MONTH,RELEVANT_UNTIL_DAY_OF_MONTH) values (
-- '-- AMC Tape auswählen
-- call CALC.DO_SWITCH_TO_TAPE(''AMC'');
-- -- Automatisierung ausführen
-- call CALC.DO_BUILD_A_GROUP(''ALL'',''{$COD}'',''KR'');',
-- 'Baue die Tabellen für den neuen Stichtag mit SPOT, IWHS, CMS und KR Daten.',8,14);
--
-- insert into CALC.AUTO_TABLE_RELEVANT_PROCEDURES (CODE,DESCRIPTION,RELEVANT_FROM_DAY_OF_MONTH,RELEVANT_UNTIL_DAY_OF_MONTH) values (
-- '-- AMC Tape auswählen
-- call CALC.DO_SWITCH_TO_TAPE(''AMC'');
-- -- Automatisierung ausführen
-- call CALC.DO_BUILD_A_GROUP(''ALL'',''{$COD}'',''FINAL'');',
-- 'Einen Durchlauf basierend auf allen Quelldaten außer BW berechnen',9,20);
--
-- insert into CALC.AUTO_TABLE_RELEVANT_PROCEDURES (CODE,DESCRIPTION,RELEVANT_FROM_DAY_OF_MONTH,RELEVANT_UNTIL_DAY_OF_MONTH) values (
-- '-- AMC Tape auswählen
-- call CALC.DO_SWITCH_TO_TAPE(''AMC'');
-- -- Automatisierung ausführen
-- call CALC.DO_BUILD_A_GROUP(''ALL'',''{$COD}'',''FINAL WITH BW'');',
-- 'Einen finalen Durchlauf basierend auf allen Quelldaten berechnen',15,31);