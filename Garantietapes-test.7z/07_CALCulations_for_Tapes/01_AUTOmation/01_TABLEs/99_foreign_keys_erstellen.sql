-- Alle Foreign keys hier erstellen
-- Beispiel:
-- alter table SCHEMAA.TABELLENNAMEA add constraint FK_NAME foreign key (SPALTENNAMEA) references SCHEMAB.TABELLENNAMEB(SPALTENNAMEB)

