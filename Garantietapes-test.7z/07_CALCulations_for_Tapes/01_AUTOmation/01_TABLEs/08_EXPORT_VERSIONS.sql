/* CALC.AUTO_TABLE_EXPORT_VERSIONS
 * Table to keep track of Export versions
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_EXPORT_VERSIONS_UPDATE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_EXPORT_VERSIONS');
create table CALC.AUTO_TABLE_EXPORT_VERSIONS
(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    TAPENAME VARCHAR(8) NOT NULL,                           -- Name des Tapes für das Exportiert wurde
    TABNAME VARCHAR(128) NOT NULL,                          -- Tabellenname wie in SYSCAT
    GROUPNAME VARCHAR(128) NOT NULL,                        -- Nutzer definierter Gruppenname
    CUT_OFF_DATE DATE NOT NULL,                             -- Stichtag
    VERSION BIGINT NOT NULL,                                -- Export Version
    EXPORTNAME_FULL VARCHAR(256),                           -- Name der Exportdatei (mit Stichtag und Version)
    EXPORT_QUERY VARCHAR(512),                              -- Query für den Export handler
    Completed BOOLEAN DEFAULT FALSE,                        -- Wurde die Prozedur abgeschlossen?
    SUCCESS BOOLEAN DEFAULT NULL,                           -- Wurde die Prozedur erfolgreich abgeschlossen?
    GETOETETE_ALPAKA INT DEFAULT 0 NOT NULL,                -- Getötete Alpaka für Sven
    STERNE INT DEFAULT 10 NOT NULL,                         -- Sterne für Sophie
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    LAST_CHANGED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,    --ON UPDATE CURRENT_TIMESTAMP
    LAST_CHANGED_BY VARCHAR(128) DEFAULT USER,                --ON UPDATE CURRENT_USER
    PRIMARY KEY(ID)
    --FOREIGN KEY TABNAME (TABNAME) REFERENCES SYSCAT.TABLES ON DELETE NO ACTION
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_EXPORT_VERSIONS');


--#SET TERMINATOR &&
-- Trigger to monitor changes on a row
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_EXPORT_VERSIONS_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_EXPORT_VERSIONS
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&