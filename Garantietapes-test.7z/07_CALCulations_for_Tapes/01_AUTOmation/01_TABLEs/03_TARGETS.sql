/* CALC.AUTO_TABLE_TARGETS
 * Tabelle, um die zu bauenden Tabellen der AMC Tapes zu definieren.
 *
 * @column ID BIGINT NOT NULL                                   Identifikationsnummer der Zeile
 * @column TABSCHEMA VARCHAR(128) NOT NULL                      Schema der Tabelle wie in SYSCAT
 * @column TABNAME VARCHAR(128) NOT NULL,                       Tabellenname der Tabelle wie in SYSCAT
 * @column TYPE VARCHAR(1),                                     Tabelle (T)/ View (V)/ MQT (S) (automatisch)
 * @column IS_AUTOMATEABLE BOOLEAN NOT NULL,                    Kann die Tabelle neu gebaut werden (FALSE für
 *                                                                  Rohtabellen)
 * @column DO_TRUNCATE_BEFORE_BUILD BOOLEAN,                    Soll diese Tabelle getruncated werden, bevor sie neu
 *                                                                  gebaut wird? (TRUE für die meisten Current Tabellen,
 *                                                                  FALSE für !ALLE! Archive und für MQTs)
 * @column BUILDCODE CLOB(204800),                              Code zum neu Bauen der Tabelle
 * @column RECREATECODE CLOB(204800),                           Code zum Wiederherstellen der Tabelle aus dem Archiv
 * @column CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,      Zeile wurde erstellt am (automatisch)
 * @column CREATED_BY VARCHAR(128) DEFAULT USER,                Zeile wurde erstellt von (automatisch)
 * @column LAST_CHANGED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP, Zeile wurde zuletzt geändert am (automatisch)
 * @column LAST_CHANGED_BY VARCHAR(128) DEFAULT USER,           Zeile wurde zuletzt geändert von (automatisch)
 *
 * @throws SQLCODE 438, SQLSTATE 7C110, Duplicate table name *. Jede Tabelle darf nur einmal in AMC.AUTO_TABLE_TARGETS
 *                                                                  vorkommen. Diese Regel wurde hier gebrochen.
 * @throws SQLCODE 438, SQLSTATE 7C101, Invalid table name *.   Tabelle ist nicht in der SYSCAT
 * @throws SQLCODE 438, SQLSTATE 7C120, Invalid column name * in *. COLNAME_CUT_OFF_DATE ist nicht in der Tabelle
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_TARGETS_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_INSERT_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_TABNAME_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_TABSCHEMA_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_UPDATE_TABSCHEMA_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_UPDATE_TABNAME_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGETS_DELETE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_TARGETS');
create table CALC.AUTO_TABLE_TARGETS
(
	ID BIGINT                           not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	TABSCHEMA VARCHAR(128)              not NULL,
	TABNAME VARCHAR(128)                not NULL,
	COLNAME_CUT_OFF_DATE VARCHAR(128),                          -- Name der COD Spalte wie in SYSCAT
	TYPE VARCHAR(1)                 default 'T' not NULL,
	IS_AUTOMATEABLE BOOLEAN             not NULL,
	DO_TRUNCATE_BEFORE_BUILD BOOLEAN,
	BUILDCODE CLOB(204800),
	BUILD_VIEW_SCHEMA VARCHAR(128) DEFAULT 'CALC', -- SCHEMA der View aus der die Tabelle befüllt wird
	RECREATECODE CLOB(204800),
	CREATED_AT TIMESTAMP(6)         default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128)         default USER,
	LAST_CHANGED_AT TIMESTAMP(6)    default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128)    default USER,
    CONSTRAINT TABLENAME PRIMARY KEY (TABSCHEMA,TABNAME)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_TARGETS');
grant select on CALC.AUTO_TABLE_TARGETS to group NLB_MW_ADAP_S_GNI_TROOPER;

-- START TRIGGER DEFINITIONEN
--#SET TERMINATOR &&
-- Trigger to monitor changes on a row
create or replace trigger CALC.AUTO_TABLE_TARGETS_UPDATE_TRIGGER
    no cascade before update
    on CALC.AUTO_TABLE_TARGETS
    referencing NEW as NROW
    for each row mode DB2SQL
begin
    atomic
    set
        NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
        NROW.LAST_CHANGED_BY = USER,
        NROW.TYPE = (select TYPE
                     from SYSCAT.TABLES
                     where TABNAME = NROW.TABNAME
                       and TABSCHEMA = NROW.TABSCHEMA),
        NROW.COLNAME_CUT_OFF_DATE = (select COLNAME from SYSCAT.COLUMNS where TABSCHEMA = NROW.TABSCHEMA and TABNAME = NROW.TABNAME and upper(COLNAME) in ('CUTOFFDATE','CUT_OFF_DATE','STICHTAG','BESTANDSDATUM','DATE_FOR_AUTOMATION') order by COLNAME DESC limit 1);
end
&&

-- Trigger to check Tablenames on INSERT since SYSCAT cannot be referenced in a foreign key
create or replace trigger CALC.AUTO_TABLE_TARGETS_INSERT_TRIGGER
    before insert
    on CALC.AUTO_TABLE_TARGETS
    referencing NEW as NEW_TABNAME
    for each row mode DB2SQL
begin
    atomic
    declare ERROR_MESSAGE VARCHAR(70);
    if not EXISTS(
            select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA) then
        set ERROR_MESSAGE = 'Invalid table name ' || NEW_TABNAME.TABSCHEMA || '.' || NEW_TABNAME.TABNAME || '.';
        signal SQLSTATE '7C102' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    if EXISTS(select *
              from CALC.AUTO_TABLE_TARGETS
              where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA) then
        set ERROR_MESSAGE = 'Duplicate table name ' || NEW_TABNAME.TABSCHEMA || '.' || NEW_TABNAME.TABNAME || '.';
        signal SQLSTATE '7C110' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- check COLNAME of CUT_OFF_DATE
    if NEW_TABNAME.COLNAME_CUT_OFF_DATE is not NULL and not EXISTS (select * from SYSCAT.COLUMNS where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA and COLNAME = NEW_TABNAME.COLNAME_CUT_OFF_DATE) then
        set ERROR_MESSAGE = 'Invalid column name '||NEW_TABNAME.COLNAME_CUT_OFF_DATE||' in '||NEW_TABNAME.TABSCHEMA||'.'||NEW_TABNAME.TABNAME||'.';
        signal SQLSTATE '7C120' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    set NEW_TABNAME.TYPE =
            (select TYPE from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA);
end
&&

-- Trigger to check TABNAME on UPDATE since SYSCAT cannot be referenced in a foreign key
create or replace trigger CALC.AUTO_TABLE_TARGETS_TABNAME_UPDATE_TRIGGER
    after update of TABNAME
    on CALC.AUTO_TABLE_TARGETS
    referencing NEW as NEW_TABNAME
    for each row mode DB2SQL
begin
    atomic
    declare ERROR_MESSAGE VARCHAR(70);
    if not EXISTS(
            select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA) then
        set ERROR_MESSAGE = 'Invalid table name ' || NEW_TABNAME.TABSCHEMA || '.' || NEW_TABNAME.TABNAME || '.';
        signal SQLSTATE '7C102' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
end
&&

-- Trigger to check TABSCHEMA on UPDATE since SYSCAT cannot be referenced in a foreign key
create or replace trigger CALC.AUTO_TABLE_TARGETS_TABSCHEMA_UPDATE_TRIGGER
    after update of TABSCHEMA
    on CALC.AUTO_TABLE_TARGETS
    referencing NEW as NEW_TABNAME
    for each row mode DB2SQL
begin
    atomic
    declare ERROR_MESSAGE VARCHAR(70);
    if not EXISTS(
            select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME and TABSCHEMA = NEW_TABNAME.TABSCHEMA) then
        set ERROR_MESSAGE = 'Invalid table name ' || NEW_TABNAME.TABSCHEMA || '.' || NEW_TABNAME.TABNAME || '.';
        signal SQLSTATE '7C102' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
end
&&

-- TRIGGER BEFORE PK UPDATE erstellen
------------------------------------------------------------------------------------------------------------------------
--CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TARGETS_UPDATE_TABSCHEMA_TRIGGER
--    NO CASCADE BEFORE UPDATE of TABSCHEMA
--    ON CALC.AUTO_TABLE_TARGETS
--     REFERENCING OLD AS OROW
--      FOR EACH ROW MODE DB2SQL
--     BEGIN ATOMIC
--      declare ERROR_MESSAGE VARCHAR(70);
--      -- Foreign key TABNAME_SOURCE
--      IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_SOURCE = OROW.TABNAME and TABSCHEMA_SOURCE = OROW.TABSCHEMA) THEN
--          SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
--          SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
--      END IF;
--      -- Foreign key TABNAME_TARGET
--      IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_TARGET = OROW.TABNAME and TABSCHEMA_TARGET = OROW.TABSCHEMA) THEN
--          SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
--          SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
--      END IF;
--     END
-- &&
------------------------------------------------------------------------------------------------------------------------
-- CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TARGETS_UPDATE_TABNAME_TRIGGER
--     NO CASCADE BEFORE UPDATE of TABNAME
--     ON CALC.AUTO_TABLE_TARGETS
--     REFERENCING OLD AS OROW
--      FOR EACH ROW MODE DB2SQL
--     BEGIN ATOMIC
--      declare ERROR_MESSAGE VARCHAR(70);
--      -- Foreign key TABNAME_SOURCE
--      IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_SOURCE = OROW.TABNAME and TABSCHEMA_SOURCE = OROW.TABSCHEMA) THEN
--          SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
--          SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
--      END IF;
--      -- Foreign key TABNAME_TARGET
--      IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_TARGET = OROW.TABNAME and TABSCHEMA_TARGET = OROW.TABSCHEMA) THEN
--          SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
--          SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
--      END IF;
--     END
-- &&
------------------------------------------------------------------------------------------------------------------------

-- TRIGGER BEFORE DELETE erstellen
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TARGETS_DELETE_TRIGGER
    NO CASCADE BEFORE DELETE
    ON CALC.AUTO_TABLE_TARGETS
    REFERENCING OLD AS OROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key TABNAME_SOURCE
     IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_SOURCE = OROW.TABNAME and TABSCHEMA_SOURCE = OROW.TABSCHEMA) THEN
         SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
         SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
     -- Foreign key TABNAME_TARGET
     IF EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABNAME_TARGET = OROW.TABNAME and TABSCHEMA_TARGET = OROW.TABSCHEMA) THEN
         SET ERROR_MESSAGE = 'Table '||OROW.TABSCHEMA||'.'||OROW.TABNAME||' still in use in TARGET_TO_SOURCES.';
         SIGNAL SQLSTATE '7C130' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------
--#SET TERMINATOR ;
-- ENDE TRIGGER DEFINITIONEN


