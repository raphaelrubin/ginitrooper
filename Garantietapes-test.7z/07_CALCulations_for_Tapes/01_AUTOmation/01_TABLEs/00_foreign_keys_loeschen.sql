-- Alle Foreign keys hier löschen
-- Beispiel:
-- alter table SCHEMA.TABELLENNAME drop foreign key (FK_NAME)

