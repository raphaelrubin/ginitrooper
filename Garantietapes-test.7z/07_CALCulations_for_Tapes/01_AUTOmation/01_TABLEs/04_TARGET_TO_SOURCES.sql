/* CALC.AUTO_TABLE_TARGET_TO_SOURCES
 * Tabelle, um die Ursprungstabellen der AMC Tape Tabellen zu definieren. Jede Target Tabelle kann (uu. über Views) auf mehreren Source Tabellen basieren.
 *
 * @column ID BIGINT NOT NULL                                   Identifikationsnummer der Zeile
 * @column TABSCHEMA_TARGET VARCHAR(128) NOT NULL               Schema der Target-Tabelle wie in SYSCAT
 * @column TABNAME_TARGET VARCHAR(128) NOT NULL,                Tabellenname der Target-Tabelle wie in SYSCAT
 * @column TABSCHEMA_SOURCE VARCHAR(128) NOT NULL,              Schema der Source-Tabelle wie in SYSCAT
 * @column TABNAME_SOURCE VARCHAR(128) NOT NULL,                Tabellenname der Source-Tabelle wie in SYSCAT
 * @column CUT_OFF_DATE_SOURCE VARCHAR(128),                    Name der Stichtag bestimmenden Spalte in der
 *                                                                  Source-Tabelle wie in SYSCAT.COLUMNS
 * @column REQUIRED BOOLEAN NOT NULL,                           Muss die Source-Tabelle das aktuelle Cut Off Date haben,
 *                                                                  um die finale Version der target-Tabelle zu bauen?
 * @column STAGE_REQUIRED_AT INT NOT NULL,                      Ab welcher Stufe Ist diese SOURCE mit neuem Cut Off Date
 *                                                                  notwendig um TARGET zu bauen?
 * @column CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,      Zeile wurde erstellt am (automatisch)
 * @column CREATED_BY VARCHAR(128) DEFAULT USER,                Zeile wurde erstellt von (automatisch)
 * @column LAST_CHANGED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP, Zeile wurde zuletzt geändert am (automatisch)
 * @column LAST_CHANGED_BY VARCHAR(128) DEFAULT USER,           Zeile wurde zuletzt geändert von (automatisch)
 *
 * @throws SQLCODE 438, SQLSTATE 7C210, No duplicate entry in
 *                                      AMC.AUTO_TABLE_TARGET_TO_SOURCES allowed.   Jede Zeile darf nur einmal in
 *                                                                                  AMC.AUTO_TABLE_TARGET_TO_SOURCES
 *                                                                                  vorkommen. Diese Regel wurde hier
 *                                                                                  gebrochen.
 * @throws SQLCODE 438, SQLSTATE 7C201/2/3/4, Invalid table name *.                 Entweder die Source-Tabelle oder die
 *                                                                                  Target-Tabelle ist keine gültige
 *                                                                                  Tabelle.
 * @throws SQLCODE 438, SQLSTATE 7C231, VALID_UNTIL must be <= VALID_FROM           Anfangsdatum muss kleiner als
 *                                                                                  Enddatum sein

 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_UPDATE_TRIGGER;
drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_INSERT_TRIGGER;
--drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABNAME_TARGET_UPDATE_TRIGGER;
--drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABSCHEMA_TARGET_UPDATE_TRIGGER;
--drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABNAME_SOURCE_UPDATE_TRIGGER;
--drop trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABSCHEMA_SOURCE_UPDATE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_TARGET_TO_SOURCES');
create table CALC.AUTO_TABLE_TARGET_TO_SOURCES(
    ID BIGINT                       not NULL generated always as IDENTITY (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
    TABSCHEMA_TARGET VARCHAR(128)   not NULL,               -- Schema wie in SYSCAT
    TABNAME_TARGET VARCHAR(128)     not NULL,               -- Tabellenname wie in SYSCAT
    TABSCHEMA_SOURCE VARCHAR(128)   not NULL,               -- Schema wie in SYSCAT
    TABNAME_SOURCE VARCHAR(128)     not NULL,               -- Tabellenname wie in SYSCAT
    REQUIRED BOOLEAN                not NULL,               -- Ist diese SOURCE mit neuem Cut Off Date notwendig um TARGET zu bauen?
    STAGE_REQUIRED_AT INT           not NULL,               -- Ab welcher Stufe Ist diese SOURCE mit neuem Cut Off Date notwendig um TARGET zu bauen?
    STAGE_SOURCE VARCHAR(32)        not NULL,               -- Ab welcher Stufe Ist diese SOURCE mit neuem Cut Off Date notwendig um TARGET zu bauen?
    VALID_FROM DATE                 default NULL,           -- Stichtag, ab welchem diese Beziehung gültig ist
    VALID_UNTIL DATE                default NULL,           -- Stichtag, bis zu welchem diese Beziehung gültig ist
    CREATED_AT TIMESTAMP            default CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128)         default USER,
    LAST_CHANGED_AT TIMESTAMP       default CURRENT_TIMESTAMP,  -- ON UPDATE CURRENT_TIMESTAMP
    LAST_CHANGED_BY VARCHAR(128)    default USER,               -- ON UPDATE CURRENT_USER
    PRIMARY KEY(ID)
    --CONSTRAINT FK_TABLENAME_TARGET FOREIGN KEY (TABSCHEMA_TARGET,TABNAME_TARGET) REFERENCES CALC.AUTO_TABLE_TARGETS(TABSCHEMA,TABNAME),
    --CONSTRAINT FK_TABLENAME_SOURCE FOREIGN KEY (TABSCHEMA_SOURCE,TABNAME_SOURCE) REFERENCES CALC.AUTO_TABLE_TARGETS(TABSCHEMA,TABNAME)
    --FOREIGN KEY(STAGE_REQUIRED_AT) REFERENCES AMC.AUTO_TABLE_MODES
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_TARGET_TO_SOURCES');


-- START TRIGGER DEFINITIONEN
--#SET TERMINATOR &&

-- BEFORE INSERT Trigger to check Tablenames since SYSCAT cannot be referenced in a foreign key
------------------------------------------------------------------------------------------------------------------------
create or replace trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_INSERT_TRIGGER
    before insert
    on CALC.AUTO_TABLE_TARGET_TO_SOURCES
    REFERENCING NEW AS NROW
    FOR EACH ROW MODE DB2SQL
BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key FK_TABLENAME_TARGET SYSCAT
    if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME_TARGET and TABSCHEMA = NROW.TABSCHEMA_TARGET) then
        set ERROR_MESSAGE = 'Invalid table name '||NROW.TABSCHEMA_TARGET||'.'||NROW.TABNAME_TARGET||'.';
        signal SQLSTATE '7C202' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- Foreign key FK_TABLENAME_SOURCE SYSCAT
    if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME_SOURCE and TABSCHEMA = NROW.TABSCHEMA_SOURCE) then
        set ERROR_MESSAGE = 'Invalid table name '||NROW.TABSCHEMA_SOURCE||'.'||NROW.TABNAME_SOURCE||'.';
        signal SQLSTATE '7C201' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- Foreign key FK_TABLENAME_SOURCE TARGETS
    IF NOT EXISTS (select * from CALC.AUTO_TABLE_TARGETS where (TABSCHEMA,TABNAME) = (case when NROW.TABSCHEMA_SOURCE = 'CALC' then 'CALC' when BUILD_VIEW_SCHEMA = 'CALC' then 'AMC' else NROW.TABSCHEMA_SOURCE end,NROW.TABNAME_SOURCE)) THEN
        SET ERROR_MESSAGE = 'Source Table '||NROW.TABSCHEMA_SOURCE||'.'||NROW.TABNAME_SOURCE||' not in TARGETS.';
        SIGNAL SQLSTATE '7C203' SET MESSAGE_TEXT = ERROR_MESSAGE;
    END IF;
    -- Foreign key FK_TABLENAME_TARGET TARGETS
    IF NOT EXISTS (select * from CALC.AUTO_TABLE_TARGETS where (TABSCHEMA,TABNAME) = (case when NROW.TABSCHEMA_TARGET = 'CALC' then 'CALC' when BUILD_VIEW_SCHEMA = 'CALC' then 'AMC' else NROW.TABSCHEMA_TARGET end,NROW.TABNAME_TARGET)) THEN
        SET ERROR_MESSAGE = 'Target Table '||NROW.TABSCHEMA_TARGET||'.'||NROW.TABNAME_TARGET||' not in TARGETS.';
        SIGNAL SQLSTATE '7C204' SET MESSAGE_TEXT = ERROR_MESSAGE;
    END IF;
     -- check if source table is in AUTO list of tables
    if VALID_FROM > VALID_UNTIL then
        set ERROR_MESSAGE = 'VALID_UNTIL must be <= VALID_FROM';
        signal SQLSTATE '7C231' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- check for duplicate
--     if EXISTS (
--         select T2S.*
--         from CALC.AUTO_TABLE_TARGET_TO_SOURCES as T2S
--         left join CALC.AUTO_TABLE_TARGETS as T on (T2S.TABSCHEMA_TARGET, T2S.TABNAME_TARGET) = (T.TABSCHEMA, T.TABNAME)
--         left join CALC.AUTO_TABLE_TARGETS as S on (T2S.TABSCHEMA_SOURCE, T2S.TABNAME_SOURCE) = (S.TABSCHEMA, S.TABNAME)
--         where (TABSCHEMA_SOURCE = NROW.TABSCHEMA_SOURCE or S.BUILD_VIEW_SCHEMA = 'CALC') and TABNAME_SOURCE = NROW.TABNAME_SOURCE
--           and (TABSCHEMA_TARGET = NROW.TABSCHEMA_TARGET or T.BUILD_VIEW_SCHEMA = 'CALC') and TABNAME_TARGET = NROW.TABNAME_TARGET
--           and not ( -- Es darf keine Überschneidung des Gültigkeitsbereiches vorliegen!
--                    (date(VALID_FROM) is NULL           and NROW.VALID_FROM > date(VALID_UNTIL))
--                 or (date(VALID_FROM) < NROW.VALID_FROM and NROW.VALID_FROM > date(VALID_UNTIL))
--                 or (NROW.VALID_FROM is NULL            and date(VALID_FROM) > NROW.VALID_UNTIL)
--                 or (NROW.VALID_FROM < date(VALID_FROM) and date(VALID_FROM) > NROW.VALID_UNTIL)
--                 or (date(VALID_FROM) is NULL           and date(NROW.VALID_FROM) is NULL)
--                 or (date(VALID_UNTIL) is NULL          and date(NROW.VALID_UNTIL) is NULL)
--             )
--        ) then
--         set ERROR_MESSAGE = 'Duplicate entry in CALC.AUTO_TABLE_TARGET_TO_SOURCES not allowed.';
--         signal SQLSTATE '7C210' set MESSAGE_TEXT = ERROR_MESSAGE;
--     end if;
END
&&
------------------------------------------------------------------------------------------------------------------------

-- BEFORE UPDATE Trigger to monitor changes on a row
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_TARGET_TO_SOURCES_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_TARGET_TO_SOURCES
    REFERENCING NEW AS NROW
    FOR EACH ROW MODE DB2SQL
BEGIN ATOMIC
    declare ERROR_MESSAGE VARCHAR(70);
    -- Foreign key FK_TABLENAME_TARGET SYSCAT
    if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME_TARGET and TABSCHEMA = NROW.TABSCHEMA_TARGET) then
        set ERROR_MESSAGE = 'Invalid table name '||NROW.TABSCHEMA_TARGET||'.'||NROW.TABNAME_TARGET||'.';
        signal SQLSTATE '7C202' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- Foreign key FK_TABLENAME_SOURCE SYSCAT
    if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME_SOURCE and TABSCHEMA = NROW.TABSCHEMA_SOURCE) then
        set ERROR_MESSAGE = 'Invalid table name '||NROW.TABSCHEMA_SOURCE||'.'||NROW.TABNAME_SOURCE||'.';
        signal SQLSTATE '7C201' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- Foreign key FK_TABLENAME_SOURCE TARGETS
    IF NOT EXISTS (select * from CALC.AUTO_TABLE_TARGETS where (TABSCHEMA,TABNAME) = (case when NROW.TABSCHEMA_SOURCE = 'CALC' then 'CALC' when BUILD_VIEW_SCHEMA = 'CALC' then 'AMC' else NROW.TABSCHEMA_SOURCE end,NROW.TABNAME_SOURCE)) THEN
        SET ERROR_MESSAGE = 'Source Table '||NROW.TABSCHEMA_SOURCE||'.'||NROW.TABNAME_SOURCE||' not in TARGETS.';
        SIGNAL SQLSTATE '7C203' SET MESSAGE_TEXT = ERROR_MESSAGE;
    END IF;
    -- Foreign key FK_TABLENAME_TARGET TARGETS
    IF NOT EXISTS (select * from CALC.AUTO_TABLE_TARGETS where (TABSCHEMA,TABNAME) = (case when NROW.TABSCHEMA_TARGET = 'CALC' then 'CALC' when BUILD_VIEW_SCHEMA = 'CALC' then 'AMC' else NROW.TABSCHEMA_TARGET end,NROW.TABNAME_TARGET)) THEN
        SET ERROR_MESSAGE = 'Target Table '||NROW.TABSCHEMA_TARGET||'.'||NROW.TABNAME_TARGET||' not in TARGETS.';
        SIGNAL SQLSTATE '7C204' SET MESSAGE_TEXT = ERROR_MESSAGE;
    END IF;
    -- check if source table is in AUTO list of tables
    if VALID_FROM > VALID_UNTIL then
        set ERROR_MESSAGE = 'VALID_UNTIL must be <= VALID_FROM';
        signal SQLSTATE '7C231' set MESSAGE_TEXT = ERROR_MESSAGE;
    end if;
    -- check for duplicate
--     if EXISTS (
--         select T2S.*
--         from CALC.AUTO_TABLE_TARGET_TO_SOURCES as T2S
--         left join CALC.AUTO_TABLE_TARGETS as T on (T2S.TABSCHEMA_TARGET, T2S.TABNAME_TARGET) = (T.TABSCHEMA, T.TABNAME)
--         left join CALC.AUTO_TABLE_TARGETS as S on (T2S.TABSCHEMA_SOURCE, T2S.TABNAME_SOURCE) = (S.TABSCHEMA, S.TABNAME)
--         where (TABSCHEMA_SOURCE = NROW.TABSCHEMA_SOURCE or S.BUILD_VIEW_SCHEMA = 'CALC') and TABNAME_SOURCE = NROW.TABNAME_SOURCE
--           and (TABSCHEMA_TARGET = NROW.TABSCHEMA_TARGET or T.BUILD_VIEW_SCHEMA = 'CALC') and TABNAME_TARGET = NROW.TABNAME_TARGET
--           and not ( -- Es darf keine Überschneidung des Gültigkeitsbereiches vorliegen!
--                    (date(VALID_FROM) is NULL           and NROW.VALID_FROM > date(VALID_UNTIL))
--                 or (date(VALID_FROM) < NROW.VALID_FROM and NROW.VALID_FROM > date(VALID_UNTIL))
--                 or (NROW.VALID_FROM is NULL            and date(VALID_FROM) > NROW.VALID_UNTIL)
--                 or (NROW.VALID_FROM < date(VALID_FROM) and date(VALID_FROM) > NROW.VALID_UNTIL)
--                 or (date(VALID_FROM) is NULL           and date(NROW.VALID_FROM) is NULL)
--                 or (date(VALID_UNTIL) is NULL          and date(NROW.VALID_UNTIL) is NULL)
--             )
--        ) then
--         set ERROR_MESSAGE = 'Duplicate entry in CALC.AUTO_TABLE_TARGET_TO_SOURCES not allowed.';
--         signal SQLSTATE '7C210' set MESSAGE_TEXT = ERROR_MESSAGE;
--     end if;
    -- update the Last Changed Fingerprint
    SET
        NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
        NROW.LAST_CHANGED_BY = USER;
END
&&
------------------------------------------------------------------------------------------------------------------------

-- -- Trigger to check TABNAME_TARGET on UPDATE since SYSCAT cannot be referenced in a foreign key
-- create or replace trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABNAME_TARGET_UPDATE_TRIGGER
--     before update of TABNAME_TARGET on CALC.AUTO_TABLE_TARGET_TO_SOURCES
--     referencing NEW as NEW_TABNAME
--     for each row mode DB2SQL
--     begin atomic
--         declare ERROR_MESSAGE VARCHAR(70);
--         if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME_TARGET and TABSCHEMA = NEW_TABNAME.TABSCHEMA_TARGET) then
--             set ERROR_MESSAGE = 'Invalid Tablename '||NEW_TABNAME.TABSCHEMA_TARGET||'.'||NEW_TABNAME.TABNAME_TARGET||'.';
--             SIGNAL SQLSTATE '73513' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--     end
-- &&
--
-- -- Trigger to check TABSCHEMA_TARGET on UPDATE since SYSCAT cannot be referenced in a foreign key
-- create or replace trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABSCHEMA_TARGET_UPDATE_TRIGGER
--     before update of TABSCHEMA_TARGET on CALC.AUTO_TABLE_TARGET_TO_SOURCES
--     referencing NEW as NEW_TABNAME
--     for each row mode DB2SQL
--     begin atomic
--         declare ERROR_MESSAGE VARCHAR(70);
--         if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME_TARGET and TABSCHEMA = NEW_TABNAME.TABSCHEMA_TARGET) then
--             set ERROR_MESSAGE = 'Invalid Tablename '||NEW_TABNAME.TABSCHEMA_TARGET||'.'||NEW_TABNAME.TABNAME_TARGET||'.';
--             SIGNAL SQLSTATE '73513' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--     end
-- &&
--
-- -- Trigger to check TABNAME_SOURCE on UPDATE since SYSCAT cannot be referenced in a foreign key
-- create or replace trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABNAME_SOURCE_UPDATE_TRIGGER
--     before update of TABNAME_SOURCE on CALC.AUTO_TABLE_TARGET_TO_SOURCES
--     referencing NEW as NEW_TABNAME
--     for each row mode DB2SQL
--     begin atomic
--         declare ERROR_MESSAGE VARCHAR(70);
--         if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME_SOURCE and TABSCHEMA = NEW_TABNAME.TABSCHEMA_SOURCE) then
--             set ERROR_MESSAGE = 'Invalid Tablename '||NEW_TABNAME.TABSCHEMA_SOURCE||'.'||NEW_TABNAME.TABNAME_SOURCE||'.';
--             SIGNAL SQLSTATE '73513' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--         if EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABSCHEMA_SOURCE = NEW_TABNAME.TABSCHEMA_SOURCE and TABNAME_SOURCE = NEW_TABNAME.TABNAME_SOURCE and TABSCHEMA_TARGET = NEW_TABNAME.TABSCHEMA_TARGET and TABNAME_TARGET = NEW_TABNAME.TABNAME_TARGET) then
--             set ERROR_MESSAGE = 'No duplicate entry in CALC.AUTO_TABLE_TARGET_TO_SOURCES allowed.';
--             signal SQLSTATE '73505' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--     end
-- &&
--
-- -- Trigger to check TABSCHEMA_SOURCE on UPDATE since SYSCAT cannot be referenced in a foreign key
-- create or replace trigger CALC.AUTO_TABLE_TARGET_TO_SOURCES_TABSCHEMA_SOURCE_UPDATE_TRIGGER
--     before update of TABSCHEMA_SOURCE on CALC.AUTO_TABLE_TARGET_TO_SOURCES
--     referencing NEW as NEW_TABNAME
--     for each row mode DB2SQL
--     begin atomic
--         declare ERROR_MESSAGE VARCHAR(70);
--         if not EXISTS (select * from SYSCAT.TABLES where TABNAME = NEW_TABNAME.TABNAME_SOURCE and TABSCHEMA = NEW_TABNAME.TABSCHEMA_SOURCE) then
--             set ERROR_MESSAGE = 'Invalid Tablename '||NEW_TABNAME.TABSCHEMA_SOURCE||'.'||NEW_TABNAME.TABNAME_SOURCE||'.';
--             SIGNAL SQLSTATE '73513' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--         if EXISTS (select * from CALC.AUTO_TABLE_TARGET_TO_SOURCES where TABSCHEMA_SOURCE = NEW_TABNAME.TABSCHEMA_SOURCE and TABNAME_SOURCE = NEW_TABNAME.TABNAME_SOURCE and TABSCHEMA_TARGET = NEW_TABNAME.TABSCHEMA_TARGET and TABNAME_TARGET = NEW_TABNAME.TABNAME_TARGET) then
--             set ERROR_MESSAGE = 'No duplicate entry in CALC.AUTO_TABLE_TARGET_TO_SOURCES allowed.';
--             signal SQLSTATE '73505' set MESSAGE_TEXT = ERROR_MESSAGE;
--         end if;
--     end
-- &&
-- ENDE TRIGGER DEFINITIONEN
