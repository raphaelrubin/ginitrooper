/* CALC.AUTO_TABLE_BUILD_VERSIONS
 * Log der einzelnen Bau Versionen der Automatisierung
 */

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger CALC.AUTO_TABLE_BUILD_VERSIONS_UPDATE_TRIGGER;

call STG.TEST_PROC_BACKUP_AND_DROP('CALC','AUTO_TABLE_BUILD_VERSIONS');
create table CALC.AUTO_TABLE_BUILD_VERSIONS
(
    ID BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 NOCYCLE CACHE 500 NOORDER),
    TAPENAME VARCHAR(8) NOT NULL,                           -- Name des Tapes für das Exportiert wurde
    LIST_ID BIGINT DEFAULT NULL,                            -- Listen ID für BGA Sonderkunden (sonst NULL)
    GROUPNAME VARCHAR(128) NOT NULL,                        -- Nutzer definierter Gruppenname
    CUT_OFF_DATE DATE NOT NULL,                             -- Stichtag
    arg_Stage INT NOT NULL,                                     -- Tabellen Stage
    arg_useArchive BOOLEAN NOT NULL,
    arg_rebuildAll BOOLEAN NOT NULL,
    arg_VERSION BIGINT NOT NULL,                                -- Bau Version
    Completed BOOLEAN DEFAULT FALSE,                        -- Wurde die Prozedur abgeschlossen?
    SUCCESS BOOLEAN DEFAULT NULL,                           -- Wurde die Prozedur erfolgreich abgeschlossen?
    WARNINGS INT DEFAULT 0,
    CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY VARCHAR(128) DEFAULT USER,
    LAST_CHANGED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,    --ON UPDATE CURRENT_TIMESTAMP
    LAST_CHANGED_BY VARCHAR(128) DEFAULT USER,                --ON UPDATE CURRENT_USER
    PRIMARY KEY(ID)
    --FOREIGN KEY TABNAME (TABNAME) REFERENCES SYSCAT.TABLES ON DELETE NO ACTION
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','AUTO_TABLE_BUILD_VERSIONS');


--#SET TERMINATOR &&
-- Trigger to monitor changes on a row
CREATE OR REPLACE TRIGGER CALC.AUTO_TABLE_BUILD_VERSIONS_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON CALC.AUTO_TABLE_BUILD_VERSIONS
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
    SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&