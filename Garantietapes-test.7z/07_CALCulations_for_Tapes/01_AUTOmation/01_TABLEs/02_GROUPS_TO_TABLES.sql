-- Table to keep track of all the groups and contained tables

-- CI START FOR ALL TAPES

--Kommentar für die CI, damit die Tabelle neu gebaut werden kann für den Test

-- Zunächst müssen die Trigger gedroped werden, da diese beim dropen der Tabelle nicht mit gedroped werden.
-- Damit die Archive- und Recovery-Prozedur keine Änderung an den Daten triggert, müssen diese vorher gelöscht werden.
drop trigger AMC.AUTO_TABLE_GROUPS_UPDATE_TRIGGER;
--drop trigger AMC.AUTO_TABLE_GROUPS_TABNAME_UPDATE_TRIGGER;
drop trigger AMC.AUTO_TABLE_GROUPS_TABNAME_INSERT_TRIGGER;

-- TABLE erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','AUTO_TABLE_GROUPS');
create table AMC.AUTO_TABLE_GROUPS
(
	ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	TABNAME VARCHAR(128) not null,
	GROUPNAME VARCHAR(128) not null,
	EXPORTNAME VARCHAR(128) not null,
	CREATED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) default USER,
	LAST_CHANGED_AT TIMESTAMP(6) default CURRENT TIMESTAMP,
	LAST_CHANGED_BY VARCHAR(128) default USER,
	PRIMARY KEY(ID)
    -- CONSTRAINT FK_GROUP FOREIGN KEY (GROUPNAME) REFERENCES CALC.AUTO_TABLE_GROUPS(GROUPNAME)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','AUTO_TABLE_GROUPS');
grant select on AMC.AUTO_TABLE_GROUPS to group NLB_MW_ADAP_S_GNI_TROOPER;
------------------------------------------------------------------------------------------------------------------------

--#SET TERMINATOR &&

-- BEFORE INSERT Trigger to check Tablenames since SYSCAT cannot be referenced in a foreign key
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER AMC.AUTO_TABLE_GROUPS_TABNAME_INSERT_TRIGGER
     BEFORE INSERT ON AMC.AUTO_TABLE_GROUPS
     REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key GROUPNAME
     IF NOT EXISTS (select * from CALC.AUTO_TABLE_GROUPS where GROUPNAME = NROW.GROUPNAME) THEN
         SET ERROR_MESSAGE = 'Invalid group name '||NROW.GROUPNAME||'.';
         SIGNAL SQLSTATE '73513' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
     -- Foreign key TABNAME
     IF NOT EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME and TABSCHEMA = 'AMC') THEN
         SET ERROR_MESSAGE = 'Invalid table name AMC.'|| NROW.TABNAME||'.';
         SIGNAL SQLSTATE '73513' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
    END
&&
------------------------------------------------------------------------------------------------------------------------

-- BEFORE UPDATE Trigger to monitor changes on a row
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER AMC.AUTO_TABLE_GROUPS_UPDATE_TRIGGER
    NO CASCADE BEFORE UPDATE
    ON AMC.AUTO_TABLE_GROUPS
    REFERENCING NEW AS NROW
     FOR EACH ROW MODE DB2SQL
    BEGIN ATOMIC
     declare ERROR_MESSAGE VARCHAR(70);
     -- Foreign key GROUPNAME
     IF NOT EXISTS (select * from CALC.AUTO_TABLE_GROUPS where GROUPNAME = NROW.GROUPNAME) THEN
         SET ERROR_MESSAGE = 'Invalid group name '||NROW.GROUPNAME||'.';
         SIGNAL SQLSTATE '73513' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
     -- Foreign key TABNAME
     IF NOT EXISTS (select * from SYSCAT.TABLES where TABNAME = NROW.TABNAME and TABSCHEMA = 'AMC') THEN
         SET ERROR_MESSAGE = 'Invalid table name AMC.'||NROW.TABNAME||'.';
         SIGNAL SQLSTATE '73513' SET MESSAGE_TEXT = ERROR_MESSAGE;
     END IF;
     -- update the Last Changed Fingerprint
     SET
     NROW.LAST_CHANGED_AT = CURRENT TIMESTAMP,
     NROW.LAST_CHANGED_BY = USER;
    END
&&

-- CI END FOR ALL TAPES
--#SET TERMINATOR ;
-- SWITCHES erstellen
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_DROP_AND_CREATE_SWITCH('AMC','AUTO_TABLE_GROUPS');
------------------------------------------------------------------------------------------------------------------------
