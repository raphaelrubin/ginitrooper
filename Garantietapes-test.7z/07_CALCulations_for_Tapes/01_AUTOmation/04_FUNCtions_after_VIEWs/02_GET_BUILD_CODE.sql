/* CALC.AUTO_FUNC_GET_BUILD_CODE
 *
 * Diese Funktion erstellt den Code, um eine Tabelle neu zu bauen
 *
 * @input: TAPENAME varchar(8)              Schema des aktiven Tapes
 * @input: TABSCHEMA_CURRENT varchar(8)     Schema der Tabelle, die wiederhergestellt werden soll
 * @input: TABNAME_CURRENT varchar(128)     Name der Tabelle, die wiederhergestellt werden soll
 *
 * @output CLOB(200k) Query, welche zum Bauen der Tabelle ausgeführt werden muss
 */

drop function CALC.AUTO_FUNC_GET_BUILD_CODE(varchar(8), varchar(8), varchar(128), BOOLEAN);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_BUILD_CODE(TAPENAME varchar(8),TABSCHEMA_CURRENT varchar(8), TABNAME_CURRENT varchar(128), FORCE_OUTPUT BOOLEAN)
  returns CLOB(200k)
  begin
    declare curQuery CLOB(200k);
    declare tabType CHAR(1);
    declare VIEWSCHEMA VARCHAR(128);
    declare VIEWNAME varchar(128);
    declare COLUMNNAMES CLOB(100k);

    set curQuery = (select BUILDCODE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR);
    set tabType = (select TYPE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR);
    set VIEWSCHEMA = coalesce((select BUILD_VIEW_SCHEMA from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR),'CALC');
    set COLUMNNAMES = (select listagg(cast(COLNAME as VARCHAR(30000)),', ') from SYSCAT.COLUMNS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT with UR);
    -- determine View name
--     case
--         when upper(right(TABNAME_CURRENT,7)) = 'CURRENT' then
--             set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(TABSCHEMA_CURRENT,TABNAME_CURRENT);
--         else
--             set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT(TABSCHEMA_CURRENT,TABNAME_CURRENT);
--     end case;
    set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(TABSCHEMA_CURRENT,TABNAME_CURRENT);

    -- generate Query
    case
        when upper(curQuery) = 'DEFAULT' and tabType = 'S' then
            -- MQT => refresh table <Mqt>
            set curQuery = 'refresh table '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT;
        when upper(curQuery) = 'DEFAULT' and tabType = 'T' then
            -- Table => insert into <Table> select * from <View>
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| ' ('||COLUMNNAMES||') select '||COLUMNNAMES||' from '|| VIEWSCHEMA || '.'|| VIEWNAME;
        when upper(curQuery) = 'DEFAULT INTERNAL' and tabType = 'T' then
            -- Table => insert into <Table> select * from <View>
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| ' select * from '|| TABSCHEMA_CURRENT || '.'|| VIEWNAME;
        when curQuery is NULL and FORCE_OUTPUT then
            -- Table => insert into <Table> select * from <View>
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| ' ('||COLUMNNAMES||') select '||COLUMNNAMES||' from '|| VIEWSCHEMA || '.'|| VIEWNAME;
            case
                when TABSCHEMA_CURRENT = 'NLB' and VIEWSCHEMA = 'STG' then
                    -- Befüllung NLB Tabelle
                    set curQuery = curQuery||' where BRANCH = ''NLB''';
                when TABSCHEMA_CURRENT = 'BLB' and VIEWSCHEMA = 'STG' then
                    -- Befüllung BLB Tabelle
                    set curQuery = curQuery||' where BRANCH = ''BLB''';
                when TABSCHEMA_CURRENT = 'ANL' and VIEWSCHEMA = 'STG' then
                    -- Befüllung ANL Tabelle
                    set curQuery = curQuery||' where BRANCH not in (''NLB'',''BLB'',''CBB'')';
                when TABSCHEMA_CURRENT = 'CBB' and VIEWSCHEMA = 'STG' then
                    -- Befüllung CBB Tabelle
                    set curQuery = curQuery||' where BRANCH in (''LUX'',''CBB'')';
                else
                    set curQuery = curQuery;

            end case;
        else
            -- Else: use the provided query or NULL
            set curQuery = curQuery;
    end case;

    set curQuery = replace(curQuery,'AMC.',TAPENAME||'.'); -- Wird für merge codes benötigt
    -- TODO: der code oben muss auch andere Tapes ersetzen...

    return curQuery;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_BUILD_CODE(varchar(8), varchar(8), varchar(128)) is 'Funktion, welche den Code zum Bauen einer Tabelle wiedergibt.';

drop function CALC.AUTO_FUNC_GET_BUILD_CODE(varchar(8),varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_BUILD_CODE(TAPENAME varchar(8), TABSCHEMA_CURRENT varchar(8), TABNAME_CURRENT varchar(128))
  returns CLOB(200k)
  begin
      return CALC.AUTO_FUNC_GET_BUILD_CODE(TAPENAME, TABSCHEMA_CURRENT, TABNAME_CURRENT, FALSE);
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_BUILD_CODE(varchar(8), varchar(8), varchar(128)) is 'Funktion, welche den Code zum Bauen einer Tabelle wiedergibt.';

-- TESTS

-- call CALC.DO_SWITCH_TO_TAPE('AMC');
-- select
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','NLB', 'SPOT_STAMMDATEN_CURRENT',TRUE) as SPOT_STAMMDATEN_CURRENT,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','NLB', 'SPOT_STAMMDATEN_CURRENT',FALSE) as SPOT_STAMMDATEN_CURRENT_UNFORCED,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','AMC', 'TABLE_PORTFOLIO_ARCHIVE',TRUE) as TABLE_PORTFOLIO_ARCHIVE,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','AMC', 'TABLE_PORTFOLIO_CURRENT',TRUE) as TABLE_PORTFOLIO_CURRENT,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','BGA', 'TABLE_PORTFOLIO_CURRENT',TRUE) as TABLE_PORTFOLIO_CURRENT,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','NLB', 'SPOT_STAMMDATEN',TRUE) as SPOT_STAMMDATEN,
-- --     CALC.AUTO_FUNC_GET_BUILD_CODE('AMC','IMAP', 'CURRENCY_MAP',TRUE) as CURRENCY_MAP
-- -- from SYSIBM.SYSDUMMY1;
