drop function CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE(varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE(TABSCHEMA_CURRENT varchar(8), TABNAME_CURRENT varchar(128))
  returns DATE
  -- takes a table and checks what CUT_OFF_DATE Value is in the source view for that table. The Date value of that cut off date is returned.
  begin
    declare curQuery CLOB(200k);
    declare VIEWSCHEMA VARCHAR(128);
    declare VIEWNAME varchar(128);
    declare CUTOFFDATE_COLNAME VARCHAR(64);
    declare ANS_CUT_OFF_DATE DATE;

    select coalesce(BUILD_VIEW_SCHEMA,'CALC'), COLNAME_CUT_OFF_DATE into VIEWSCHEMA, CUTOFFDATE_COLNAME from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR;
--     case
--         when upper(right(TABNAME_CURRENT,7)) = 'CURRENT' then
--             set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(TABSCHEMA_CURRENT,TABNAME_CURRENT);
--         else
--             set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_ARCHIVE_TO_CURRENT(TABSCHEMA_CURRENT,TABNAME_CURRENT);
--     end case;
    set VIEWNAME = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_VIEW(TABSCHEMA_CURRENT,TABNAME_CURRENT);

    set curQuery = 'select DATE('||CUTOFFDATE_COLNAME||') from '||VIEWSCHEMA||'.'||VIEWNAME||' limit 1';
                                                                                                                          
    if curQuery is NULL then
        -- keine CUT_OFF_DATE_SPALTE oder keine Quellview -> Einfach auf NULL setzen, Fehler wird in get truncate code behoben oder geworfen.
        return NULL;
    end if;
    
    if TABNAME_CURRENT like '%_CURRENT' and TABSCHEMA_CURRENT in ('AMC','BGA') then
        set curQuery = 'select DATE(CUT_OFF_DATE) from CALC.AUTO_TABLE_CUTOFFDATES where IS_ACTIVE limit 1';
    end if;

    begin
        declare stmt STATEMENT;
        declare crsr CURSOR for stmt;
        prepare stmt FROM curQuery;
        open crsr;
            fetch crsr into ANS_CUT_OFF_DATE;
        close crsr;
    end;

    return ANS_CUT_OFF_DATE;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE(varchar(8), varchar(128)) is 'Funktion, welche den Stcihtag der zugehörigen View wiedergibt.';


-- TESTS
-- select
--     CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE('NLB','SPOT_STAMMDATEN_CURRENT'),
--     CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE('BLB','SPOT_STAMMDATEN'),
--     CALC.AUTO_FUNC_GET_EXPECTED_CUT_OFF_DATE('IMAP','CURRENCY_MAP')
-- from SYSIBM.SYSDUMMY1;
