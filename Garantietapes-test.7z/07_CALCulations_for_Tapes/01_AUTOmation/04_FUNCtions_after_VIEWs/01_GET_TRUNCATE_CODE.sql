/* CALC.AUTO_FUNC_GET_TRUNCATE_CODE
 *
 * Diese Funktion erstellt den Code, um eine AMC Tabelle zu leeren
 *
 * @input: desired_TABSCHEMA varchar(8)     Schema der Tabelle, die geleert werden soll
 * @input: desired_TABNAME varchar(128)     Name der Tabelle, die geleert werden soll
 *
 * @output CLOB(200k) Query, welche zum Leeren der Tabelle ausgeführt werden muss
 */

drop function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(varchar(8), varchar(128), DATE);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(desired_TABSCHEMA varchar(8), desired_TABNAME varchar(128), desired_CUTOFFDATE DATE)
  returns CLOB(200k)
  begin
    declare curQuery CLOB(200k);
    declare CUTOFFDATE_COLNAME VARCHAR(64);

    -- Stichtag Spalte für where Bedingung
    set CUTOFFDATE_COLNAME = (select COLNAME_CUT_OFF_DATE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME limit 1 with UR);

    -- delete Query bauen
    set curQuery = 'delete from ' || desired_TABSCHEMA||'.'||desired_TABNAME;
    case
        when desired_TABNAME like '%_CURRENT' then
            set curQuery = curQuery || ' where 1=1';
        else
            set curQuery = curQuery || ' where '||CUTOFFDATE_COLNAME||' = '''||desired_CUTOFFDATE||'''';
            -- Info -> NULL, falls keine CUT_OFF_DATE Spalte und Archiv Tabelle.
            --         Wirft beim Ausführen später zwar einen Fehler, aber besser als alles aus dem Archiv zu löschen.
    end case;
    return curQuery;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(varchar(8), varchar(128), DATE) is 'Funktion, welche den Code zum Leeren einer Tabelle wiedergibt.';

drop function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(varchar(8), varchar(128));
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(desired_TABSCHEMA varchar(8), desired_TABNAME varchar(128))
  returns CLOB(200k)
  begin
    declare desired_CUTOFFDATE DATE;
    set desired_CUTOFFDATE = last_day(CURRENT_DATE-1 MONTH);
    return CALC.AUTO_FUNC_GET_TRUNCATE_CODE(desired_TABSCHEMA, desired_TABNAME, desired_CUTOFFDATE);
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_TRUNCATE_CODE(varchar(8), varchar(128)) is 'Funktion, welche den Code zum Leeren einer Tabelle wiedergibt.';


-- TEST
-- select
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','NLB', 'SPOT_STAMMDATEN_CURRENT',TRUE) as SPOT_STAMMDATEN_CURRENT,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','NLB', 'SPOT_STAMMDATEN_CURRENT',FALSE) as SPOT_STAMMDATEN_CURRENT_UNFORCED,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','AMC', 'TABLE_PORTFOLIO_ARCHIVE',TRUE) as TABLE_PORTFOLIO_ARCHIVE,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','AMC', 'TABLE_PORTFOLIO_CURRENT',TRUE) as TABLE_PORTFOLIO_CURRENT,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','BGA', 'TABLE_PORTFOLIO_CURRENT',TRUE) as TABLE_PORTFOLIO_CURRENT,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','NLB', 'SPOT_STAMMDATEN',TRUE) as SPOT_STAMMDATEN,
-- --     CALC.AUTO_FUNC_GET_TRUNCATE_CODE('AMC','IMAP', 'CURRENCY_MAP',TRUE) as CURRENCY_MAP
-- -- from SYSIBM.SYSDUMMY1;
