/* CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE
 *
 * Diese Funktion erstellt den Code, um eine Tabelle aus dem Archiv wiederherzustellen.
 *
 * @input: TAPENAME varchar(8)              Schema des aktiven Tapes
 * @input: TABSCHEMA_CURRENT varchar(8)     Schema der Tabelle, die wiederhergestellt werden soll
 * @input: TABNAME_CURRENT varchar(128)     Name der Tabelle, die wiederhergestellt werden soll
 * @input: in_CUTOFFDATE date               Cut off date, welches wiederhergestellt werden soll
 *
 * @output CLOB(200k) Query, welche zur Wiederherstellung ausgeführt werden muss
 */
drop function CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE(varchar(8),varchar(8), varchar(128), date);
--#SET TERMINATOR &&
create or replace function CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE(TAPENAME varchar(8), TABSCHEMA_CURRENT varchar(8), TABNAME_CURRENT varchar(128), in_CUTOFFDATE date)
  returns CLOB(200k)
  begin
    declare mode CLOB(200k);
    declare TABNAME_ARCHIVE VARCHAR(128);
    declare CODname VARCHAR(64);
    declare curQuery CLOB(200k);
    declare colnames CLOB(100k);

    set mode = (select RECREATECODE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR);

    set CODname = (select COLNAME_CUT_OFF_DATE from CALC.AUTO_VIEW_TARGETS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT limit 1 with UR);

    -- determine Archive name
    set TABNAME_ARCHIVE = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(TABSCHEMA_CURRENT,TABNAME_CURRENT);

    -- get a list of all columns except CREATED_AT/CREATED_BY
    set colnames = (select listagg(cast(COLNAME as VARCHAR(30000)),', ') from SYSCAT.COLUMNS where TABSCHEMA = TABSCHEMA_CURRENT and TABNAME = TABNAME_CURRENT and COLNAME not in ('CREATED_AT','CREATED_BY') with UR);


    -- generate Query
    case
        when upper(mode) = 'MAX COD' then
            -- fill with the latest available data
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| '('||colnames||') select '||colnames||' from '|| TABSCHEMA_CURRENT|| '.'||
                           TABNAME_ARCHIVE || ' where '|| CODname|| ' in (select MAX('|| CODname|| ') from '|| TABSCHEMA_CURRENT|| '.'||
                           TABNAME_ARCHIVE || ' where '|| CODname|| ' <= '''|| in_CUTOFFDATE|| ''') ';
        when upper(mode) = 'BW' then
            -- fill with the exact requested CoD
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| '('||colnames||') select '||colnames||' from '|| TABSCHEMA_CURRENT|| '.'||
                           TABNAME_ARCHIVE || ' where '|| CODname|| ' = '''|| in_CUTOFFDATE|| ''' ';
        when upper(mode) = 'DEFAULT' then
            set curQuery = 'insert into '|| TABSCHEMA_CURRENT|| '.'|| TABNAME_CURRENT|| '('||colnames||') select '||colnames||' from '|| TABSCHEMA_CURRENT|| '.'||
                           TABNAME_ARCHIVE || ' where '|| CODname|| ' = '''|| in_CUTOFFDATE|| ''' ';
        else
            set curQuery = replace(mode,'%COD',CAST(in_CUTOFFDATE AS VARCHAR(16)));
    end case;

    set curQuery = replace(curQuery,'AMC.',TAPENAME||'.');

    return curQuery;
  end
&&
--#SET TERMINATOR ;
comment on function CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE is 'Funktion, welche den Code zum Wiederherstellen einer Tabelle aus dem Archiv wiedergibt.';


-- call CALC.DO_SWITCH_TO_TAPE('AMC');
-- select
--        CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE('AMC','AMC','TABLE_PORTFOLIO_CURRENT','31.12.2019') AS TABLE_PORTFOLIO_CURRENT,
--        CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE('AMC','AMC','TABLE_CASH_FLOW_FUTURE_CURRENT','29.02.2020') AS TAPE_CASH_FLOW_FUTURE_CURRENT,
--        CALC.AUTO_FUNC_GET_REINSTATE_FROM_ARCHIVE_CODE('AMC','NLB','SPOT_UMSATZ_CURRENT','30.04.2020') AS SPOT_UMSATZ_CURRENT
-- from SYSIBM.SYSDUMMY1;