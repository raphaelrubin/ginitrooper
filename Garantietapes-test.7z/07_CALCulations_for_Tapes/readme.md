# CALCulations

Dieser Ordner enthällt den Automatisierungscode sowie die Mapping Views, die von mehreren Tapes geteilt werden.