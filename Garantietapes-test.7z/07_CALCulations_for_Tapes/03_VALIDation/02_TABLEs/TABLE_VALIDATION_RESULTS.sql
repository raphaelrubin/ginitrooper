
-- Tabelle für Rohdaten Validierung
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('CALC','TABLE_VALIDATION_RESULTS_CURRENT');
create table CALC.TABLE_VALIDATION_RESULTS_CURRENT (
    ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	TABLEGROUP VARCHAR(128) not NULL,
	CUT_OFF_DATE DATE not NULL,
	IMPORTANCE INTEGER not NULL DEFAULT 0,
	AFFECTED_TABLE VARCHAR(128),
	AFFECTED_COLUMN VARCHAR(128),
	AFFECTED_ROW VARCHAR(128),
	ERRORMESSAGE VARCHAR(1024),
	VALIDATION_ID BIGINT,
	CREATED_AT TIMESTAMP(6) not NULL default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) not NULL default USER,
    PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','TABLE_VALIDATION_RESULTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- CI START FOR ALL TAPES

-- Tabelle für Tapedaten Validierung
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('AMC','TABLE_VALIDATION_RESULTS_CURRENT');
create table AMC.TABLE_VALIDATION_RESULTS_CURRENT (
    ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	TABLEGROUP VARCHAR(128) not NULL,
	CUT_OFF_DATE DATE not NULL,
	IMPORTANCE INTEGER not NULL DEFAULT 0,
	AFFECTED_TABLE VARCHAR(128),
	AFFECTED_COLUMN VARCHAR(128),
	AFFECTED_ROW VARCHAR(128),
	ERRORMESSAGE VARCHAR(1024),
	VALIDATION_ID BIGINT,
	CREATED_AT TIMESTAMP(6) not NULL default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) not NULL default USER,
    PRIMARY KEY(ID)
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('AMC','TABLE_VALIDATION_RESULTS_CURRENT');
------------------------------------------------------------------------------------------------------------------------

-- CI END FOR ALL TAPES
