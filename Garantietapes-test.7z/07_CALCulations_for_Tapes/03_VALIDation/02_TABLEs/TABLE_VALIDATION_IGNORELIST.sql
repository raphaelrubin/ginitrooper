
------------------------------------------------------------------------------------------------------------------------
call STG.TEST_PROC_BACKUP_AND_DROP('CALC','TABLE_VALIDATION_IGNORELIST_ARCHIVE');
create table CALC.TABLE_VALIDATION_IGNORELIST_ARCHIVE (
    ID BIGINT not NULL generated always as identity (start with 1 increment by 1 MINVALUE 1 MAXVALUE 9223372036854775807 nocycle cache 500 noorder),
	VALIDATION_ID BIGINT,
	AFFECTED_TABLE VARCHAR(128),
	AFFECTED_COLUMN VARCHAR(128),
	AFFECTED_ROW VARCHAR(128),
	COMMENT VARCHAR(1024),
	CREATED_AT TIMESTAMP(6) not NULL default CURRENT TIMESTAMP,
	CREATED_BY VARCHAR(128) not NULL default USER,
    PRIMARY KEY(ID)
    --FOREIGN KEY (VALIDATION_ID) references CALC.AUTO_TABLE_VALIDATIONS(ID) on update no action on delete cascade
);
call STG.TEST_PROC_LOAD_AND_DROP_BACKUP_FOR('CALC','TABLE_VALIDATION_IGNORELIST_ARCHIVE');
------------------------------------------------------------------------------------------------------------------------


