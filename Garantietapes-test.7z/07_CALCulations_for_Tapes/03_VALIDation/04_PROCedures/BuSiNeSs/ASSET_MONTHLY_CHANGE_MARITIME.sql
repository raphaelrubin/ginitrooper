-- Dieser Test prüft, ob ein ASSET Value sich ungewöhnlich stark verändert hat zwischen zwei Monatsstichtagen.
drop procedure CALC.VALID_PROC_BSNS_ASSET_MONTHLY_CHANGE_MARITIME (VARCHAR(8), VARCHAR(128), VARCHAR(256), FLOAT, VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_ASSET_MONTHLY_CHANGE_MARITIME (TABSCHEMA VARCHAR(8), TABNAME VARCHAR(128), COLNAME_VALUE VARCHAR(256), PERCENT_CHANGE FLOAT, TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare curQueryShort VARCHAR(450);
    declare active_Schema VARCHAR(8);
    declare used_Schema VARCHAR(8);
    declare TABNAME_ARCHIVE VARCHAR(128);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_ASSET_MONTHLY_CHANGE_MARITIME.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();
    set used_Schema = COALESCE(TABSCHEMA,active_Schema);
    set TABNAME_ARCHIVE = CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE(used_Schema,TABNAME);

    set curQuery = 'select
    AST_CM.ASSET_ID as AFFECTED_ROW,
    AST_CM.CUT_OFF_DATE as CUT_OFF_DATE,
    ''Mehr als '||cast(INTEGER(ROUND(100*PERCENT_CHANGE,0)) as VARCHAR(10))||'% Wertveränderung von '||COLNAME_VALUE||' ggü. dem letzten Monat. Neuer Wert: '' || BIGINT(AST_CM.'||COLNAME_VALUE||') || '', alter Wert: '' || BIGINT(AST_LM.'||COLNAME_VALUE||') as ERRORMESSAGE
from '||used_Schema||'.'||TABNAME||' as AST_CM
inner join '||used_Schema||'.'||TABNAME_ARCHIVE||' as AST_LM   on (AST_CM.ASSET_ID, AST_CM.BRANCH, LAST_DAY(AST_CM.CUT_OFF_DATE - 1 month)) = (AST_LM.ASSET_ID, AST_LM.BRANCH, AST_LM.CUT_OFF_DATE)
where AST_CM.'||COLNAME_VALUE||' not between '||(1-PERCENT_CHANGE)||' * AST_LM.'||COLNAME_VALUE||' and '||(1+PERCENT_CHANGE)||' * AST_LM.'||COLNAME_VALUE||'
    and AST_CM.'||COLNAME_VALUE||' not between '||(1-2*PERCENT_CHANGE)||' * AST_CM.'||replace(COLNAME_VALUE,'MARKET_VALUE_EUR','VALUE_OF_LATEST_VALUATION_USD')||' and '||(1+2*PERCENT_CHANGE)||' * AST_CM.'||replace(COLNAME_VALUE,'MARKET_VALUE_EUR','VALUE_OF_LATEST_VALUATION_USD')||'';

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||used_Schema||'.'||TABNAME||''' as AFFECTED_TABLE,
        ''ASSET_ID'' as AFFECTED_COLUMN,
        AFFECTED_ROW as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    set curQueryShort = right(curQuery,450);
    call CALC.AUTO_PROC_LOG_DEBUG('    '||curQueryShort);

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_ASSET_MONTHLY_CHANGE_MARITIME.');
end
&&

-- TEST
-- delete from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
-- call CALC.VALID_PROC_BSNS_ASSET_MONTHLY_CHANGE_MARITIME(NULL,'TABLE_MARITIME_ASSET_CURRENT','SHIP_MARKET_VALUE_EUR',0.1,'ALL','08/31/2020',100);
-- select * from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
--
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
--
--
-- select CALC.AUTO_FUNC_CHANGE_NAME_CURRENT_TO_ARCHIVE('AMC','TABLE_GENERAL_ASSET_CURRENT') from SYSIBM.SYSDUMMY1;
-- -- beispiel
--
-- select
--     AST_CM.ASSET_ID                                                                                                                                                             as AFFECTED_ROW,
--     AST_CM.CUT_OFF_DATE                                                                                                                                                         as CUT_OFF_DATE,
--     'Mehr als 10% Wertveraenderung ggue. dem letzten Monat. Neuer Wert: EUR ' || BIGINT(AST_CM.VO_ANZUS_VALUE_EUR) || ', alter Wert: EUR ' || BIGINT(AST_LM.VO_ANZUS_VALUE_EUR) as ERRORMESSAGE
-- from AMC.TAPE_GENERAL_ASSET_FINISH as AST_CM
-- inner join AMC.TABLE_GENERAL_ASSET_ARCHIVE as AST_LM   on (AST_CM.ASSET_ID, AST_CM.BRANCH, LAST_DAY(AST_CM.CUT_OFF_DATE - 1 month)) = (AST_LM.ASSET_ID, AST_LM.BRANCH, AST_LM.CUT_OFF_DATE)
-- where AST_CM.VO_ANZUS_VALUE_EUR not between (1-0.1) * AST_LM.VO_ANZUS_VALUE_EUR and (1+0.1) * AST_LM.VO_ANZUS_VALUE_EUR
--   and AST_CM.ASSET_DESCRIPTION not in ('Giroguthaben', 'Sonstige Guthaben')