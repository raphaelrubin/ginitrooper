--Dieser Test prüft ob alle Derivate korrekt verarbeitet wurden. Erwartung Leere Menge
--Also: Ist die Anzahl der Derivate mit Loanstate_Spot und Current Contractual Maturity Date ungleich null <200, dann Fehler
drop procedure CALC.VALID_PROC_BSNS_PORTFOLIO_CLIENT_IN_IWHS (VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_PORTFOLIO_CLIENT_IN_IWHS (TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare active_Schema VARCHAR(8);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_PORTFOLIO_CLIENT_IN_IWHS.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();

    set curQuery = 'select distinct
           ''Die Kundennummer ''||TBL.BRANCH_CLIENT||''_''||TBL.CLIENT_NO||'' gibt es in AMC.TABLE_PORTFOLIO_CURRENT aber nicht im IWHS.'' as ERRORMESSAGE,
           TBL.CLIENT_ID_ORIG                                            as AFFECTED_ROW,
           TBL.CUT_OFF_DATE
        from '||active_Schema||'.TABLE_PORTFOLIO_CURRENT as TBL
        left join (
    select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, ''NLB'' as BRANCH from NLB.IWHS_KUNDE_CURRENT
    union all
    select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, ''BLB'' as BRANCH from BLB.IWHS_KUNDE_CURRENT
    union all
    select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, ''NLB'' as BRANCH from ANL.IWHS_KUNDE_CURRENT
) as IWHS on (IWHS.BRANCH,IWHS.CLIENT_NO,IWHS.CUT_OFF_DATE)=(TBL.BRANCH_CLIENT,TBL.CLIENT_NO,TBL.CUT_OFF_DATE)
    where IWHS.CLIENT_NO is null and TBL.CLIENT_NO<>''9999999999''';

    --set curQueryShort = left(curQuery,450);
    --call CALC.AUTO_PROC_LOG_DEBUG('    '||curQueryShort);

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP); set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||active_Schema||'.TABLE_PORTFOLIO_CURRENT'' as AFFECTED_TABLE,
        ''CLIENT_ID_ORIG'' as AFFECTED_COLUMN,
        AFFECTED_ROW as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_PORTFOLIO_CLIENT_IN_IWHS.');
end
&&

-- test
-- delete from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
-- call CALC.VALID_PROC_BSNS_PORTFOLIO_CLIENT_IN_IWHS('ALL','08/31/2020',100);
-- select * from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
--
--
-- select distinct
--            'Die Kundennummer '||TBL.BRANCH_CLIENT||'_'||TBL.CLIENT_NO||' gibt es in AMC.TABLE_PORTFOLIO_CURRENT aber nicht im IWHS.' as ERRORMESSAGE,
--            TBL.CLIENT_ID_ORIG                                            as AFFECTED_ROW--,
--            -- TBL.CUT_OFF_DATE
--         from AMC.TABLE_PORTFOLIO_CURRENT as TBL
--         left join (
--     select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, 'NLB' as BRANCH from NLB.IWHS_KUNDE_CURRENT
--     union all
--     select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, 'BLB' as BRANCH from BLB.IWHS_KUNDE_CURRENT
--     union all
--     select CUTOFFDATE as CUT_OFF_DATE, BORROWERID as CLIENT_NO, 'NLB' as BRANCH from ANL.IWHS_KUNDE_CURRENT
-- ) as IWHS on (IWHS.BRANCH,IWHS.CLIENT_NO,IWHS.CUT_OFF_DATE)=(TBL.BRANCH_CLIENT,TBL.CLIENT_NO,TBL.CUT_OFF_DATE)
--     where IWHS.CLIENT_NO is null and TBL.CLIENT_NO<>'9999999999'