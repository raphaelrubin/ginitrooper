--Test für EAD Veränderung nach Kermit
--Dieser Test prüft, ob sich der EAD vor Kermit verändert hat. Das sollte er nicht.
drop procedure CALC.VALID_PROC_BSNS_GG_WITH_EXPOSURE_WITHOUT_BALANCESHEETVALUE (VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_GG_WITH_EXPOSURE_WITHOUT_BALANCESHEETVALUE (TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(1024 K);
    declare active_Schema VARCHAR(8);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_GG_WITH_EXPOSURE_WITHOUT_BALANCESHEETVALUE.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();

    set curQuery = 'select ''TABLE_FACILITY_CORE_CURRENT'' as AFFECTED_TABLE,
       ''Facility Details'' as AFFECTED_COLUMN,
       F.FACILITY_ID as AFFECTED_ROW,
       ''Das Konto '' || F.FACILITY_ID  || '' hat bei KR EAD und SPOT oder BW Restkapital aber keinen Bilanzwert. Portfolio ist: '' || CALC.MAP_FUNC_PORTFOLIO_TO_ROOT(F.PORTFOLIO) as ERRORMESSAGE,
       F.CUT_OFF_DATE
from '||active_Schema||'.TAPE_FACILITY_CORE_FINISH as F
where ABS(coalesce(F.BILANZWERT_IFRS9_TC,0)) < 0.01         -- Bilanzsumme ist 0
  and (   ABS(coalesce(F.PRICIPAL_OST_TC_BW,0)) > 0.01      -- BW Restkapital <> 0
       or ABS(coalesce(F.PRICIPAL_OST_TC_SPOT,0)) > 0.01)   -- SPOT Restkapital <> 0
  and coalesce(F.ZEB_R_EAD_TOTAL_AMT_EUR,0) <> 0            -- ZEB EAD <> 0
  and F.PRODUCTTYPE not in (''Limit'',''Rahmenkreditzusage'')
  and substr(F.FACILITY_ID,6,2) not in (''13'',''49'')';

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        ''AMC.TAPE_FACILITY_CORE_FINISH'' as AFFECTED_TABLE,
        ''FACILITY_ID'' as AFFECTED_COLUMN,
        AFFECTED_ROW as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_GG_WITH_EXPOSURE_WITHOUT_BALANCESHEETVALUE.');
end
&&


-- call CALC.VALID_PROC_BSNS_GG_WITH_EXPOSURE_WITHOUT_BALANCESHEETVALUE('ALL','08/31/2020',100);
-- select * from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
--
-- select 'TABLE_FACILITY_CORE_CURRENT' as AFFECTED_TABLE,
--        'Facility Details' as AFFECTED_COLUMN,
--        F.FACILITY_ID as AFFECTED_ROW,
--        'Das Konto ' || F.FACILITY_ID  || ' hat bei KR EAD und SPOT oder BW Restkapital aber keinen Bilanzwert. Portfolio ist: ' || CALC.MAP_FUNC_PORTFOLIO_TO_ROOT(F.PORTFOLIO) as ERRORMESSAGE,
--        F.CUT_OFF_DATE
-- from AMC.TAPE_FACILITY_CORE_FINISH as F
-- where ABS(coalesce(F.BILANZWERT_IFRS9_TC,0)) < 0.01         -- Bilanzsumme ist 0
--   and (   ABS(coalesce(F.PRICIPAL_OST_TC_BW,0)) > 0.01      -- BW Restkapital <> 0
--        or ABS(coalesce(F.PRICIPAL_OST_TC_SPOT,0)) > 0.01)   -- SPOT Restkapital <> 0
--   and coalesce(F.ZEB_R_EAD_TOTAL_AMT_EUR,0) <> 0            -- ZEB EAD <> 0
--   and F.PRODUCTTYPE not in ('Limit','Rahmenkreditzusage')
--   and substr(F.FACILITY_ID,6,2) not in ('13','49')
-- ;
--
-- select BILANZWERT_IFRS9_TC, PRICIPAL_OST_TC_BW, PRICIPAL_OST_TC_SPOT
-- from AMC.TAPE_FACILITY_CORE_FINISH as F
-- where ABS(coalesce(F.BILANZWERT_IFRS9_TC,0)) < 0.01         -- Bilanzsumme ist 0
--   and (   ABS(coalesce(F.PRICIPAL_OST_TC_BW,0)) > 0.01      -- BW Restkapital <> 0
--        or ABS(coalesce(F.PRICIPAL_OST_TC_SPOT,0)) > 0.01)   -- SPOT Restkapital <> 0
--   and coalesce(F.ZEB_R_EAD_TOTAL_AMT_EUR,0) <> 0            -- KR EAD <> 0
--   and F.PRODUCTTYPE not in ('Limit','Rahmenkreditzusage')
--   and substr(F.FACILITY_ID,6,2) not in ('13','49')
-- ;
