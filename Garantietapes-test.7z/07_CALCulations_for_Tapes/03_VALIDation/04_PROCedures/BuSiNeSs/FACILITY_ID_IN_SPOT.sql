--Test für EAD Veränderung nach Kermit
--Dieser Test prüft, ob sich der EAD vor Kermit verändert hat. Das sollte er nicht.
drop procedure CALC.VALID_PROC_BSNS_FACILITY_ID_IN_SPOT (VARCHAR(128), VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_FACILITY_ID_IN_SPOT (TABNAME VARCHAR(128), TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(1024 K);
    declare active_Schema VARCHAR(8);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_FACILITY_ID_IN_SPOT.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();

    set curQuery = 'select
    TBL.FACILITY_ID as AFFECTED_ROW,
    ''FACILITY_ID ist nicht in SPOT STAMMDATEN.''  as ERRORMESSAGE,
    TBL.CUT_OFF_DATE
from '||active_Schema||'.'||TABNAME||' as TBL
left join (
    select CUTOFFDATE, FACILITY_ID from NLB.SPOT_STAMMDATEN_CURRENT union all
    select CUTOFFDATE, FACILITY_ID from BLB.SPOT_STAMMDATEN_CURRENT union all
    select CUTOFFDATE, FACILITY_ID from ANL.SPOT_STAMMDATEN_CURRENT union all
    select CUTOFFDATE, ''K028-''|| (KKTOAVA + case when KKTOAVA = ''2588650'' then 3 else 1 end ) || ''_1020'' as FACILITY_ID from CBB.SPOT_STAMMDATEN_CURRENT
    ) as SPOT on SPOT.FACILITY_ID = TBL.FACILITY_ID and SPOT.CUTOFFDATE = TBL.CUT_OFF_DATE
where SPOT.CUTOFFDATE is NULL';

    set curQuery = 'select
        NULL as AFFECTED_ROW,
        ANZAHL||'' FACILITY_IDs sind nicht in SPOT STAMMDATEN.'' as ERRORMESSAGE,
        CUT_OFF_DATE
from (
      select COUNT( distinct TBL.FACILITY_ID) as ANZAHL,
             TBL.CUT_OFF_DATE
      from '||active_Schema||'.'||TABNAME||' as TBL
               left join (
          select CUTOFFDATE, FACILITY_ID from NLB.SPOT_STAMMDATEN_CURRENT union all
          select CUTOFFDATE, FACILITY_ID from BLB.SPOT_STAMMDATEN_CURRENT union all
          select CUTOFFDATE, FACILITY_ID from ANL.SPOT_STAMMDATEN_CURRENT union all
          select CUTOFFDATE, ''K028-'' || (KKTOAVA + case when KKTOAVA = ''2588650'' then 3 else 1 end) || ''_1020'' as FACILITY_ID
          from CBB.SPOT_STAMMDATEN_CURRENT
      ) as SPOT on SPOT.FACILITY_ID = TBL.FACILITY_ID and SPOT.CUTOFFDATE = TBL.CUT_OFF_DATE
      where SPOT.CUTOFFDATE is NULL group by TBL.CUT_OFF_DATE
)';

    call CALC.AUTO_PROC_LOG_DEBUG(left(curQuery,240));

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||active_Schema||'.'||TABNAME||''' as AFFECTED_TABLE,
        ''FACILITY_ID'' as AFFECTED_COLUMN,
        AFFECTED_ROW as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';



    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_FACILITY_ID_IN_SPOT.');
end
&&

-- select
--         NULL                             as AFFECTED_ROW,
--         ANZAHL||' FACILITY_IDs sind nicht in SPOT STAMMDATEN.' as ERRORMESSAGE,
--         CUT_OFF_DATE
-- from (
--       select COUNT( distinct TBL.FACILITY_ID)                             as ANZAHL,
--              TBL.CUT_OFF_DATE
--       from AMC.TABLE_CASH_FLOW_PAST_CURRENT as TBL
--                left join (
--           select CUTOFFDATE, FACILITY_ID
--           from NLB.SPOT_STAMMDATEN_CURRENT
--           union all
--           select CUTOFFDATE, FACILITY_ID
--           from BLB.SPOT_STAMMDATEN_CURRENT
--           union all
--           select CUTOFFDATE, FACILITY_ID
--           from ANL.SPOT_STAMMDATEN_CURRENT
--           union all
--           select CUTOFFDATE,
--                  'K028-' || (KKTOAVA + case when KKTOAVA = '2588650' then 3 else 1 end) ||
--                  '_1020' as FACILITY_ID
--           from CBB.SPOT_STAMMDATEN_CURRENT
--       ) as SPOT on SPOT.FACILITY_ID = TBL.FACILITY_ID and SPOT.CUTOFFDATE = TBL.CUT_OFF_DATE
--       where SPOT.CUTOFFDATE is NULL
--       group by TBL.CUT_OFF_DATE
-- )

-- delete from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
-- call CALC.VALID_PROC_BSNS_FACILITY_ID_IN_SPOT('TABLE_CASH_FLOW_PAST_GIRO_CURRENT','ALL','08/31/2020',100);
-- select * from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
--
-- select
--     TBL.FACILITY_ID as AFFECTED_ROW,
--     'FACILITY_ID ist nicht in SPOT STAMMDATEN.'  as ERROR,
--     TBL.CUT_OFF_DATE
-- from AMC.TABLE_CASH_FLOW_FUTURE_CURRENT as TBL
-- left join (
--     select CUTOFFDATE, FACILITY_ID from NLB.SPOT_STAMMDATEN_CURRENT union all
--     select CUTOFFDATE, FACILITY_ID from BLB.SPOT_STAMMDATEN_CURRENT union all
--     select CUTOFFDATE, FACILITY_ID from ANL.SPOT_STAMMDATEN_CURRENT union all
--     select CUTOFFDATE, 'K028-'|| (KKTOAVA + case when KKTOAVA = '2588650' then 3 else 1 end ) || '_1020' as FACILITY_ID from CBB.SPOT_STAMMDATEN_CURRENT
--     ) as SPOT on SPOT.FACILITY_ID = TBL.FACILITY_ID and SPOT.CUTOFFDATE = TBL.CUT_OFF_DATE
-- where SPOT.CUTOFFDATE is NULL
-- ;