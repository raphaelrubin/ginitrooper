--Test für EAD Veränderung nach Kermit
--Dieser Test prüft, ob sich der EAD vor Kermit verändert hat. Das sollte er nicht.
drop procedure CALC.VALID_PROC_BSNS_KERMIT_CHANGES_EAD (VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_KERMIT_CHANGES_EAD (TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare active_Schema VARCHAR(8);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_KERMIT_CHANGES_EAD.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();

    set curQuery = 'select
    ''Der EAD vor Kermit ist in'' || ANZAHL || ''Fällen ungleich dem EAD nach Kermit.'' as ERRORMESSAGE,
    CUT_OFF_DATE
from (select count(*) as ANZAHL, PRE_KERMIT.CUT_OFF_DATE
    from '||active_Schema||'.TABLE_KREDITRISIKO_BANKANALYSER_VOR_KERMIT_CURRENT as PRE_KERMIT
    inner join '||active_Schema||'.TABLE_KREDITRISIKO_BANKANALYSER_CURRENT as POST_KERMIT on (PRE_KERMIT.FACILITY_ID, PRE_KERMIT.CUT_OFF_DATE) = (POST_KERMIT.FACILITY_ID, POST_KERMIT.CUT_OFF_DATE)
    where PRE_KERMIT.EAD_TOTAL_EUR <> POST_KERMIT.EAD_TOTAL_EUR
    group by PRE_KERMIT.CUT_OFF_DATE)
where ANZAHL >= 1';

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||active_Schema||'.TABLE_KREDITRISIKO_BANKANALYSER_CURRENT'' as AFFECTED_TABLE,
        ''EAD_TOTAL_EUR'' as AFFECTED_COLUMN,
        NULL as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_KERMIT_CHANGES_EAD.');
end
&&


-- call CALC.VALID_PROC_BSNS_KERMIT_CHANGES_EAD('ALL','08/31/2020',100);
--
-- select
--     'Der EAD vor Kermit ist in' || ANZAHL || 'Fällen ungleich dem EAD nach Kermit.'  as ERROR,
--     CUT_OFF_DATE
-- from (select count(*) as ANZAHL, PRE_KERMIT.CUT_OFF_DATE
--     from AMC.TABLE_KREDITRISIKO_BANKANALYSER_VOR_KERMIT_CURRENT as PRE_KERMIT
--     inner join AMC.TABLE_KREDITRISIKO_BANKANALYSER_CURRENT as POST_KERMIT on (PRE_KERMIT.FACILITY_ID, PRE_KERMIT.CUT_OFF_DATE) = (POST_KERMIT.FACILITY_ID, POST_KERMIT.CUT_OFF_DATE)
--     where PRE_KERMIT.EAD_TOTAL_EUR <> POST_KERMIT.EAD_TOTAL_EUR
--     group by PRE_KERMIT.CUT_OFF_DATE)
-- where ANZAHL >= 1
-- ;