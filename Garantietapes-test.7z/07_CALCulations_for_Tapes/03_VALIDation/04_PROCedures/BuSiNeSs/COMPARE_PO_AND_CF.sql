-- TEST_CHECK_10
-- keine Ergebnisse erwartet - Teste ob Principal Outstanding und Umsätze übereinstimmen
drop procedure CALC.VALID_PROC_BSNS_COMPARE_PO_AND_CF (VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_BSNS_COMPARE_PO_AND_CF (TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare active_Schema VARCHAR(8);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for BSNS_COMPARE_PO_AND_CF.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();

    set curQuery = 'select distinct
        FACILITY_ID as AFFECTED_ROW,
        ''Principal Outstanding und Umsätze stimmen nicht überein'' as ERRORMESSAGE, CUT_OFF_DATE as CUT_OFF_DATE
from (
        select distinct
            F_C.FACILITY_ID,
            F_A.FACILITY_ID as FAC_2019,
            coalesce(abs(SUM(case when UMSATZ_ART in (''DARL_ABG_ZINS_ZAHLUNG_A'',''DARL_GEBUEHREN_A'',''DARL_ZINSEN_A'',''Zinszahlung (aktiv)'',''DARL_AUFL_ABGRZINS_A_W'') then 0 else TRANSAKTION_WERT_WHRG end) over (partition by F_C.FACILITY_ID)),0) -
              abs((coalesce(F_C.PRICIPAL_OST_TC_BW,0) - coalesce(F_A.PRICIPAL_OST_TC_BW,0)) )               as U_D_DELTA,
            F_A.CUT_OFF_DATE as CUT_OFF_DATE
        from '||active_Schema||'.TABLE_FACILITY_CORE_CURRENT as F_C
        left join '||active_Schema||'.TABLE_FACILITY_CORE_ARCHIVE as F_A on F_C.FACILITY_ID = F_A.FACILITY_ID and F_A.CUT_OFF_DATE = MAP.getPreviousQuarterCOD(MAP.getPreviousQuarterCOD(F_C.CUT_OFF_DATE))
        left join '||active_Schema||'.TABLE_CASH_FLOW_PAST_ARCHIVE as CFP_A on CFP_A.FACILITY_ID = F_C.FACILITY_ID
        left join '||active_Schema||'.TABLE_PORTFOLIO_ARCHIVE as P_A on P_A.FACILITY_ID = F_A.FACILITY_ID and F_A.CUT_OFF_DATE=P_A.CUT_OFF_DATE
        where F_A.INAKTIV <> 1
    )
where ABS(U_D_DELTA) > 1
  and left(FACILITY_ID,7)<> ''0009-33''
  and substr(FACILITY_ID,6,2) not in (''11'',''15'')
  and FAC_2019 is null';

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||active_Schema||'.TABLE_FACILITY_CORE_CURRENT'' as AFFECTED_TABLE,
        ''FACILITY_ID'' as AFFECTED_COLUMN,
        AFFECTED_ROW as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for BSNS_COMPARE_PO_AND_CF.');
end
&&


-- call CALC.VALID_PROC_BSNS_COMPARE_PO_AND_CF('ALL','08/31/2020',100);
