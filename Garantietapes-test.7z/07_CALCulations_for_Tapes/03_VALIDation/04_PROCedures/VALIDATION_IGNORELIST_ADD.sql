
drop procedure CALC.AUTO_PROC_VALIDATION_IGNORELIST_ADD(BIGINT, varchar(1024));
--#SET TERMINATOR &&
create or replace procedure CALC.AUTO_PROC_VALIDATION_IGNORELIST_ADD(VALIDATION_RESULT_ID BIGINT, REASON_FOR_IGNORING varchar(1024))
LANGUAGE SQL
  begin
    declare QueryStatement CLOB(200K);

    set QueryStatement = 'insert into CALC.TABLE_VALIDATION_IGNORELIST_ARCHIVE (VALIDATION_ID, AFFECTED_TABLE, ' ||
                         'AFFECTED_COLUMN, AFFECTED_ROW,COMMENT) select VALIDATION_ID, AFFECTED_TABLE, ' ||
                         'AFFECTED_COLUMN, AFFECTED_ROW, '''||REASON_FOR_IGNORING||''' as COMMENT from ' ||
                         'AMC.TABLE_VALIDATION_RESULTS_CURRENT where ID = '||VALIDATION_RESULT_ID;

    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(QueryStatement,'');

  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.AUTO_PROC_VALIDATION_IGNORELIST_ADD is 'Prozedur zum Hinzufügen einer Validierungsaußnahme.';
