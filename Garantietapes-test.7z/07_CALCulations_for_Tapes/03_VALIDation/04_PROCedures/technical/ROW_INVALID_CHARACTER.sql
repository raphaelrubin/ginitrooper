drop procedure CALC.VALID_PROC_ROW_INVALID_CHARACTERS (VARCHAR(8), VARCHAR(128), VARCHAR(256), VARCHAR(256),  VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_ROW_INVALID_CHARACTERS (TABSCHEMA VARCHAR(8), TABNAME VARCHAR(128),COLNAME_ID VARCHAR(256),COLNAME_VARCHAR VARCHAR(256), TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare active_Schema VARCHAR(8);
    declare used_Schema VARCHAR(8);
    declare COD_COLNAME varchar(128);
    declare curQueryShort varchar(450);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for ROW_INVALID_CHARACTERS.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();
    set used_Schema = COALESCE(TABSCHEMA,active_Schema);
    set COD_COLNAME = CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME(used_Schema,TABNAME);
    set curQuery = 'select '||COLNAME_ID||' as ROW_AFFECTED, '||COD_COLNAME||' as CUT_OFF_DATE,
       '''||COLNAME_VARCHAR||' enthällt ein invalides Zeichen (ASCII '' || ascii(substring('||COLNAME_VARCHAR||',NUMBER,1))||'')'' as ERRORMESSAGE
from '||used_Schema||'.'||TABNAME||'
left join CALC.AUTO_VIEW_NUMBERS on NUMBER < length('||COLNAME_VARCHAR||')
where '||COD_COLNAME||' = '''||CUT_OFF_DATE||'''
and ascii(substring('||COLNAME_VARCHAR||',NUMBER,1)) not between 32 and 127
and ascii(substring('||COLNAME_VARCHAR||',NUMBER,1)) not in (0,194,195)
limit 1';

    set curQueryShort = left(curQuery,450);
    call CALC.AUTO_PROC_LOG_DEBUG('    '||curQueryShort);

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||used_Schema||'.'||TABNAME||''' as AFFECTED_TABLE,
        '''||COLNAME_ID||''' as AFFECTED_COLUMN,
        ROW_AFFECTED as AFFECTED_ROW,
        ERRORMESSAGE as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for ROW_INVALID_CHARACTERS.');
end
&&


-- TEST

-- delete from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
-- call CALC.VALID_PROC_ROW_INVALID_CHARACTERS('AMC','TABLE_MARITIME_ASSET_ARCHIVE','ASSET_ID','SHIP_TYPE_OF_VESSEL_SUB_SEGMENT','ALL','07/31/2020',100);
-- select * from AMC.TABLE_VALIDATION_RESULTS_CURRENT where IMPORTANCE = 100;
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
--
-- select ASSET_ID as ROW_AFFECTED, CUT_OFF_DATE,
--        'SHIP_TYPE_OF_VESSEL_SUB_SEGMENT enhällt ein invalides Zeichen (ASCII ' || ascii(substring(SHIP_TYPE_OF_VESSEL_SUB_SEGMENT,NUMBER,1))||')' as ERRORMESSAGE
-- from AMC.TABLE_MARITIME_ASSET_ARCHIVE
-- left join CALC.AUTO_VIEW_NUMBERS on NUMBER < length(SHIP_TYPE_OF_VESSEL_SUB_SEGMENT)
-- where ascii(substring(SHIP_TYPE_OF_VESSEL_SUB_SEGMENT,NUMBER,1)) not between 32 and 127
-- and ascii(substring(SHIP_TYPE_OF_VESSEL_SUB_SEGMENT,NUMBER,1)) not in (0,194,195)
-- limit 1
-- ;
--
-- select ASSET_ID as ROW_AFFECTED, CUT_OFF_DATE,
--        'SHIP_TYPE_OF_VESSEL_SUB_SEGMENT enhällt ein invalides Zeichen (ASCII ' || ascii(substring('azAZ09!§$%&/()=?''"öüä"#+*-_.:,;][{}',NUMBER,1))||')' as ERRORMESSAGE
-- from AMC.TABLE_MARITIME_ASSET_ARCHIVE
-- left join CALC.AUTO_VIEW_NUMBERS on NUMBER < length('azAZ09!§$%&/()=?''"öüä"#+*-_.:,;][{}')
-- where ascii(substring('azAZ09!§$%&/()=?''"öüä"#+*-_.:,;][{}',NUMBER,1)) not between 32 and 127
-- and ascii(substring('azAZ09!§$%&/()=?''"öüä"#+*-_.:,;][{}',NUMBER,1)) not in (0,194,195)
-- limit 1
-- ;
--
--
-- with
--     -- finde erste id Spalte für die Tabellen
--     COLNAME_ID_ID as (
--         select distinct TABSCHEMA, TABNAME, first_value(COLNAME) over (partition by TABSCHEMA, TABNAME order by COLNO) as COLNAME
--         from SYSCAT.COLUMNS
--         where COLNAME like '%ID' -- Spalte muss eine ID sein
--           and COLNAME not in ('R_DET_SCENARIO_ID','R_RUN_ID','R_CLIENT_ID','R_BANK_ID') -- Unnütze ID Spalten
--     ),
--     -- finde die erste sinnvolle Spalte in den Tabellen
--     COLNAME_ID_FIRST as (
--         select distinct TABSCHEMA, TABNAME, first_value(COLNAME) over (partition by TABSCHEMA, TABNAME order by COLNO) as COLNAME
--         from SYSCAT.COLUMNS
--         where COLNAME not in ('CUTOFFDATE','CUT_OFF_DATE') -- Stichtag ist nicht hilfreich
--     ),
--     -- finde die erste ID und wenn keine vorhanden, dann die erste sinnvolle Spalte in jeder Tabelle
--     COLNAME_IDs as (
--         select COLNAME_ID_FIRST.TABSCHEMA, COLNAME_ID_FIRST.TABNAME, coalesce(COLNAME_ID_ID.COLNAME,COLNAME_ID_FIRST.COLNAME) as COLNAME
--         from COLNAME_ID_FIRST
--         left join COLNAME_ID_ID on (COLNAME_ID_ID.TABSCHEMA, COLNAME_ID_ID.TABNAME) = (COLNAME_ID_FIRST.TABSCHEMA, COLNAME_ID_FIRST.TABNAME)
--     ),
--     -- finde die kleinste Stage für die eine Tabele gebraucht wird.
--     FIRST_STAGE as (
--         select TABSCHEMA_SOURCE as TABSCHEMA, TABNAME_SOURCE as TABNAME, MIN(STAGE_REQUIRED_AT) as STAGE, nullif(MIN(coalesce(VALID_FROM,'01/01/2015')),'01/01/2015') as VALID_FROM, nullif(MAX(coalesce(VALID_UNTIL,'12/31/2999')),'12/31/2999') as VALID_UNTIL
--         from CALC.AUTO_TABLE_TARGET_TO_SOURCES
--         group by TABSCHEMA_SOURCE, TABNAME_SOURCE
--     ),
--     data as (
--         select distinct TARGETS.TABNAME,
--                         coalesce(FIRST_STAGE.STAGE,90) as SYSTEMSTAGE,
--                         NULL                as TAPENAME,
--                         'ROW_INVALID_CHARACTERS'    as PROCEDURE_NAME,
--                         '''' || TARGETS.TABSCHEMA || ''',''' ||
--                         TARGETS.TABNAME || ''','''||COLUMNS_ID.COLNAME ||''',''' || COLUMNS.COLNAME ||
--                         '''' as PARAMETERS,
--                         3 as IMPORTANCE,
--                         COLUMNS.COLNAME||' auf falsch encodierte Zeichen überprüfen.' as DESCRIPTION,
--                         FIRST_STAGE.VALID_FROM,
--                         FIRST_STAGE.VALID_UNTIL as VALID_TO
--         from CALC.AUTO_TABLE_TARGETS as TARGETS
--         left join SYSCAT.COLUMNS as COLUMNS
--                on (TARGETS.TABSCHEMA, TARGETS.TABNAME) = (COLUMNS.TABSCHEMA, COLUMNS.TABNAME)
--         left join COLNAME_IDs as COLUMNS_ID
--                on (TARGETS.TABSCHEMA, TARGETS.TABNAME) = (COLUMNS_ID.TABSCHEMA, COLUMNS_ID.TABNAME)
--         left join CALC.AUTO_TABLE_TARGETS as CURRENTS on TARGETS.TABNAME || '_CURRENT' = CURRENTS.TABNAME
--         left join FIRST_STAGE on (TARGETS.TABSCHEMA, TARGETS.TABNAME) = (FIRST_STAGE.TABSCHEMA, FIRST_STAGE.TABNAME)
--         where TARGETS.TABSCHEMA in ('NLB', 'BLB', 'CBB', 'IMAP') -- Uns interessieren nur Quelltabellen und keine SMAP, weil die von uns eingetippert werden.
--           and CURRENTS.TABNAME is NULL                           -- Es gibt zu dieser Tabelle keine CURRENT Tabelle.
--           and COLUMNS.TYPENAME in ('VARCHAR', 'CHAR')            -- Nur Textspalten
--           and COLUMNS.COLNAME not in ('BRANCH', 'QUELLE', 'USER')
--           and COLUMNS.COLNAME not like '%ID'                     -- Bestimmte Spalten müssen nicht überprüft werden
--     )
-- select * from data
-- where SYSTEMSTAGE < 90
-- ;
--
-- select * from CALC.AUTO_TABLE_VALIDATIONS where PROCEDURE_NAME = 'ROW_INVALID_CHARACTERS' order by TABNAME, PARAMETERS;
-- select MSN_ESN, AC_TYPE, AIRCRAFT_STATUS, MARKET_CLASS, MARKET_CLASS_DETAIL, OEM, OPERATOR, REGION_OPERATOR, REGISTER, TYPE_DETAIL, YOM from NLB.ACASA_AIRCRAFT_AKT_STATUS;
-- select CMS_ID, ANFORDERER, ANMERKUNGEN, AUFTRAGSART, BEWERTUNGSANLASS, BLW, CMS_FLUGZEUGMUSTERTYP, CMS_FLUGZEUGMUSTERVARIANTE, CMS_TRIEBWERKSVARIANTE, CURRENT_LEASE,  FLUGZEUGHERSTELLER, FLUGZEUGMUSTER, GES_MANAGER, GES_OWNER, GP_BEZEICHNUNG, GUTACHTER, CURRENT_LEASE, FLUGZEUGHERSTELLER, LAND, REGISTER_AUTHORITY, REGNO_PREFIX, REGNO_REST, SPECIFICS_EINTRAG, UEBERPRUEFUNG_BEANTRAGT, VERSION, VORLAEUFIG, WARTUNGSNACHWEIS, STATUS, TRIEBWERKSHAFTUNGSVERBUND, TRIEBWERKSTYP from NLB.ACASA_FLUGZEUG_GUTACHTEN;
