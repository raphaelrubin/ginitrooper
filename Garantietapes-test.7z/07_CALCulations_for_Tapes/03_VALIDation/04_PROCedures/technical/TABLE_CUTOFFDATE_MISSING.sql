drop procedure CALC.VALID_PROC_TABLE_CUTOFFDATE_MISSING (VARCHAR(8), VARCHAR(128), VARCHAR(256), VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_TABLE_CUTOFFDATE_MISSING (in_TABSCHEMA VARCHAR(8),in_TABNAME VARCHAR(128), COL_CUT_OFF_DATE VARCHAR(256), TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(200K);
    declare active_TABSCHEMA VARCHAR(8);
    declare TABSCHEMA VARCHAR(8);
    declare FULLTABNAME VARCHAR(256);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for TABLE_CUTOFFDATE_MISSING.');

    set active_TABSCHEMA = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    set TABSCHEMA = coalesce(in_TABSCHEMA,active_TABSCHEMA);
    set FULLTABNAME = case when instr(in_TABNAME,'.') > 0 then in_TABNAME else TABSCHEMA||'.'||in_TABNAME end;

    -- Validierungsquery
    set curQuery = 'select * from (select coalesce((select TRUE from '||FULLTABNAME||' where '||COL_CUT_OFF_DATE||' = '''||CUT_OFF_DATE||''' limit 1),FALSE) as HASENTRY from SYSIBM.SYSDUMMY1) where HASENTRY = FALSE';
    -- Eintrag für jeden gefundenen Fehler generieren
    set active_TABSCHEMA = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_TABSCHEMA,TABLEGROUP);
    set curQuery = 'insert into '||active_TABSCHEMA||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        '''||CUT_OFF_DATE||''' as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||in_TABNAME||''' as AFFECTED_TABLE,
        NULL as AFFECTED_COLUMN,
        NULL as AFFECTED_ROW,
        ''Die Tabelle '||FULLTABNAME||' ist für diesen Stichtag leer.'' as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for TABLE_CUTOFFDATE_MISSING.');
end
&&


-- TEST
-- select * from (select coalesce((select TRUE from NLB.LIQ_DEAL_STATUS where CUTOFFDATE = '08/31/2020' limit 1),FALSE) as HASENTRY from SYSIBM.SYSDUMMY1) where HASENTRY = FALSE
--
-- call CALC.VALID_PROC_TABLE_CUTOFFDATE_MISSING('NLB','LIQ_DEAL_STATUS','CUTOFFDATE','ALL','08/31/2020',2);
--
-- insert into CALC.AUTO_TABLE_VALIDATIONS (TABNAME, SYSTEM_STAGE, TAPENAME, PROCEDURE_NAME, PARAMETERS, IMPORTANCE, DESCRIPTION, VALID_FROM, VALID_TO)
-- select distinct
--     VAL.TABNAME,
--     SYSTEM_STAGE,
--     TAPENAME,
--     'TABLE_CUTOFFDATE_MISSING' as PROCEDURE_NAME,
--     PARAMETERS||', '''||TAR.COLNAME_CUT_OFF_DATE||'''' as PARAMETERS,
--     2 as IMPORTANCE,
--     replace(DESCRIPTION,' leer?',' für den gewünschten Stichtag leer?') as DESCRIPTION,
--     VALID_FROM, VALID_TO
-- from CALC.AUTO_TABLE_VALIDATIONS as VAL
-- left join CALC.AUTO_TABLE_TARGETS as TAR on VAL.TABNAME = TAR.TABNAME
-- where PROCEDURE_NAME = 'TABLE_EMPTY' and COLNAME_CUT_OFF_DATE is not NULL
