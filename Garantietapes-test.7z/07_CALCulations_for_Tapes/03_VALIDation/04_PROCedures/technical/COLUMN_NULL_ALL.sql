drop procedure CALC.VALID_PROC_COLUMN_NULL_ALL (VARCHAR(8), VARCHAR(128), VARCHAR(256), VARCHAR(512), VARCHAR(128), DATE, INTEGER, BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.VALID_PROC_COLUMN_NULL_ALL (TABSCHEMA VARCHAR(8), TABNAME VARCHAR(128),COLNAME VARCHAR(256), REASONMSG VARCHAR(512), TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)
    LANGUAGE SQL
  BEGIN
    declare curQuery CLOB(800 K);
    declare curQueryShort VARCHAR(450);
    declare active_Schema VARCHAR(8);
    declare used_Schema VARCHAR(8);
    declare COD_COLNAME varchar(128);

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Executing validation for COLUMN_NULL_ALL.');

    set active_Schema = CALC.AUTO_FUNC_GET_ACTIVE_TAPE();
    set used_Schema = COALESCE(TABSCHEMA,active_Schema);
    set REASONMSG = COALESCE(REASONMSG,'');
    set COD_COLNAME = CALC.AUTO_FUNC_GET_CUT_OFF_DATE_COLNAME(used_Schema,TABNAME);
    set curQuery = 'select CNN.CUT_OFF_DATE, '''||COLNAME||' ist immer NULL. '||REASONMSG||''' as ERRORMESSAGE
from (
    select coalesce('||coalesce(COD_COLNAME,''''||CUT_OFF_DATE||'''')||','''||CUT_OFF_DATE||''') as CUT_OFF_DATE, count('||COLNAME||') as COUNT
    from '||used_Schema||'.'||TABNAME||'
    '||case when COD_COLNAME is not NULL then 'group by '||COD_COLNAME else '' end || --
') as CNN where CNN.COUNT = 0';

    set curQueryShort = left(curQuery,450);
    call CALC.AUTO_PROC_LOG_DEBUG('    '||curQueryShort);

    set active_Schema = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(active_Schema,TABLEGROUP);
    set curQuery = 'insert into '||active_Schema||'.TABLE_VALIDATION_RESULTS_CURRENT(TABLEGROUP,CUT_OFF_DATE,IMPORTANCE,AFFECTED_TABLE,AFFECTED_COLUMN,AFFECTED_ROW,ERRORMESSAGE,VALIDATION_ID)
        select
        '''||TABLEGROUP||''' as TABLEGROUP,
        CUT_OFF_DATE as CUT_OFF_DATE,
        '||IMPORTANCE||' as IMPORTANCE,
        '''||used_Schema||'.'||TABNAME||''' as AFFECTED_TABLE,
        '''||COLNAME||''' as AFFECTED_COLUMN,
        NULL as AFFECTED_ROW,
        trim(ERRORMESSAGE) as ERRORMESSAGE
    , '||VALIDATION_ID||' as VALIDATION_ID from ('||curQuery||')';

    -- Test ausführen:
    call CALC.AUTO_PROC_EXECUTE_IMMEDIATE(curQuery,'    ');

    call CALC.AUTO_PROC_LOG_DEBUG('  '||'Finished executing validation for COLUMN_NULL_ALL.');
end
&&

-- call CALC.VALID_PROC_COLUMN_ALL_NULL ('AMC', 'TABLE_FACILITY_CORE_CURRENT', 'RIVO_STAGE','Wurde BW verarbeitet?','ALL','07/31/2020',4); -- Check 38
-- call CALC.VALID_PROC_COLUMN_ALL_NULL ('AMC', 'TABLE_FACILITY_CORE_CURRENT', 'LIQ_PAST_DUE_TILG_ORIGINAL_CURRENCY','Wurde LIQ_PAST_DUE verarbeitet?','ALL','07/31/2020',4); -- Check 39


