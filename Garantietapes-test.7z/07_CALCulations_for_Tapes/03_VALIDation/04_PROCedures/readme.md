## PROCedures

Dieser Ordner beinhaltet alle Prozeduren, welche Validierungen ausführen.

Jede Prozedur muss mit CALC.VALID_PROC_ beginnen.

Jede Prozedur muss `,TABLEGROUP VARCHAR(128),CUT_OFF_DATE DATE,IMPORTANCE INTEGER, VALIDATION_ID BIGINT)` als letzte Argumente haben und
darf nichts zurückgeben. Das Ergebnis der Tests muss in die jeweilige Tape Tabelle geschrieben werden.