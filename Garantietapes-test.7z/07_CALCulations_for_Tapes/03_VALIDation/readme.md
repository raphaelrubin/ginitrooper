# VALIDation

beinhaltet alles was rein für die Validierungen genutzt wird.

Alles was hier drinnen erstellt wird muss mit `CALC.VALID_` beginnen.

Wenn du Tabellen oder VIews hier erwartest aber nicht finden kannst sind sie vermutlich in CALCulations > AUTOmation.
Die Teile der Validierung, die nicht die eigentliche Validierung durchführen gehören zur Automatisierung.