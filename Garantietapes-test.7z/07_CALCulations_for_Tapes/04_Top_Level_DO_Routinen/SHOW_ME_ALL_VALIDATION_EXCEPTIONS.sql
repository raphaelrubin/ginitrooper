
drop procedure CALC.DO_SHOW_ME_ALL_VALIDATION_EXCEPTIONS();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_SHOW_ME_ALL_VALIDATION_EXCEPTIONS ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.TABLE_VALIDATION_IGNORELIST_ARCHIVE
         order by CREATED_AT
         ;

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_SHOW_ME_ALL_VALIDATION_EXCEPTIONS is 'Zeigt Ausnahmen zur Validierung an';


-- call CALC.DO_SHOW_THE_LOG;