
drop procedure CALC.DO_BUILD_A_TABLE_EXPLICITELY (VARCHAR(8), VARCHAR(128));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_BUILD_A_TABLE_EXPLICITELY (desired_TABSCHEMA VARCHAR(8), desired_TABNAME VARCHAR(128))
    LANGUAGE SQL
begin
    -- Input Validation
    if not EXISTS(select * from SYSCAT.TABLES where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
        call CALC.AUTO_PROC_LOG_ERROR(desired_TABSCHEMA||'.'||desired_TABNAME||' nicht in der SYSCAT','71001');
    end if;
    if not EXISTS(select * from CALC.AUTO_TABLE_TARGETS where TABSCHEMA = desired_TABSCHEMA and TABNAME = desired_TABNAME) then
        call CALC.AUTO_PROC_LOG_ERROR(desired_TABSCHEMA||'.'||desired_TABNAME||' nicht in CALC.AUTO_TABLE_TARGETS','71002');
    end if;

    call CALC.AUTO_PROC_BUILD_EXPLICIT_TABLE(desired_TABSCHEMA,desired_TABNAME,'');

    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_BUILD_A_TABLE_EXPLICITELY is 'Baut die Tabelle im gegebenen Tape neu. desired_TABNAME = Name der Tabelle; for_TAPE = Name des Tapes, welches neu gebaut werden soll; for_CUT_OFF_DATE = Der Stichtag (z.B. ''31.12.2019''), with_Mode = Modus (z.B. ''FINAL'')';

-- call CALC.DO_BUILD_A_TABLE_EXPLICITELY('NLB','SPOT_STAMMDATEN_CURRENT');
-- call CALC.DO_BUILD_A_TABLE_EXPLICITELY('NLB','SPOT_STAMMDATEN');
-- call CALC.DO_BUILD_A_TABLE_EXPLICITELY('IMAP','CURRENCY_MAP');
-- call CALC.DO_BUILD_A_TABLE_EXPLICITELY('AMC','TABLE_PORTFOLIO_CURRENT');