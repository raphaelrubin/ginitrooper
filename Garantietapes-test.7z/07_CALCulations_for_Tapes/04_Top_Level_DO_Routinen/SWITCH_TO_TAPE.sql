drop procedure CALC.DO_SWITCH_TO_TAPE(VARCHAR(8));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_SWITCH_TO_TAPE (TAPENAME VARCHAR(8))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    call CALC.AUTO_PROC_LOG_INFO('Switch to Tape '||TAPENAME||'.');
    call CALC.AUTO_PROC_CONTROL_PREPARE(TAPENAME);
    update CALC.AUTO_TABLE_TAPES set IS_ACTIVE = FALSE where NAME <> TAPENAME;
    update CALC.AUTO_TABLE_TAPES set IS_ACTIVE = TRUE where NAME = TAPENAME;
    COMMIT;
    call CALC.AUTO_PROC_LOG_INFO('Finished switching to tape '||TAPENAME||'.');
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_SWITCH_TO_TAPE is 'Ändert das aktuelle Tape auf das gewünschte Tape. Dieses wird dann von anderen Prozeduren gebaut/exportiert.';


-- call CALC.DO_SWITCH_TO_TAPE('AMC');