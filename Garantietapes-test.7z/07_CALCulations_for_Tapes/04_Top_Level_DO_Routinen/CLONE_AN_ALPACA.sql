
drop procedure CALC.DO_CLONE_AN_ALPACA(INT);
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CLONE_AN_ALPACA(number_of_times INT)
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_ALPACA
         ;

    call CALC.AUTO_PROC_ALPACA_CLONE(number_of_times);

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CLONE_AN_ALPACA is 'Klont ein Alpaka der Herde die gewünschte Anzahl an Malen. Ein Klon kostet 200 Sterne.';