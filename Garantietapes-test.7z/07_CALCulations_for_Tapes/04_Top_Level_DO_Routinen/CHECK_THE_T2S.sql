
drop procedure CALC.DO_CHECK_THE_T2S();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CHECK_THE_T2S ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_TEST_T2S order by TABSCHEMA, TABNAME
         ;

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CHECK_THE_T2S is 'Zeigt die eventuelle Probleme der aktiven T2S Tabelle.';


-- call CALC.DO_CHECK_THE_T2S;