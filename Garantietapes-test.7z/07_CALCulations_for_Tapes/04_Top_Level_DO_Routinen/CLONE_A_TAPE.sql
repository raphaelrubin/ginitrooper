
drop procedure CALC.DO_CLONE_A_TAPE(varchar(8),varchar(8),varchar(512));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CLONE_A_TAPE(TAPE_toclone varchar(8),new_TAPE varchar(8),TAPE_DESCRIPTION varchar(512))
    LANGUAGE SQL
    DYNAMIC RESULT SETS 1
BEGIN


    declare schemacode VARCHAR(512);
    declare schemapremissions VARCHAR(512);
    declare tablespacecode VARCHAR(1024);
    declare tablespacepermissions VARCHAR(1024);

    DECLARE curOUTFAIL CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select '4) Grant permissions for tablespaces', tablespacepermissions from SYSIBM.SYSDUMMY1
            union all
         select '3) Create tablespaces', tablespacecode from SYSIBM.SYSDUMMY1
            union all
         select '2) Grant permissions for schema', schemapremissions from SYSIBM.SYSDUMMY1
            union all
         select '1) Create schema', schemacode from SYSIBM.SYSDUMMY1
    ;

    DECLARE curOUTSUCCESS CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select 'Created new Schema.' from SYSIBM.SYSDUMMY1
    ;

    set schemacode = 'create schema '||new_TAPE||';'; -- Schema erstellen

    set schemapremissions = ''||
        'db2 "grant alterin ON SCHEMA '||new_TAPE||' TO GROUP DBBLOSSOM"
        db2 "grant createin ON SCHEMA '||new_TAPE||' TO GROUP DBBLOSSOM"
        db2 "grant dropin ON SCHEMA '||new_TAPE||' TO GROUP DBBLOSSOM"';

    set tablespacecode = '' ||
        'db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_A MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP1"
        db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_B MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP2"
        db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_C MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP3"
        db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_D MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP4"
        db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_E MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP5"
        db2 "CREATE TABLESPACE SPACE_'||new_TAPE||'_F MANAGED BY AUTOMATIC STORAGE USING stogroup STOGRP6"';

    set tablespacepermissions = '' ||
        'db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_A TO GROUP DBBLOSSOM"
        db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_B TO GROUP DBBLOSSOM"
        db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_C TO GROUP DBBLOSSOM"
        db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_D TO GROUP DBBLOSSOM"
        db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_E TO GROUP DBBLOSSOM"
        db2 "GRANT USE OF TABLESPACE SPACE_'||new_TAPE||'_F TO GROUP DBBLOSSOM"';

    if NOT EXISTS (select * from SYSCAT.SCHEMATA where SCHEMANAME = new_TAPE) then
        OPEN curOUTFAIL;
        RETURN;
    end if;

    --call CALC.AUTO_PROC_CONTROL_PREPARE(TAPE_toclone);
    call CALC.AUTO_PROC_TAPE_CLONE(TAPE_toclone,new_TAPE,TAPE_DESCRIPTION);

    OPEN curOUTSUCCESS;
    RETURN;
END
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CLONE_A_TAPE is 'Erstellt ein komplett neues Tape basierend auf einem existierendem Tape. TAPE_toclone = zu kopierendes Tapeschema; new_TAPE = neuer Tapename (Schema muss schon erstellt sein); TAPE_DESCRIPTION = Beschreibungstext für das Tape.';

--
-- call CALC.AUTO_PROC_BUILD_GROUP_CANCEL();
--
-- call CALC.DO_VIEW_THE_LOG();
--
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
--
-- call CALC.HELP();
-- REBIND PACKAGE CALC.SQL200305153250762;
-- call sysproc.ADMIN_REVALIDATE_DB_OBJECTS('PROCEDURE','CALC','AUTO_PROC_TAPE_REMOVE');
-- call CALC.DO_REMOVE_A_TAPE('GGG');
-- call CALC.DO_CLONE_A_TAPE('AMC','GGG','Test Tape');
--
-- call CALC.AUTO_PROC_TAPE_REMOVE('GGG');
-- delete from CALC.AUTO_TABLE_TAPES where NAME = 'TMP';
-- call CALC.AUTO_PROC_CONTROL_PREPARE('AMC');
-- call CALC.AUTO_PROC_TAPE_CLONE('AMC','GGG','Test Tape');
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
--
-- select * from GGG.AUTO_TABLE_GROUPS;
-- insert into GGG.AUTO_TABLE_GROUPS (TABNAME, GROUPNAME, EXPORTNAME) values ('TAPE_AIRCRAFT_ASSET_FINISH','AIRCRAFT','TEST_AIRCRAFT_ASSET');
-- insert into GGG.AUTO_TABLE_GROUPS (TABNAME, GROUPNAME, EXPORTNAME) values ('TAPE_AIRCRAFT_COLLATERAL_FINISH','AIRCRAFT','TEST_AIRCRAFT_COLLATERAL');
-- insert into GGG.AUTO_TABLE_GROUPS (TABNAME, GROUPNAME, EXPORTNAME) values ('TAPE_AIRCRAFT_COLLATERAL_TO_FACILITY_FINISH','AIRCRAFT','TEST_AIRCRAFT_COLLATERAL2FACILITY');
-- insert into GGG.AUTO_TABLE_GROUPS (TABNAME, GROUPNAME, EXPORTNAME) values ('TAPE_AIRCRAFT_ASSET_TO_COLLATERAL_FINISH','AIRCRAFT','TEST_AIRCRAFT_ASSET2COLLATERAL');
--
--
-- call CALC.AUTO_PROC_BUILD_GROUP('AMC','FLUGZEUGE','31.12.2019','FINAL');
--
--
--
--
-- select VALID, * from SYSCAT.PROCEDURES where SPECIFICNAME = 'SQL200305153250762' or PROCNAME = 'AUTO_PROC_TAPE_REMOVE';
--
-- select VALID, * from SYSCAT.PROCEDURES where PROCSCHEMA = 'CALC';
--
-- select * from SYSCAT.TABLES where TABSCHEMA = 'TMP' and TABNAME like 'AUTO_%';
-- delete from CALC.AUTO_TABLE_TAPES where NAME = 'TMP';
--
-- create table TMP.AMC_GG like AMC.AMC_GG including identity including defaults partition by RANGE (CUT_OFF_DATE) (starting '1.1.2015' ending '31.12.2025' EVERY 1 Month) in SPACE_TMP_A,SPACE_TMP_B,SPACE_TMP_C,SPACE_TMP_D,SPACE_TMP_E,SPACE_TMP_F;
--
--
-- select * from AMC.AUTO_TABLE_MODES;
--
--
-- create or replace view CALC.AUTO_VIEW_GROUPS as
--     with CLEANED_DATA as ( select distinct 'AMC' as TAPENAME, GROUPNAME, CALC.AUTO_FUNC_CHANGE_NAME_TABLE_TO_ROOT(TABNAME) as TABNAME from AMC.AUTO_TABLE_GROUPS;
