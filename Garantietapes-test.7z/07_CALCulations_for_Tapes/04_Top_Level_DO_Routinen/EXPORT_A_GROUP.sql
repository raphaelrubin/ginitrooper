
drop procedure CALC.DO_EXPORT_A_GROUP (VARCHAR(128), VARCHAR(10));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_EXPORT_A_GROUP (TABLEGROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    declare for_TAPE VARCHAR(8);
    SET for_TAPE = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    call CALC.AUTO_PROC_EXPORT_GROUP (for_TAPE , TABLEGROUP ,for_CUT_OFF_DATE );
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_EXPORT_A_GROUP is 'Exportiert die Tabellen für die gegebene Gruppe im gegebenen Tape. GROUP = Name der Gruppe; for_TAPE = Name des Tapes, welches neu gebaut werden soll; for_CUT_OFF_DATE = Der Stichtag (z.B. ''31.12.2019'')';