# Top Level Routinen

Hier befinded sich der Code für alle Prozeduren, die normalerweise von Nutzern der Automatisierung aufgerufen werden.
Die Prozeduren hier sollen nur eine der AUTO_PROC Prozeduren aus dem automation Ordner mit den richtigen Parametern
aufrufen und einen formatierten Output zurückgeben.