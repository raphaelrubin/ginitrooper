drop procedure CALC.DO_RUN_VALIDATIONS (VARCHAR(128), VARCHAR(10), VARCHAR(32));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_RUN_VALIDATIONS (desired_TABLEGROUP VARCHAR(128), for_CUT_OFF_DATE VARCHAR(10), with_RAWDATASYSTEMS VARCHAR(32))
    --DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    declare for_TAPE VARCHAR(8);
    declare resultTape VARCHAR(8);
    declare chosen_CUT_OFF_DATE DATE;
    -- Cursor erstellen, der den finalen Output an den Client übergibt
    --DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
    --    for
    --        select RESULTS.*
    --        from CALC.SWITCH_VALIDATION_RESULTS_CURRENT as RESULTS
    --        left join CALC.TABLE_VALIDATION_IGNORELIST_ARCHIVE as IGNORE
    --            on (RESULTS.VALIDATION_ID, RESULTS.AFFECTED_TABLE, RESULTS.AFFECTED_COLUMN, RESULTS.AFFECTED_ROW) =
    --               ( IGNORE.VALIDATION_ID,  IGNORE.AFFECTED_TABLE,  IGNORE.AFFECTED_COLUMN,  IGNORE.AFFECTED_ROW)
    --        where IGNORE.ID is NULL -- Eintrag ist nicht auf der Ignorierliste
    --        order by IMPORTANCE
    --;
    SET for_TAPE = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    set resultTape = CALC.AUTO_FUNC_GET_VALID_RESULT_SCHEMA(for_TAPE,desired_TABLEGROUP);
    set chosen_CUT_OFF_DATE = DATE(for_CUT_OFF_DATE);
    call CALC.AUTO_PROC_SWITCH_FLIP(resultTape,'TABLE_VALIDATION_RESULTS_CURRENT','  ');
    call CALC.AUTO_PROC_VALIDATION_BUILD(desired_TABLEGROUP,chosen_CUT_OFF_DATE,with_RAWDATASYSTEMS);

    --OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_RUN_VALIDATIONS is 'Baut die Validierungen für die gegebene Gruppe im aktiven Tape neu. TABLEGROUP = Name der Gruppe; for_TAPE = Name des Tapes, welches neu gebaut werden soll; for_CUT_OFF_DATE = Der Stichtag (z.B. ''31.12.2019''), with_RAWDATASYSTEMS = Modus (z.B. ''FINAL'')';


-- TEST
-- call CALC.AUTO_PROC_SWITCH_FLIP('AMC','TABLE_VALIDATION_RESULTS_CURRENT','  ');
-- call CALC.DO_RUN_VALIDATIONS('ALL','31.07.2020','FINAL');
