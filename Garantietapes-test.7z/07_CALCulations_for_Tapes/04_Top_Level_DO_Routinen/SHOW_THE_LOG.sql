
drop procedure CALC.DO_SHOW_THE_LOG();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_SHOW_THE_LOG ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select CREATED_AT, LEVEL, MESSAGE from (
                                    select CREATED_AT, LEVEL, MESSAGE
                                    from CALC.AUTO_VIEW_LOG
                                    union all
                                    select CREATED_AT, LEVEL, MESSAGE
                                    from (select * from CALC.AUTO_VIEW_LOG_DEBUG order by CREATED_AT DESC limit 1)
                                    where LEVEL = 'DEBUG'
                                ) AS A
         order by CREATED_AT DESC
         limit 500
         ;

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_SHOW_THE_LOG is 'Zeigt die neuesten Einträge im Log an.';


-- call CALC.DO_SHOW_THE_LOG;