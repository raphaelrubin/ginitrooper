
drop procedure CALC.DO_BUILD_A_GROUP (VARCHAR(128), DATE, VARCHAR(32));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_BUILD_A_GROUP (desired_TABLEGROUP VARCHAR(128), for_CUT_OFF_DATE DATE, with_RAWDATASYSTEMS VARCHAR(32))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    declare for_TAPE VARCHAR(8);
    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select 'Tape' as KEY, cast(TAPE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Group' as KEY, cast(GROUP as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Cut off date' as KEY, cast(CUT_OFF_DATE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Version' as KEY, cast(VERSION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Created at' as KEY, cast(CREATED_AT as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Duration' as KEY, cast(DURATION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select 'Completed' as KEY, cast(COMPLETED as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1)
            union all
            select LOG.LEVEL as KEY, trim(cast(LOG.MESSAGE as VARCHAR(512))) as VALUE from CALC.AUTO_TABLE_LOG as LOG
                full outer join (select * from CALC.AUTO_VIEW_VERSIONS where TAPE = for_Tape order by CREATED_AT DESC limit 1) as parameters on LOG.CREATED_AT > parameters.CREATED_AT
                where LEVEL in ('ERROR','WARNING')
                  and parameters.TYPE is not NULL
    ;

    --insert into CALC.AUTO_TABLE_EXECUTION_PLAN (VERSION, COMMAND) VALUES (1,'select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1');
    SET for_TAPE = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);

    call CALC.AUTO_PROC_BUILD_GROUP(for_TAPE,desired_TABLEGROUP,for_CUT_OFF_DATE,with_RAWDATASYSTEMS);

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_BUILD_A_GROUP is 'Baut die Tabellen für die gegebene Gruppe im gegebenen Tape neu. TABLEGROUP = Name der Gruppe; for_TAPE = Name des Tapes, welches neu gebaut werden soll; for_CUT_OFF_DATE = Der Stichtag (z.B. ''31.12.2019''), with_RAWDATASYSTEMS = Modus (z.B. ''FINAL'')';

--
-- call CALC.DO_SWITCH_TO_TAPE('AMC');
-- truncate CALC.AUTO_TABLE_EXECUTION_PLAN immediate;
-- call CALC.DO_BUILD_A_GROUP('ALL','31.12.2019','FINAL');
-- select * from CALC.AUTO_TABLE_EXECUTION_PLAN order by CREATED_AT;
-- call CALC.DO_CONTINUE_BUILDING();
--
-- call CALC.DO_SHOW_THE_LOG();
--
-- call CALC.DO_CANCEL_BUILDING();