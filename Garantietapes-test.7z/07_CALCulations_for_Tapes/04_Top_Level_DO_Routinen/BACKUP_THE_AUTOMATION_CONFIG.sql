
drop procedure CALC.DO_BACKUP_THE_AUTOMATION_CONFIG ();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_BACKUP_THE_AUTOMATION_CONFIG ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    declare for_TAPE VARCHAR(8);
    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select * from (select TABSCHEMA, TABNAME from SYSCAT.TABLES where TABSCHEMA = 'CALC' and TABNAME like 'BACKUP_AUTO_TABLE_TARGET_TO_SOURCES%' order by CREATE_TIME desc limit 1)
            union all
            select * from (select TABSCHEMA, TABNAME from SYSCAT.TABLES where TABSCHEMA = 'CALC' and TABNAME like 'BACKUP_AUTO_TABLE_TARGETS%' order by CREATE_TIME desc limit 1)
    ;

    call CALC.AUTO_PROC_LOG_INFO('Creating backups for all config tables.');
    call CALC.AUTO_PROC_BACKUP_WRITE('CALC','AUTO_TABLE_TARGET_TO_SOURCES','  ');
    call CALC.AUTO_PROC_BACKUP_WRITE('CALC','AUTO_TABLE_TARGETS','  ');
    call CALC.AUTO_PROC_LOG_INFO('Finished creating backups for all config tables.');
    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_BACKUP_THE_AUTOMATION_CONFIG is 'Baut die Backup Tabellen für T und T2S Tabellen';


-- call CALC.DO_BACKUP_THE_AUTOMATION_CONFIG();