
drop procedure CALC.DO_LIST_BACKUPS(BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.DO_LIST_BACKUPS (ONLY_MOST_RECENT BOOLEAN)
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    declare for_TAPE VARCHAR(8);
    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select TABSCHEMA, TABNAME from SYSCAT.TABLES where TABSCHEMA = 'CALC' and TABNAME like 'BACKUP%' order by CREATE_TIME
    ;
    DECLARE curOUT_RECENT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select distinct TABSCHEMA, first_value(TABNAME) over (partition by TABNAME_ORIG order by TABNAME DESC) as TABNAME
            from (
                  select TABSCHEMA,
                         TABNAME,
                         TRIM(T '_' from TRIM(B ' ' from REPLACE(TRANSLATE(TABNAME, '', '0123456789'), 'BACKUP_', ''))) as TABNAME_ORIG
                  from SYSCAT.TABLES
                  where TABSCHEMA = 'CALC'
                    and TABNAME like 'BACKUP%'
                  order by CREATE_TIME
              )
    ;
    if ONLY_MOST_RECENT then
        OPEN curOUT_RECENT;
    else
        OPEN curOUT;
    end if;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_LIST_BACKUPS is 'Zeigt einem alle Backups';


-- TEST
-- call CALC.DO_LIST_BACKUPS(TRUE);