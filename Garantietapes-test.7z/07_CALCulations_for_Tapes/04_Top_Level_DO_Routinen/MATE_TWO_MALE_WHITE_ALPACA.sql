
drop procedure CALC.DO_MATE_TWO_MALE_WHITE_ALPACA();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_MATE_TWO_MALE_WHITE_ALPACA()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_ALPACA
         ;

    call CALC.AUTO_PROC_ALPACA_MATE();

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_MATE_TWO_MALE_WHITE_ALPACA is 'Versucht zwei männliche weiße Alpaka zu paaren. Dies schlägt meistens fehl...';