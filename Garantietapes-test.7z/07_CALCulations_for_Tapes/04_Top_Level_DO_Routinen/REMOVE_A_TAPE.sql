
drop procedure CALC.DO_REMOVE_A_TAPE(varchar(8));
--#SET TERMINATOR &&
create or replace procedure CALC.DO_REMOVE_A_TAPE(TAPE_to_delete varchar(8))
    AUTONOMOUS
    LANGUAGE SQL
BEGIN
    call CALC.AUTO_PROC_TAPE_REMOVE(TAPE_to_delete);
END
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_REMOVE_A_TAPE(varchar(8)) is 'Achtung! Entfernt ein vorhandenes Tape';