drop procedure CALC.DO_SHOW_THE_STATE_OF_TABLES();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_SHOW_THE_STATE_OF_TABLES()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_TABLE_BUILD_STATE order by TABSCHEMA, TABNAME;

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_SHOW_THE_STATE_OF_TABLES is 'Zeigt eine Liste an Tabellen, wann sie zuletzt gebaut und exportiert wurden.';


-- call CALC.DO_SHOW_THE_STATE_OF_TABLES();