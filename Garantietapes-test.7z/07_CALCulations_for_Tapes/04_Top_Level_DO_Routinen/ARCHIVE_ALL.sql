-- Archives all Tape Tables as the CURRENT Tables are.
drop procedure CALC.DO_ARCHIVE_ALL();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_ARCHIVE_ALL()
    LANGUAGE SQL
  BEGIN
    declare TAPE VARCHAR(8);
    declare CUT_OFF_DATE DATE;

    SET TAPE = (select NAME from CALC.AUTO_TABLE_TAPES where IS_ACTIVE limit 1);
    SET CUT_OFF_DATE = (select CUT_OFF_DATE from CALC.AUTO_TABLE_BUILD_VERSIONS where TAPENAME = TAPE order by CREATED_AT DESC limit 1);

    call CALC.AUTO_PROC_BUILD_ARCHIVES(TAPE, CUT_OFF_DATE, FALSE);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_ARCHIVE_ALL is 'Baut alle Archive für das aktuelle Tape für den letzte gebauten Stichtag.';