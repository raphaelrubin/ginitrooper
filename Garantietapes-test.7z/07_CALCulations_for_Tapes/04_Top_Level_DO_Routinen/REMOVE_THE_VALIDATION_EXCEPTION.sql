
drop procedure CALC.DO_REMOVE_THE_VALIDATION_EXCEPTION(BIGINT);
--#SET TERMINATOR &&
create or replace procedure CALC.DO_REMOVE_THE_VALIDATION_EXCEPTION(with_exception_ID BIGINT)
DYNAMIC RESULT SETS 1
LANGUAGE SQL
  begin
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
        select * from CALC.TABLE_VALIDATION_IGNORELIST_ARCHIVE order by CREATED_AT;

    call CALC.AUTO_PROC_VALIDATION_IGNORELIST_REMOVE(with_exception_ID);

    OPEN curOUT;
    RETURN;

  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_REMOVE_THE_VALIDATION_EXCEPTION is 'Prozedur zum Entfernen einer Validierungsaußnahme.';
