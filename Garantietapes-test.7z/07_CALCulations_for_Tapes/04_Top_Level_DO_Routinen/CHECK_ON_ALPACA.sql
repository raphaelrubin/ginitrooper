
drop procedure CALC.DO_CHECK_ON_ALPACA();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CHECK_ON_ALPACA ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_ALPACA
         ;

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CHECK_ON_ALPACA is 'Zeigt die aktuelle Anzahl an Alpaka und Sternen an.';


--call CALC.DO_CHECK_ON_ALPACA;