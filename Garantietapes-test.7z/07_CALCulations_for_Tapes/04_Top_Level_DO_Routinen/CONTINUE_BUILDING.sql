drop procedure CALC.DO_CONTINUE_BUILDING(BOOLEAN);
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CONTINUE_BUILDING(rebuild_last_table BOOLEAN)
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select 'Tape' as KEY, cast(TAPE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Group' as KEY, cast(GROUP as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Cut off date' as KEY, cast(CUT_OFF_DATE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Version' as KEY, cast(VERSION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Created at' as KEY, cast(CREATED_AT as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Duration' as KEY, cast(DURATION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Completed' as KEY, cast(COMPLETED as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select LOG.LEVEL as KEY, trim(cast(LOG.MESSAGE as VARCHAR(512))) as VALUE from CALC.AUTO_TABLE_LOG as LOG
                full outer join (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1) as parameters on LOG.CREATED_AT > parameters.CREATED_AT
                where LEVEL in ('ERROR','WARNING')
                  and parameters.TYPE is not NULL
    ;

    call CALC.AUTO_PROC_BUILD_GROUP_CONTINUE(rebuild_last_table);

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CONTINUE_BUILDING(BOOLEAN) is 'Wenn die vorherige Ausführung der Bau Prozedur abgebrochen ist, kann sie mit diesem Befehl neugestartet werden.';



drop procedure CALC.DO_CONTINUE_BUILDING();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CONTINUE_BUILDING()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
            select 'Tape' as KEY, cast(TAPE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Group' as KEY, cast(GROUP as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Cut off date' as KEY, cast(CUT_OFF_DATE as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Version' as KEY, cast(VERSION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Created at' as KEY, cast(CREATED_AT as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Duration' as KEY, cast(DURATION as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select 'Completed' as KEY, cast(COMPLETED as VARCHAR(512)) as VALUE from (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1)
            union all
            select LOG.LEVEL as KEY, trim(cast(LOG.MESSAGE as VARCHAR(512))) as VALUE from CALC.AUTO_TABLE_LOG as LOG
                full outer join (select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1) as parameters on LOG.CREATED_AT > parameters.CREATED_AT
                where LEVEL in ('ERROR','WARNING')
                  and parameters.TYPE is not NULL
    ;

    call CALC.DO_CONTINUE_BUILDING(FALSE);

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CONTINUE_BUILDING() is 'Wenn die vorherige Ausführung der Bau Prozedur abgebrochen ist, kann sie mit diesem Befehl neugestartet werden.';

--
--
--
-- call CALC.DO_VIEW_THE_LOG();
-- select * from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC;
-- insert into AMC.TABLE_CASH_FLOW_FUTURE_CURRENT select * from CALC.VIEW_CASH_FLOW_FUTURE;
-- call CALC.DO_CONTINUE_BUILDING();