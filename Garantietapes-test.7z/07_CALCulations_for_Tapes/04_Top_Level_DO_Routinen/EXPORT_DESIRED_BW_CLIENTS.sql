drop procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS(DATE);
--#SET TERMINATOR &&
create or replace procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS(CUTOFFDATE DATE)
DYNAMIC RESULT SETS 1
LANGUAGE SQL
begin
    declare zip_command VARCHAR(10000);
    declare send_command VARCHAR(10000);
    declare export_code CLOB(200k);
    declare filename VARCHAR(256);
    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CLIENT
        for
            select zip_command, '7ZIP COMMAND' from SYSIBM.SYSDUMMY1
                union all
            select send_command, 'SEND COMMAND' from SYSIBM.SYSDUMMY1
        ;


      set filename = 'BW_KUNDENLISTE_'|| VARCHAR_FORMAT(CUTOFFDATE,'YYYYMM');
      call CALC.AUTO_PROC_LOG_INFO('Start exporting '||filename);

      --updates the COD for the View that creates the Client sets
      if(select count(*) from CALC.AUTO_TABLE_CLIENTS_FOR_BW_DESIRED_COD )>=1
          then
                update CALC.AUTO_TABLE_CLIENTS_FOR_BW_DESIRED_COD set COD = CUTOFFDATE where 1=1;
          else
            insert into CALC.AUTO_TABLE_CLIENTS_FOR_BW_DESIRED_COD select CUTOFFDATE from sysibm.SYSDUMMY1;
      end if;
      --inserts the data for the current client selection and updates the TIMESTAMP update if the data column already existed. The Choosen COD is used to calculate the Client LIST
      merge into  CALC.AUTO_TABLE_CLIENTS_FOR_BW as A using CALC.AUTO_VIEW_CLIENTS_FOR_BW as B on (A.ZM_EXTNR,A.ZM_IDTYPE,A.THE_DATE,A.FISCPER) = (B.ZM_EXTNR,B.ZM_IDTYPE,b.THE_DATE,B.FISCPER)
        when matched then UPDATE set (A.ZM_EXTNR,A.ZM_IDTYPE,A.THE_DATE,A.FISCPER,A.LAST_CHANGED_AT,A.LAST_CHANGED_BY) = (B.ZM_EXTNR,B.ZM_IDTYPE,B.THE_DATE,B.FISCPER,current timestamp,current user)
        when not MATCHED then insert (ZM_EXTNR,ZM_IDTYPE,THE_DATE,FISCPER) values (B.ZM_EXTNR,B.ZM_IDTYPE,B.THE_DATE,B.FISCPER)
        else ignore;
      --exports the current clients with the selected COD

      set zip_command = CALC.AUTO_FUNC_GET_7Z_ZIP_CODE(filename,filename);
      set send_command = 'send '||filename||'.7z';
      set export_code = 'select ZM_EXTNR,ZM_IDTYPE,FISCPER from CALC.AUTO_TABLE_CLIENTS_FOR_BW
            where 1=1
                and LAST_CHANGED_AT in (select MAX(LAST_CHANGED_AT) from  CALC.AUTO_TABLE_CLIENTS_FOR_BW  where month(THE_DATE) = month('''|| CUTOFFDATE ||''') and year(THE_DATE) = year('''|| CUTOFFDATE ||'''))
                and month(THE_DATE) = MONTH('''|| CUTOFFDATE ||''')
                and year(THE_DATE) = year('''|| CUTOFFDATE ||''')';
      call STG.PROC_EXPORT_SQL_AUTOMATION(export_code,filename);
      call CALC.AUTO_PROC_LOG_INFO('  Zip Code:'||LEFT(zip_command,500));
      call CALC.AUTO_PROC_LOG_INFO('  Send Code:'||send_command);
      call CALC.AUTO_PROC_LOG_INFO('Finished exporting '||filename);
      OPEN curOUT;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS(DATE) is 'Exportiert die BW Kundenliste für den gewünschten Stichtag';



drop procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS()
DYNAMIC RESULT SETS 1
LANGUAGE SQL
  begin
      declare current_CUT_OFF_DATE DATE;
      set current_CUT_OFF_DATE = LAST_DAY(CURRENT_DATE - 1 MONTH);
      call CALC.DO_EXPORT_DESIRED_BW_CLIENTS(current_CUT_OFF_DATE);
  end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_EXPORT_DESIRED_BW_CLIENTS() is 'Exportiert die BW Kundenliste für den aktuellen Stichtag';


-- TEST
-- call CALC.DO_EXPORT_DESIRED_BW_CLIENTS();
