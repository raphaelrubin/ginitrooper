drop procedure CALC.DO_CANCEL_BUILDING ();
--#SET TERMINATOR &&
create or replace procedure CALC.DO_CANCEL_BUILDING ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select * from CALC.AUTO_VIEW_VERSIONS where TYPE = 'BUILD' order by CREATED_AT DESC limit 1
         ;

    call CALC.AUTO_PROC_BUILD_GROUP_CANCEL();

    OPEN curOUT;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.DO_CANCEL_BUILDING is 'Achtung! Wenn die vorherige Ausführung der Bau Prozedur abgebrochen ist, kann sie mit diesem Befehl beendet werden. Stelle vor dem Ausführen sicher, dass die Bau Prozedur wirklich nicht mehr läuft!';
