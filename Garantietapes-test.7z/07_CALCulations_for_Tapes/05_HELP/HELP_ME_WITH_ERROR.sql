drop procedure CALC.HELP_ME_WITH_ERROR(varchar(4),char(5));
--#SET TERMINATOR &&
create or replace procedure CALC.HELP_ME_WITH_ERROR(in_SQLCODE VARCHAR(4),in_SQLSTATE CHAR(5))
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT1 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select SQLCODE, SQLSTATE, MESSAGE, PROBLEM, SOLUTION from CALC.AUTO_TABLE_ERRORS where SQLCODE = in_SQLCODE and SQLSTATE = in_SQLSTATE order by MESSAGE
         ;

    OPEN curOUT1;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.HELP_ME_WITH_ERROR is 'Zeigt Infos für einen bestimmten SQLCODE und SQLSTATE an.';