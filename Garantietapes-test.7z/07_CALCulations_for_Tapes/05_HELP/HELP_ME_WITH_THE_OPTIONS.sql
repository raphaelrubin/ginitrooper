drop procedure CALC.HELP_ME_WITH_THE_OPTIONS ();
--#SET TERMINATOR &&
create or replace procedure CALC.HELP_ME_WITH_THE_OPTIONS ()
    DYNAMIC RESULT SETS 3
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT1 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select NAME as TAPENAME, DESCRIPTION from CALC.AUTO_TABLE_TAPES order by TAPENAME
         ;
    DECLARE curOUT2 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select MODENAME as RAWDATASYSTEMS_NAME, DESCRIPTION from CALC.AUTO_VIEW_MODES order by MODENAME
         ;
    DECLARE curOUT3 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
          select GROUPNAME as TABLEGROUP_NAME, DESCRIPTION, TABLES as TABLES_IN_GROUP from CALC.AUTO_VIEW_GROUPS order by GROUPNAME
         ;

    OPEN curOUT1;
    OPEN curOUT2;
    OPEN curOUT3;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.HELP_ME_WITH_THE_OPTIONS is 'Zeigt alle möglichen Optionen für Tape, Group und Mode und deren Beschreibung.';