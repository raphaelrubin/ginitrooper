drop procedure CALC.HELP_ME_DECIDE_WHAT_TO_DO ();
--#SET TERMINATOR &&
create or replace procedure CALC.HELP_ME_DECIDE_WHAT_TO_DO ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin
    DECLARE currentCOD DATE;
    DECLARE currentDayOfMonth INT;
    DECLARE hasUnfinishedRoutine BOOLEAN;
    DECLARE lastExportetName VARCHAR(64);
    DECLARE hasUnexportetData BOOLEAN;
    DECLARE BWhasbeenLoaded BOOLEAN;
    DECLARE lastCOD DATE;
    DECLARE lastGroup VARCHAR(128);
    DECLARE lastMode VARCHAR(128);
    DECLARE sourcesCOD DATE;
    DECLARE thisCOD DATE;
    DECLARE thisGroup VARCHAR(128);
    DECLARE thisMode VARCHAR(128);
    DECLARE nextMode VARCHAR(128);
    DECLARE hasUnarchivedData BOOLEAN;
    DECLARE lastTable VARCHAR(128);
    DECLARE dotPos INT;
    DECLARE lastTABSCHEMA VARCHAR(128);
    DECLARE lastTABNAME VARCHAR(128);
    DECLARE lastTableBUILDCODE CLOB(400k);

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT1 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
        select CODE, DESCRIPTION from (
            -- neue Automatisierungs Vorschläge
            select replace(CODE,'{$COD}',currentCOD) as CODE, DESCRIPTION, 4 as ORDER
            from CALC.AUTO_TABLE_RELEVANT_PROCEDURES
            where currentDayOfMonth between RELEVANT_FROM_DAY_OF_MONTH and RELEVANT_UNTIL_DAY_OF_MONTH
              and not hasUnfinishedRoutine

        union all
        -- Automatisierung läuft gerade
                -- Prozedur neu starten
                select 'call CALC.DO_CONTINUE_BUILDING(FALSE);' as CODE, 'Wenn die Prozedur abgebrochen ist, kann sie mit diesem Befehl neu gestartet werden wobei Fehler soweit möglich ignoriert werden.' as DESCRIPTION, 1 as ORDER
                from SYSIBM.SYSDUMMY1
                where hasUnfinishedRoutine
            union all
                -- Prozedur abbrechen
                select 'call CALC.DO_CANCEL_BUILDING();' as CODE, 'Wenn die Prozedur abgebrochen ist, kann sie mit diesem Befehl beendet werden.' as DESCRIPTION, 2 as ORDER
                from SYSIBM.SYSDUMMY1
                where hasUnfinishedRoutine
            union all
                -- Prozedur abbrechen und Tabelle neu bauen
                select 'call CALC.DO_CANCEL_BUILDING();
call CALC.DO_BUILD_A_TABLE('''||lastTable||''','''||thisCOD||''','''||thisMode||''');' as CODE, 'Wenn die Prozedur abgebrochen ist, kann sie mit diesem Befehl beendet und die Problem Tabelle neu gebaut werden.' as DESCRIPTION, 3 as ORDER
                from SYSIBM.SYSDUMMY1
                where hasUnfinishedRoutine and lastTABNAME <> ''
            union all
                -- Tabelle neu bauen
                select lastTableBUILDCODE as CODE, 'Wenn die Prozedur abgebrochen ist, kann dieser Code die Problem-Tabelle neu bauen.' as DESCRIPTION, 3 as ORDER
                from SYSIBM.SYSDUMMY1
                where hasUnfinishedRoutine and lastTableBUILDCODE is not NULL


        union all
        -- Automatisierung ist abgeschlossen
                -- Archivieren
                select 'call CALC.DO_ARCHIVE_ALL();' as CODE, 'Archiviere die Daten aus dem letzten Lauf.' as DESCRIPTION, 6 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine and hasUnarchivedData
            union all
                -- Tape Ändern
                select 'call CALC.DO_SWITCH_TO_TAPE(''AMC'');' as CODE, 'Ändere das Tape.' as DESCRIPTION, 3 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine
            union all
                -- Validierung Endtabellen
                select 'call CALC.DO_RUN_VALIDATIONS('''||lastGroup||''','''||lastCOD||''','''||lastMode||''');' as CODE, 'Validierung für die Daten aus dem letzten Run ausführen.' as DESCRIPTION, 5 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine
            union all
                -- Validierung Quelltabellen
                select 'call CALC.DO_RUN_VALIDATIONS(''SOURCES'','''||sourcesCOD||''','''||nextMode||''');' as CODE, 'Validierung für die Daten in den Quelltabellen ausführen.' as DESCRIPTION, 5 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine
            union all
                -- Exportieren
                select 'call CALC.DO_EXPORT_A_GROUP('''||lastGroup||''','''||lastCOD||''');' as CODE, 'Die neuesten Daten wurden noch nicht exportiert. Mit dieser Prozedur kann das nachgeholt werden.' as DESCRIPTION, 7 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine and hasUnexportetData
            union all
                -- Letzten Run
                select 'call CALC.DO_BUILD_A_GROUP('''||lastGroup||''','''||lastCOD||''','''||lastMode||''');' as CODE, 'Letzten Run nochmal ausführen.' as DESCRIPTION, 4 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine
            union all
                -- BW Kunden für BW Bestellung
                select 'call CALC.DO_EXPORT_DESIRED_BW_CLIENTS();' as CODE, 'Kundenliste für die BW Bestellung exportieren.' as DESCRIPTION, 8 as ORDER
                from SYSIBM.SYSDUMMY1
                where not hasUnfinishedRoutine and not BWhasbeenLoaded

        union all
        -- Generische Hilfe

                select 'call CALC.DO_SHOW_THE_LOG();' as CODE, 'Die Automatisierung ist stecken geblieben aber du weißt nicht wo? Diese Prozedur hilft dir! Schau auch in die Wiki! https://gitlab.i-lab.local/dlab/BLOSSOM/-/wikis/Tape%20Automation' as DESCRIPTION, 9 as ORDER
                from SYSIBM.SYSDUMMY1 where hasUnfinishedRoutine
            union all
                select 'call CALC.HELP_ME_WITH_THE_OPTIONS();' as CODE, 'Du willst eine andere Option für die Automatisierung auswählen? Diese Prozedur hilft dir! Ansonsten schau mal in die Wiki! https://gitlab.i-lab.local/dlab/BLOSSOM/-/wikis/Tape%20Automation' as DESCRIPTION, 9 as ORDER
                from SYSIBM.SYSDUMMY1
            union all
                select '' as CODE, 'Nicht gefunden was du suchst? Schau mal in die Wiki! https://gitlab.i-lab.local/dlab/BLOSSOM/-/wikis/Tape%20Automation' as DESCRIPTION, 10 as ORDER
                from SYSIBM.SYSDUMMY1
        ) order by ORDER
        ;

    -- Parameter berechnen

    -- aktuellen Stichtag berechnen
    set currentCOD = last_day(CURRENT_DATE - 1 MONTH);
    -- aktuellen tag des Monats berechnen
    set currentDayOfMonth = day(CURRENT_DATE);
    -- Wurde BW schon geladen?
    set BWhasbeenLoaded = FALSE;
    if (select CUTOFFDATE from NLB.BW_ZBC_IFRS_CURRENT limit 1) = currentCOD then
        set BWhasbeenLoaded = TRUE;
    end if;
    -- ist die neueste Routine abgeschlossen?
    set hasUnfinishedRoutine = FALSE;
    if EXISTS(select * from CALC.AUTO_TABLE_BUILD_VERSIONS where COMPLETED = FALSE) then
        set hasUnfinishedRoutine = TRUE;
    end if;
    -- Wurde die neueste Ausführung schon exportiert?
    set lastExportetName = (select EXPORT.EXPORTNAME_FULL
from CALC.AUTO_TABLE_BUILD_VERSIONS as BUILD
left join CALC.AUTO_TABLE_EXPORT_VERSIONS as EXPORT
    on (BUILD.TAPENAME,BUILD.GROUPNAME,BUILD.CUT_OFF_DATE) = (EXPORT.TAPENAME, EXPORT.GROUPNAME, EXPORT.CUT_OFF_DATE)
    and BUILD.CREATED_AT < EXPORT.CREATED_AT
where BUILD.GROUPNAME <> 'ARCHIVES'
  and BUILD.COMPLETED
order by BUILD.CREATED_AT DESC
limit 1);
    set hasUnexportetData = FALSE;
    if lastExportetName is NULL then
        set hasUnexportetData = TRUE;
    end if;
    -- Einstellungen des letzten erfolgreichen Runs
    set lastCOD = (select CUT_OFF_DATE from CALC.AUTO_TABLE_BUILD_VERSIONS where GROUPNAME <> 'ARCHIVES' and COMPLETED = TRUE order by CREATED_AT DESC limit 1 with UR);
    set lastGroup = (select GROUPNAME from CALC.AUTO_TABLE_BUILD_VERSIONS where GROUPNAME <> 'ARCHIVES' and COMPLETED = TRUE order by CREATED_AT DESC limit 1 with UR);
    set lastMode = (select MODE.NAME from CALC.AUTO_TABLE_BUILD_VERSIONS as BUILDS left join CALC.AUTO_TABLE_MODES as MODE on BUILDS.ARG_STAGE = STAGE where BUILDS.GROUPNAME <> 'ARCHIVES' and BUILDS.COMPLETED = TRUE order by BUILDS.CREATED_AT DESC limit 1 with UR);
    set thisCOD = (select CUT_OFF_DATE from CALC.AUTO_TABLE_BUILD_VERSIONS where GROUPNAME <> 'ARCHIVES' order by CREATED_AT DESC limit 1 with UR);
    set thisGroup = (select GROUPNAME from CALC.AUTO_TABLE_BUILD_VERSIONS where GROUPNAME <> 'ARCHIVES' order by CREATED_AT DESC limit 1 with UR);
    set thisMode = (select MODE.NAME from CALC.AUTO_TABLE_BUILD_VERSIONS as BUILDS left join CALC.AUTO_TABLE_MODES as MODE on BUILDS.ARG_STAGE = STAGE where BUILDS.GROUPNAME <> 'ARCHIVES' order by BUILDS.CREATED_AT DESC limit 1 with UR);
    set sourcesCOD = lastCOD;
    -- Einstellung der nächsten Quelldateien
    set nextMode = (select distinct first_value(MODE_NEXT.NAME) over ( order by MODE_NEXT.STAGE ASC )
    from CALC.AUTO_TABLE_MODES as MODE_NOW
    left join CALC.AUTO_TABLE_MODES as MODE_NEXT on MIN(MODE_NOW.STAGE,49) < MODE_NEXT.STAGE
    where MODE_NOW.NAME = thisMode);
    if (currentDayOfMonth < 5 and thisMode = 'FINAL WITH BW') then
        set nextMode = (select NAME from CALC.AUTO_TABLE_MODES where STAGE > 0 order by STAGE limit 1);
        set sourcesCOD = currentCOD;
    end if;
    -- wurde der letzte Lauf schon archiviert?
    set hasUnarchivedData = TRUE;
    if (select GROUPNAME from CALC.AUTO_TABLE_BUILD_VERSIONS order by CREATED_AT DESC limit 1 with UR) = 'ARCHIVES' then
        set hasUnarchivedData = FALSE;
    end if;
    -- zuletzt gebaute Tabelle?
    set lastTABSCHEMA = '';
    set lastTABNAME = '';
    set lastTable = (select LEFT(MESSAGE,MAX(MIN(LOCATE(' ',MESSAGE),LOCATE('(',MESSAGE))-1,0)) from (select TRIM(cast(LEFT(REPLACE(REPLACE(REPLACE(MESSAGE,'About to execute: "',''),'merge into ',''),'insert into ',''),128) as VARCHAR(128)))  as MESSAGE, CREATED_AT from CALC.AUTO_TABLE_LOG order by CREATED_AT DESC limit 1 with UR));
    if LOCATE('.',lastTable) > 0 then
        set dotPos = LOCATE('.',lastTable);
        set lastTABSCHEMA = SUBSTR(lastTable,1,dotPos-1);
        set lastTABNAME = SUBSTR(lastTable,dotPos+1,LENGTH(lastTable)-dotPos);
    end if;
    set lastTableBUILDCODE = (select CALC.AUTO_FUNC_GET_BUILD_CODE( TABSCHEMA,lastTABSCHEMA, TABNAME ) from CALC.AUTO_TABLE_TARGETS where TABNAME = lastTABNAME and (TABSCHEMA = lastTABSCHEMA or BUILD_VIEW_SCHEMA = 'CALC') limit 1 with UR);
    -- Ergebnis ausgeben
    OPEN curOUT1;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.HELP_ME_DECIDE_WHAT_TO_DO is 'Zeigt dir, was du zu diesem Zeitpunkt wahrscheinlich ausführen möchtest.';
