drop procedure CALC.HELP ();
--#SET TERMINATOR &&
create or replace procedure CALC.HELP ()
    DYNAMIC RESULT SETS 1
    LANGUAGE SQL
begin

    -- Cursor erstellen, der den finalen Output an den Client übergibt
    DECLARE curOUT1 CURSOR WITH HOLD WITH RETURN TO CALLER
        for
         select PROCEDURE, DESCRIPTION
         from (
                           select 'call CALC.' || NAME || COALESCE(SIGNATURE, '') || ';' as PROCEDURE,
                                  REMARKS                                                as DESCRIPTION,
                                  2 as ORDER
                           from CALC.AUTO_VIEW_DOCUMENTATION
                           where NAME like 'DO_%'
                           union all
                           select 'call CALC.' || NAME || COALESCE(SIGNATURE, '') || ';' as PROCEDURE,
                                  REMARKS                                                as DESCRIPTION,
                                  1 as ORDER
                           from CALC.AUTO_VIEW_DOCUMENTATION
                           where NAME like 'HELP%'

                       )
         order by ORDER, PROCEDURE
         ;

    OPEN curOUT1;
    RETURN;
end
&&
--#SET TERMINATOR ;
comment on procedure CALC.HELP is 'Zeigt eine Liste aller Top-Level Prozeduren und deren Beschreibung.';
